# GPU response player versus current CPU — 2026-09-20

The native GPU player completes modeled-field decisions from trick 1, but this
version is slower and shows no observed playing-strength improvement. Keep the
landed CPU implementation as the production player.

## Fixed comparison

Apple M5 Max / Metal; 18 CPU query threads for the GPU player and 18 workers for
the CPU player. Both use L2 Partner 40/8/2, Fixed/Fixed, Voidless, review off.
The GPU controller prices up to eight initial priority plans per legal root
and then refines lawful focal horizons, with a 100ms **per-move** allowance.
The actual current CPU wrapper at `f1a0fb045a316379a853b63df696d7e924349826`
retains its normal 14,000ms per-move allowance and staged reserve behavior.
It completed its requested Partner stage in every nonforced position.

This is an explicitly unequal-allowance comparison against the current player,
not an equal-time strength test or a 100ms whole-game result. Initialization
and one declared off-panel warmup per player are recorded separately. Online
wall time includes IPC, serialization, validation, solving, cleanup and any
reserve work. Both sides retain persistent worker processes.

The protocol fixes 72 fresh physical deals: two per each of nine declarations
and four bidder seats, all at bid 30. Every deal is played with GPU declaring
and CPU defending, then with partnerships swapped; order reverses for the
second deal in each declaration/bidder cell. Physical-deal and player-seed
namespaces are separate. Only the acting hand and public history reach a
player. Fixtures, source/binary/compiler identities, configuration and analysis
were saved before play. No games were dropped or retried and the player was
not changed after seeing outcomes.

## Results

All **144 games and 4,032 plays** passed independent Python replay. Both players
had zero reserve fallbacks. Of 72 paired contract comparisons, the GPU player
won **4**, lost **5**, and tied **63**. The mean paired make/set difference was
−1.39 percentage points. The comparative contract fraction was 49.31%, with a
fixed-N Hoeffding 95% interval of 33.30–65.31%. This small development panel
supports neither stronger play nor equivalence.

| Warm online wall time | GPU player | Current CPU |
|---|---:|---:|
| Mean partnership total per game (14 plays) | 358.83ms | 69.16ms |
| Median partnership total | 362.90ms | 64.95ms |
| p95 partnership total | 533.25ms | 155.42ms |
| Mean individual move, including forced/settled | 25.63ms | 4.94ms |
| p95 individual move | 100.22ms | 25.78ms |
| Maximum individual move | 101.42ms | 157.04ms |

The GPU's mean partnership time is **5.19×** the CPU's; its p95 is **3.43×**.
It fails the proposed 10% latency gate. The GPU's cooperative 100ms allowance
was exceeded externally on 303 of 2,016 calls, by at most 1.42ms. The current
CPU exceeded none of its configured allowances. These are totals from the
different positions each player encountered, not same-input speedup ratios.

The GPU returned 1,007 completely priced response reports, including 714
canonical root-action certificates. It completed 5,663 batches and **945,480
policy/scenario lanes**. There were 59 cancelled batches; earlier completed
witnesses survived, so these cancellations did not require fallback moves.
At trick 1 alone, 192 decisions completed GPU batches, totaling 279,000 lanes.
The other 1,009 GPU calls were forced or contract-settled.

Across the panel, 70,369 device epochs used 17.85s of measured device-call wall
time and 19.83s of CPU field-resolution wall time. The controller's total
partnership time was 51.67s; the current CPU used 9.96s. This explains the next
performance question: reducing repeated policy/query work and increasing useful
work per device crossing, while preserving exact modeled responses. No further
parameter tuning was performed on this panel.

## Reproduce and inspect

From the instrument directory, after preparing the reference and building the
release GPU worker with `RUSTFLAGS='-C target-cpu=native'`:

```sh
python3 tools/h2h_current.py results/new-current-h2h --gpu-ms 100 --cpu-ms 14000 --threads 18
python3 tools/h2h_current.py results/gpu-current-h2h-v1 --analyze-only
```

[`protocol.json`](protocol.json) pins every fixture and identity;
[`startup.json`](startup.json) records initialization/warmup;
[`summary.json`](summary.json) holds complete statistics and paired outcomes.
The numbered declaring/defending JSON files retain every original hand,
request, response, policy, bound, physical move and measured time. Reanalysis
independently replays every game and verifies integer report relationships.
No phone, production-strength or full-game 100ms claim follows from this result.
