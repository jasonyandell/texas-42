# Fixed-priority GPU rollout: correctness and native throughput

Exploratory native primitive result on Apple M5 Max / Metal. This does not measure an online L2 player, playing strength, or the cost of discovering ready GPU work. The kernel only implements historical Dice.

The stackless WGSL kernel evaluates one complete priority policy against one original scenario. It takes at most 28 physical plays and returns one own-team Boolean payoff. Duplicate deals with different tapes retain distinct columns. Integer weighting and root reductions run on the CPU. Restricted plan pools supply lower witnesses; this report does not use their column maxima as unrestricted upper bounds.

## Validation

- All 5 rollout contract tests passed. The suite covers all 9 declarations, depths 2–7, partial trick lengths 0–3, both teams, legal replay and tile conservation, full 5,040-plan families, original scenario ordering and weights, cancellation, malformed plans, and changed field revisions.
- 16,512 complete chronological CPU/GPU continuations matched, plus 85,680 full-family payoff lanes and 672 directed arithmetic vectors. Directed vectors force first-draw acceptance/rejection boundaries for every modulus 1–28 and exercise all partial-trick lengths.
- Every matrix in the 18-case timing panel matched both the canonical scalar reference and a compact scalar implementation before timing. Every repeated matrix and weighted reduction also matched.
- The canonical reference uses PublicState and the frozen v34 mechanics. The compact scalar control and WGSL use tables generated directly from that rule algebra; the canonical trace oracle is independent of the table-based transition implementation.

## Timing protocol

Built both native binaries with `cargo build --release --features gpu --bins`. Ran `target/release/rollout_bench 4` with the timing lane reserved. Each case has four repetitions alternating canonical/compact/GPU and GPU/compact/canonical. No old DFS timings are used as a comparison.

The primary comparison is the compact scalar control. The canonical reference additionally maintains full public histories and materializes diagnostic traces, which makes its runtime a correctness-instrument cost. Both CPU controls include validation, result allocation and the same integer weighted reduction; the compact control also builds its rule tables inside each call. GPU time includes validation, packet construction, buffer allocation/upload, dispatch, mapped readback, row assembly and that same reduction.

Scenarios and plans are prepared separately for each case and their measured costs are retained in the raw JSON. Add those costs to any arm when accounting for one-shot request construction. Device/rule/pipeline initialization is separately measured at **103.786 ms**. These are synchronous native Metal measurements, not browser measurements.

Synthetic legal roots use no trump at depths 2, 4 and 7. Hidden-hand exchanges preserve capacities and public void deductions, but this is not a calibrated belief sampler. Candidate pools contain an ascending and descending continuation per legal root, with identical duplicates omitted for depth 2; full families include all root-first permutations. The 40-scenario cases match the outer sample count, not the dependency structure or ready width of an actual modeled player.

## Results

| Depth | Scenarios | Family | Plans | Lanes | Compact CPU median ms | GPU median ms | CPU / GPU |
|---:|---:|---|---:|---:|---:|---:|---:|
| 2 | 8 | two_per_root | 2 | 16 | 0.004 | 0.338 | 0.01 |
| 2 | 8 | complete | 2 | 16 | 0.003 | 0.269 | 0.01 |
| 2 | 40 | two_per_root | 2 | 80 | 0.005 | 0.285 | 0.02 |
| 2 | 40 | complete | 2 | 80 | 0.005 | 0.506 | 0.01 |
| 2 | 512 | two_per_root | 2 | 1,024 | 0.045 | 0.497 | 0.09 |
| 2 | 512 | complete | 2 | 1,024 | 0.046 | 0.296 | 0.16 |
| 4 | 8 | two_per_root | 8 | 64 | 0.008 | 0.351 | 0.02 |
| 4 | 8 | complete | 24 | 192 | 0.018 | 0.292 | 0.06 |
| 4 | 40 | two_per_root | 8 | 320 | 0.030 | 0.309 | 0.10 |
| 4 | 40 | complete | 24 | 960 | 0.053 | 0.333 | 0.16 |
| 4 | 512 | two_per_root | 8 | 4,096 | 0.448 | 0.302 | 1.48 |
| 4 | 512 | complete | 24 | 12,288 | 1.193 | 1.012 | 1.18 |
| 7 | 8 | two_per_root | 14 | 112 | 0.030 | 0.629 | 0.05 |
| 7 | 8 | complete | 5,040 | 40,320 | 5.333 | 1.332 | 4.00 |
| 7 | 40 | two_per_root | 14 | 560 | 0.093 | 0.698 | 0.13 |
| 7 | 40 | complete | 5,040 | 201,600 | 25.765 | 2.895 | 8.90 |
| 7 | 512 | two_per_root | 14 | 7,168 | 1.846 | 0.817 | 2.26 |
| 7 | 512 | complete | 5,040 | 2,580,480 | 413.689 | 14.733 | 28.08 |

At depth 7 with 40 scenarios, the compact CPU wins on the 14-policy candidate pool, while the GPU wins on the complete 5,040-policy family. Full enumeration performs much more work than evaluating a small lawful incumbent pool; this timing result does not establish that enumeration belongs inside every nested modeled decision.

The largest 5,040 by 512 matrix contains 2,580,480 lanes, a 173,632-byte input packet and 10,321,920-byte readback. GPU times range from 8.390 to 21.132 ms across the four alternating repetitions, with a 14.733 ms median, versus 413.689 ms for the compact scalar median. This substantial latency variation is retained in the raw samples; four repetitions do not establish a stable tail estimate.

The current host allocates buffers for each call and returns an error if a batch exceeds device limits. It has no asynchronous controller, grouped multi-root scheduler, buffer pool, or automatic chunking. GPU initialization is not amortized into these per-call numbers. The CPU player remains the separately evaluated implementation; no whole-game 100 ms target or strength improvement is claimed here.

## Evidence

- [Raw timing samples](timings.jsonl), [summary and environment](summary.json), [validation log](validation.log), [benchmark stderr](benchmark.stderr), [source identities](SOURCE.sha256).
- Sources: `src/rollout.rs`, `src/gpu.rs`, `src/rollout.wgsl`, `tests/rollout_contract.rs`, `src/bin/rollout_bench.rs`.
- Validation command: `cargo test --features gpu --test rollout_contract -- --nocapture --test-threads=1`.
