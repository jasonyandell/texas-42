#!/usr/bin/env python3
"""Exact normalized cross-score of v3/v4 role actors on identical v4 labels."""
from collections import Counter, defaultdict
from fractions import Fraction
import hashlib, json, pathlib, shutil

ROOT=pathlib.Path('/Users/jason/.codex/worktrees/walt-response-ladder/texas-42/experiments/response-ladder')
OUT=ROOT/'results/compiled-v4-cross-score'
CAMPAIGNS={'c0':ROOT/'results/compiled-calibration-v4','c1':ROOT/'results/compiled-t1-calibration-v4'}
ACTORS={
 'c0': {'v3':json.loads((ROOT/'results/compiled-c0-v3/actor.json').read_text()), 'v4':json.loads((ROOT/'results/compiled-c0-v4/actor.json').read_text())},
 'c1': {'v3':json.loads((ROOT/'results/compiled-c1-v3/actor.json').read_text()), 'v4':json.loads((ROOT/'results/compiled-c1-v4/actor.json').read_text())},
}

def digest(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def role(req):
 viewer=(int(req['seat'])+int(int(req['bidder'])%2==0))%4
 return 'declaring' if viewer%2 else 'defending'
def choose(actor,response,rr):
 answers=response.get('clause_actions') or []
 for c in actor[rr]['clauses']:
  if c<len(answers) and answers[c] is not None: return int(answers[c])
 vals=response.get('action_counts') or []
 if isinstance(vals,dict): vals=[(int(a),n) for a,n in vals.items()]
 return min(int(a) for a,n in vals)
def load(campaign):
 rows=[]; statuses=Counter()
 for p in sorted((campaign/'lessons').glob('*.json')):
  x=json.loads(p.read_text()); r=x.get('response',x); st=x.get('status',r.get('status','missing-status'))
  if st!=r.get('status',st): raise ValueError(f'status mismatch {p}')
  statuses[st]+=1
  if st=='complete': rows.append({'id':x['id'],'group':str(x['group']),'split':x['split'],'request':x['request'],'response':r})
 return rows,statuses

def metric(rows,actor,split=None,rr=None):
 chosen=[r for r in rows if (split is None or r['split']==split) and (rr is None or role(r['request'])==rr)]
 groups=defaultdict(list)
 for r in chosen: groups[r['group']].append(r)
 costs=[]; opt=tied=nonopt=0
 byhand=defaultdict(list)
 for members in groups.values():
  for r in members:
   resp=r['response']; vals=resp['action_counts']; vals=dict((int(a),int(n)) for a,n in vals.items()) if isinstance(vals,dict) else {int(a):int(n) for a,n in vals}
   assert vals and resp['mass']>0
   best=max(vals.values()); pick=choose(actor,resp,role(r['request'])); assert pick in vals
   c=Fraction(best-vals[pick],int(resp['mass'])); assert Fraction(0)<=c<=Fraction(1)
   costs.append(c); opt+=pick in {a for a,n in vals.items() if n==best}; tied+=pick in {a for a,n in vals.items() if n==best} and pick!=resp.get('canonical_action'); nonopt+=pick not in {a for a,n in vals.items() if n==best}
   byhand[len(r['request'].get('hand',[]))].append((r['group'],c))
 # group mean, then mean over groups: exact fit_compiled.py weighting.
 group_means=[]
 for members in groups.values():
  group_means.append(sum((Fraction(max(dict((int(a),int(n)) for a,n in (m['response']['action_counts'].items() if isinstance(m['response']['action_counts'],dict) else m['response']['action_counts'])).values())-dict((int(a),int(n)) for a,n in (m['response']['action_counts'].items() if isinstance(m['response']['action_counts'],dict) else m['response']['action_counts']))[choose(actor,m['response'],role(m['request']))],int(m['response']['mass'])) for m in members),Fraction())/len(members))
 score=sum(group_means,Fraction())/len(group_means) if group_means else None
 hand={}
 for hs,pairs in sorted(byhand.items()):
  hg=defaultdict(list)
  for g,c in pairs: hg[g].append(c)
  hm=sum((sum(v,Fraction())/len(v) for v in hg.values()),Fraction())/len(hg)
  hand[str(hs)]={'rows':len(pairs),'groups':len(hg),'equal_group_weighted_cost':rat(hm)}
 return {'rows':len(chosen),'groups':len(groups),'equal_group_weighted_cost':rat(score),'optimal_set_hits':int(opt),'optimal_set_hit_rate':opt/len(chosen) if chosen else None,'canonical_tie_differences':int(tied),'nonoptimal_choices':int(nonopt),'by_handsize':hand}
def rat(v): return None if v is None else {'numerator':v.numerator,'denominator':v.denominator,'decimal':float(v)}
def compare(rows,a,b,split=None,rr=None):
 chosen=[r for r in rows if (split is None or r['split']==split) and (rr is None or role(r['request'])==rr)]
 trans=Counter(); canon=0
 for r in chosen:
  q=role(r['request']); x=choose(a,r['response'],q); y=choose(b,r['response'],q)
  if x!=y:
   trans[f'{x}->{y}']+=1
   canon += ((x==r['response'].get('canonical_action')) != (y==r['response'].get('canonical_action')))
 return {'rows':len(chosen),'actor_action_differences':sum(trans.values()),'canonical_status_changes':canon,'action_transitions':dict(sorted(trans.items()))}
def main():
 invalid=OUT/'report-invalid-raw-counts.json'
 old=OUT/'report.json'
 if old.exists() and not invalid.exists(): shutil.copyfile(old,invalid)
 script=OUT/'audit_compiled_v4.py'; shutil.copyfile(pathlib.Path(__file__),script)
 report={'schema':'compiled-v4-same-label-cross-score-v2','scope':'same completed v4 calibration labels; v3 and v4 role actors compared within each target campaign; normalized local teacher costs only, not game regret','weighting':'equal physical group weighting; each group contributes the mean normalized cost of its completed rows','censored_note':'settled/refused/forced/error rows are excluded from scores and retained in campaign status counts','invalid_prior_report':'report-invalid-raw-counts.json: prior report used raw count regret and is superseded','campaigns':{},'actors':ACTORS,'scores':{},'fit_alignment':{}}
 for key,camp in CAMPAIGNS.items():
  rows,sts=load(camp); report['campaigns'][key]={'path':str(camp.relative_to(ROOT)),'statuses':dict(sts),'rows_complete':len(rows),'manifest_sha256':digest(camp/'manifest.json'),'requests_sha256':digest(camp/'requests.jsonl')}; report['scores'][key]={}
  for split in ('train','development',None):
   sn=split or 'all'; report['scores'][key][sn]={}
   for rr in ('declaring','defending',None):
    rn=rr or 'all'; report['scores'][key][sn][rn]={v:metric(rows,ACTORS[key][v],split,rr) for v in ('v3','v4')}; report['scores'][key][sn][rn]['choice_comparison']=compare(rows,ACTORS[key]['v3'],ACTORS[key]['v4'],split,rr)
  fit=json.loads((ROOT/f'results/compiled-{key}-v4/audit.json').read_text())
  report['fit_alignment'][key]={}
  for split in ('train','development'):
   report['fit_alignment'][key][split]={}
   for rr in ('declaring','defending'):
    got=report['scores'][key][split][rr]['v4']['equal_group_weighted_cost']; exp=fit['roles'][rr]['selected'][split+'_local_cost']; assert got==exp, (key,split,rr,got,exp)
    report['fit_alignment'][key][split][rr]={'cross_score':got,'fit_audit':exp,'matches':True}
 report['script_sha256']=digest(script)
 (OUT/'report.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
 print(json.dumps({'report':str(OUT/'report.json'),'invalid_prior':str(invalid),'script_sha256':report['script_sha256'],'fit_alignment':report['fit_alignment']},indent=2))
 for key in ('c0','c1'):
  a=report['scores'][key]['all']; print(key, 'declaring',a['declaring']['v3']['equal_group_weighted_cost']['decimal'],a['declaring']['v4']['equal_group_weighted_cost']['decimal'],'defending',a['defending']['v3']['equal_group_weighted_cost']['decimal'],a['defending']['v4']['equal_group_weighted_cost']['decimal'],'action_diffs',a['all']['choice_comparison']['actor_action_differences'])
if __name__=='__main__': main()
