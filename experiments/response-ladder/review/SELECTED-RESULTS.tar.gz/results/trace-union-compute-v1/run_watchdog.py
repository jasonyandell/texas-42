from pathlib import Path
import os,subprocess,signal,time,json,hashlib,resource
root=Path('/Users/jason/.codex/worktrees/walt-response-ladder/texas-42/experiments/response-ladder')
out=root/'results/trace-union-compute-v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,data):
 p=out/name;t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(data,indent=2)+'\n');t.replace(p)
def bounded(label,command,env):
 before=resource.getrusage(resource.RUSAGE_CHILDREN);started=time.monotonic();timeout=False
 with (out/(label+'.stdout')).open('w') as stdout,(out/(label+'.stderr')).open('w') as stderr:
  proc=subprocess.Popen(command,cwd=root,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
  try:code=proc.wait(timeout=60)
  except subprocess.TimeoutExpired:
   timeout=True;os.killpg(proc.pid,signal.SIGKILL);code=proc.wait()
 after=resource.getrusage(resource.RUSAGE_CHILDREN)
 result={'label':label,'command':command,'cwd':str(root),'watchdog_seconds':60,'timeout':timeout,'exit_code':code,'wall_seconds':time.monotonic()-started,'user_cpu_seconds':after.ru_utime-before.ru_utime,'system_cpu_seconds':after.ru_stime-before.ru_stime}
 save(label+'.json',result);print(json.dumps(result),flush=True);return result
build=['cargo','build','--offline','--release','--features','gpu','--bin','trace_union_bench']
env=dict(os.environ,RUSTFLAGS='-C target-cpu=native')
assert not (out/'build.json').exists(), 'refuse to overwrite prior build receipt'
r=bounded('build',build,env)
if r['exit_code']!=0:raise SystemExit('build failed or watchdog; inspect retained logs')
binary=root/'target/release/trace_union_bench'
save('build-identity.json',{'git_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'binary_sha256':sha(binary),'rustflags':env['RUSTFLAGS'],'c0_sha256':sha(root/'results/compiled-c0-v3/actor.json'),'c1_sha256':sha(root/'results/compiled-c1-v3/actor.json'),'cargo_lock_sha256':sha(root/'Cargo.lock')})
command=[str(binary),'--output','results/trace-union-compute-v1','--c0','results/compiled-c0-v3/actor.json','--c1','results/compiled-c1-v3/actor.json','--seconds','55','--n','40','--depths','4,5,6,7','--seed','960901','--per-backend-ms','1000']
for cycle in range(1,10):
 r=bounded(f'cycle-{cycle:02}',command,os.environ.copy())
 checkpoint=out/'checkpoint.json'
 if checkpoint.exists():
  c=json.loads(checkpoint.read_text());print(json.dumps({'cycle':cycle,'complete_fixtures':c['complete_fixtures'],'fixture_count':c['fixture_count'],'all_attempted':c['all_attempted'],'identity_verified':c.get('last_session_identity_verified')}),flush=True)
  if c['all_attempted'] and r['exit_code']==0:break
 if r['exit_code']!=0 and not r['timeout']:raise SystemExit('cycle error; no automatic retry of error')
else:raise SystemExit('bounded cycle guard reached with pending fixtures')
print('ALL_FIXTURES_ATTEMPTED',flush=True)
