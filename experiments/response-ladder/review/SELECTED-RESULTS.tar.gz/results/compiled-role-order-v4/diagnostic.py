#!/usr/bin/env python3
"""Offline role/order partition diagnostic for frozen v4 lesson labels.

This module deliberately does not generate labels or choose a runtime actor.
It fits the existing bounded 16-clause grammar on train rows and evaluates
the selected programs on the same target's development rows.
"""

import argparse
from fractions import Fraction
import hashlib
import importlib.util
import json
from itertools import permutations
from pathlib import Path
import shutil
import time


HERE = Path(__file__).resolve().parent
WORKTREE = Path("/Users/jason/.codex/worktrees/walt-response-ladder/texas-42/experiments/response-ladder")
FIT_PATH = WORKTREE / "tools" / "fit_compiled.py"
REF_PATH = WORKTREE / "tools" / "reference_referee.py"


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


fit = load_module("fit_compiled_v4_capacity", FIT_PATH)
referee = load_module("reference_referee_v4_capacity", REF_PATH)

CLAUSES = 16
PARTITIONS = ("offset", "lead_follow")


def replay_offset(request):
    """Replay public actor order and completed-trick winners independently."""
    rotation = int(request["bidder"] % 2 == 0)
    leader = (request["bidder"] + rotation) % 4
    partial = []
    seen = set()
    for index, pair in enumerate(request.get("history", [])):
        if not isinstance(pair, list) or len(pair) != 2:
            raise ValueError(f"history item {index} is not [actor,tile]")
        actor, tile = pair
        if type(actor) is not int or type(tile) is not int or actor not in range(4) or tile not in range(28):
            raise ValueError(f"history item {index} has invalid actor or tile")
        internal = (actor + rotation) % 4
        expected = (leader + len(partial)) % 4
        if internal != expected or tile in seen:
            raise ValueError(f"history item {index} violates actor order or repeats a tile")
        seen.add(tile)
        partial.append((internal, tile))
        if len(partial) == 4:
            leader = referee.winner(partial, request["decl"])
            partial = []
    if len(partial) > 3:
        raise ValueError("replay left an invalid partial trick")
    viewer = (request["seat"] + rotation) % 4
    if (leader + len(partial)) % 4 != viewer:
        raise ValueError("history does not end at normalized requested viewer")
    return len(partial)


def row_partition(row, kind):
    offset = replay_offset(row["request"])
    if kind == "offset":
        return str(offset)
    if kind == "lead_follow":
        return "lead" if offset == 0 else "follow"
    raise ValueError(kind)


def rational_fraction(value):
    return Fraction(value["numerator"], value["denominator"])


def as_rational(value):
    return fit.rational(value.numerator, value.denominator)


def role_rows(rows, role):
    return [row for row in rows if fit.row_role(row) == role]


def selected_with_global_weights(role_train, partition_rows):
    """Select on a partition using the parent role's group weights.

    The denominator and per-row weights are computed once over all role-train
    rows. A partition therefore cannot receive a fresh equal-bin normalization.
    """
    weighted, denominator = fit.weights(role_train)
    allowed = {row["id"] for row in partition_rows}
    filtered = [(row, weight) for row, weight in weighted if row["id"] in allowed]
    candidates = []
    for length in range(4):
        for clauses in permutations(range(CLAUSES), length):
            score = sum(
                weight * row["costs"][fit.choose(row, clauses)]
                for row, weight in filtered
            )
            candidates.append((score, length, clauses))
    return min(candidates), weighted, denominator


def cost_for_partitioned(row, actors, role_only):
    actor = actors.get((fit.row_role(row), row["partition"]))
    if actor is None:
        actor = role_only[fit.row_role(row)]
    return row["costs"][fit.choose(row, actor)]


def fit_target(rows, kind):
    train = [row for row in rows if row["split"] == "train"]
    development = [row for row in rows if row["split"] == "development"]
    role_only = {}
    role_reports = {}
    partition_actors = {}
    partition_reports = {}
    for role in ("declaring", "defending"):
        role_train = role_rows(train, role)
        role_dev = role_rows(development, role)
        best, train_weighted, train_denominator = selected_with_global_weights(role_train, role_train)
        role_only[role] = best[2]
        role_reports[role] = {
            "clauses": list(best[2]),
            "train_rows": len(role_train),
            "development_rows": len(role_dev),
            "train_groups": len({row["group"] for row in role_train}),
            "development_groups": len({row["group"] for row in role_dev}),
            "train_cost": as_rational(Fraction(best[0], train_denominator)),
            "development_cost": as_rational(Fraction(
                fit.score(fit.weights(role_dev)[0], best[2]), fit.weights(role_dev)[1]
            )),
        }
        expected_partitions = (('0', '1', '2', '3') if kind == "offset" else ('lead', 'follow'))
        for partition in expected_partitions:
            part_train = [row for row in role_train if row["partition"] == partition]
            part_dev = [row for row in role_dev if row["partition"] == partition]
            if not part_train:
                partition_reports[(role, partition)] = {"status": "missing_train", "fallback": list(best[2])}
                continue
            selected, weighted, denominator = selected_with_global_weights(role_train, part_train)
            clauses = selected[2]
            partition_actors[(role, partition)] = clauses
            dev_cost = sum(
                weight * row["costs"][fit.choose(row, clauses)]
                for row, weight in fit.weights(role_dev)[0] if row["id"] in {item["id"] for item in part_dev}
            )
            dev_denominator = fit.weights(role_dev)[1] if role_dev else 1
            partition_reports[(role, partition)] = {
                "status": "fit",
                "clauses": list(clauses),
                "train_rows": len(part_train),
                "development_rows": len(part_dev),
                "train_groups": len({row["group"] for row in part_train}),
                "development_groups": len({row["group"] for row in part_dev}),
                "train_cost_contribution": as_rational(Fraction(selected[0], denominator)),
                "development_cost_contribution": (
                    as_rational(Fraction(dev_cost, dev_denominator)) if part_dev else None
                ),
                "development_status": "scored" if part_dev else "missing_development",
            }

    def global_cost(split_rows, chooser):
        by_role = {}
        for role in ("declaring", "defending"):
            local = role_rows(split_rows, role)
            weighted, denominator = fit.weights(local)
            value = sum(weight * chooser(row) for row, weight in weighted)
            by_role[role] = as_rational(Fraction(value, denominator))
        mean = (rational_fraction(by_role["declaring"]) + rational_fraction(by_role["defending"])) / 2
        return {"by_role": by_role, "role_mean": as_rational(mean)}

    baseline_train = global_cost(train, lambda row: row["costs"][fit.choose(row, role_only[fit.row_role(row)])])
    baseline_dev = global_cost(development, lambda row: row["costs"][fit.choose(row, role_only[fit.row_role(row)])])
    partition_train = global_cost(train, lambda row: row["costs"][fit.choose(row, partition_actors.get((fit.row_role(row), row["partition"]), role_only[fit.row_role(row)]))])
    partition_dev = global_cost(development, lambda row: row["costs"][fit.choose(row, partition_actors.get((fit.row_role(row), row["partition"]), role_only[fit.row_role(row)]))])
    paired = {}
    for split_name, split_rows in (("train", train), ("development", development)):
        by_role = {}
        for role in ("declaring", "defending"):
            local = role_rows(split_rows, role)
            weighted, denominator = fit.weights(local)
            old = sum(weight * row["costs"][fit.choose(row, role_only[role])] for row, weight in weighted)
            new = sum(weight * row["costs"][fit.choose(row, partition_actors.get((role, row["partition"]), role_only[role]))] for row, weight in weighted)
            by_role[role] = as_rational(Fraction(new - old, denominator))
        mean = (rational_fraction(by_role["declaring"]) + rational_fraction(by_role["defending"])) / 2
        paired[split_name] = {"partition_minus_role_by_role": by_role, "role_mean_difference": as_rational(mean)}

    return {
        "partition_kind": kind,
        "roles": role_reports,
        "partitions": {f"{role}:{partition}": report for (role, partition), report in partition_reports.items()},
        "role_only_cost": {"train": baseline_train, "development": baseline_dev},
        "partitioned_cost": {"train": partition_train, "development": partition_dev},
        "same_target_paired_difference": paired,
        "selection": "Training only; role-global physical-group weights; missing partitions inherit the role-only actor.",
    }


def load_target(path):
    rows, statuses, sources = fit.read_rows(Path(path))
    for row in rows:
        row["partition"] = None
    return rows, statuses, sources


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def assert_unit_cost(value, label):
    fraction = rational_fraction(value)
    if not (Fraction(0) <= fraction <= Fraction(1)):
        raise AssertionError(f"{label} outside [0,1]: {value}")


def assert_role_baseline(report, audit, target):
    """Pin the diagnostic's unpartitioned fit to the authoritative v4 audit."""
    for role in ("declaring", "defending"):
        got = report["roles"][role]
        want = audit["roles"][role]["selected"]
        if got["clauses"] != want["clauses"]:
            raise AssertionError(f"{target} {role} baseline clauses differ from audit")
        if rational_fraction(got["train_cost"]) != rational_fraction(want["train_local_cost"]):
            raise AssertionError(f"{target} {role} baseline train cost differs from audit")
        if rational_fraction(got["development_cost"]) != rational_fraction(want["development_local_cost"]):
            raise AssertionError(f"{target} {role} baseline development cost differs from audit")


def assert_report_costs(report, label):
    for role, value in report["roles"].items():
        assert_unit_cost(value["train_cost"], f"{label} {role} train")
        assert_unit_cost(value["development_cost"], f"{label} {role} development")
    for key, value in report["partitions"].items():
        for cost_key in ("train_cost_contribution", "development_cost_contribution"):
            if value.get(cost_key) is not None:
                assert_unit_cost(value[cost_key], f"{label} {key} {cost_key}")
    for split, value in report["role_only_cost"].items():
        for role, cost in value["by_role"].items():
            assert_unit_cost(cost, f"{label} role_only {split} {role}")
        assert_unit_cost(value["role_mean"], f"{label} role_only {split} mean")
    for split, value in report["partitioned_cost"].items():
        for role, cost in value["by_role"].items():
            assert_unit_cost(cost, f"{label} partitioned {split} {role}")
        assert_unit_cost(value["role_mean"], f"{label} partitioned {split} mean")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--t0", required=True, type=Path)
    parser.add_argument("--t1", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--c0-audit", type=Path, default=WORKTREE / "results" / "compiled-c0-v4" / "audit.json")
    parser.add_argument("--c1-audit", type=Path, default=WORKTREE / "results" / "compiled-c1-v4" / "audit.json")
    args = parser.parse_args(argv)
    started = time.monotonic()
    target_rows = {}
    target_sources = {}
    for name, campaign in (("t0", args.t0), ("t1", args.t1)):
        rows, statuses, sources = load_target(campaign)
        target_rows[name] = rows
        target_sources[name] = {"statuses": dict(statuses), "lesson_hashes": sources}

    t0_identity = {(row["id"], row["group"], row["split"], json.dumps(row["request"], sort_keys=True)) for row in target_rows["t0"]}
    t1_identity = {(row["id"], row["group"], row["split"], json.dumps(row["request"], sort_keys=True)) for row in target_rows["t1"]}
    if t0_identity != t1_identity:
        raise ValueError("T0/T1 campaigns do not share the same physical request set and splits")

    audits = {"t0": json.loads(args.c0_audit.read_text()), "t1": json.loads(args.c1_audit.read_text())}
    results = {}
    for name in ("t0", "t1"):
        rows = target_rows[name]
        for kind in PARTITIONS:
            for row in rows:
                row["partition"] = row_partition(row, kind)
            report = fit_target(rows, kind)
            assert_role_baseline(report, audits[name], name)
            assert_report_costs(report, f"{name}:{kind}")
            report["source_statuses"] = target_sources[name]["statuses"]
            report["source_lesson_hashes"] = target_sources[name]["lesson_hashes"]
            report["complete_rows"] = len(rows)
            results[f"{name}:{kind}"] = report
    campaign_hashes = {}
    for name, campaign in (("t0", args.t0), ("t1", args.t1)):
        campaign_hashes[name] = {
            filename: sha256(campaign / filename)
            for filename in ("manifest.json", "requests.jsonl", "teacher-config.json")
        }
    protocol_path = Path("/tmp/walt-v4-role-order-capacity-protocol.md")
    result = {
        "schema": "compiled-v4-role-order-capacity-diagnostic-v1",
        "scope": "Frozen v4 T0/T1 finite teacher costs; no runtime actor, strength, or H2H claim.",
        "targets": results,
        "source_hashes": {
            "fit_compiled.py": sha256(FIT_PATH),
            "reference_referee.py": sha256(REF_PATH),
            "diagnostic_script.py": sha256(Path(__file__)),
            "protocol.md": sha256(protocol_path),
            "campaign_manifests": campaign_hashes,
        },
        "elapsed_seconds": time.monotonic() - started,
    }
    args.output.mkdir(parents=True, exist_ok=False)
    shutil.copy2(Path(__file__), args.output / "diagnostic.py")
    shutil.copy2(protocol_path, args.output / "protocol.md")
    (args.output / "diagnostic.json").write_text(json.dumps(result, sort_keys=True, indent=2) + "\n")
    print(json.dumps({"schema": result["schema"], "targets": list(results), "elapsed_seconds": result["elapsed_seconds"]}, indent=2))


if __name__ == "__main__":
    main()
