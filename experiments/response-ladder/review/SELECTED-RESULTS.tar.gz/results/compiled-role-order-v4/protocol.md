# v4 role/order capacity diagnostic

This is a bounded offline calibration diagnostic. It does not generate labels,
change runtime actors, or make a playing-strength claim.

## Frozen inputs

- T0 campaign: `results/compiled-calibration-v4`
- T1 campaign: `results/compiled-t1-calibration-v4`
- Authoritative role-only audits: `results/compiled-c0-v4/audit.json` and
  `results/compiled-c1-v4/audit.json`; the run rejects any baseline clause or
  exact rational train/development cost mismatch before it is reported.
- Both campaigns must contain the same request IDs, physical groups, request
  bytes, and train/development assignment. The script rejects any mismatch.
- Complete rows are read through `tools/fit_compiled.py::read_rows`; incomplete
  rows remain in status counts and are excluded from fitting exactly as in the
  current fitter.
- The two targets remain separate. T0 and T1 costs are never pooled or compared
  as if they were the same target.

## Question

Does the v4 three-clause 16-predicate role actor lose local development cost
because one policy must cover materially different public trick positions?

## Comparisons

For each target independently:

1. Fit the current role-only declaring and defending actors.
2. Fit role-by-public-trick-offset actors for offsets 0, 1, 2, and 3.
3. Fit role-by-leading/following actors, with `lead` for offset 0 and
   `follow` for offsets 1 through 3.

Every fit enumerates the existing 3,617 ordered programs of zero through three
distinct clauses from the 16-clause vocabulary. Selection uses training rows
only, with the same physical-group normalization used by the role-only fitter.
Development rows never select a program.

The script derives trick offset by replaying each request's explicit
`[actor,tile]` history with the independent Python referee rules. It checks
normalized actor order, repeated tiles, and completed-trick winners. It does not
use `len(history) % 4` and reads no hidden hands.

## Weighting and missing bins

Weights are computed once over all training rows in a role, before partitioning.
Thus a partition cannot receive a new equal-bin normalization. Development
costs use the corresponding all-role development weights. The reported overall
role mean is the equal mean of the declaring and defending role costs, matching
the existing v4 role audit.

A partition with no training rows inherits its role-only actor and is marked
`missing_train`. A partition with training rows but no development rows is fit
and marked `missing_development`; it contributes no development evidence.
Counts of rows and physical groups are reported for every role/partition.

## Paired result

For every target and split, report the exact weighted difference

`partitioned actor cost - role-only actor cost`

by role and as the equal role mean. Negative values are local-cost reductions
on the same target labels; they are not whole-game regret or H2H evidence.

## Execution, after GO

```text
python3 /tmp/walt-v4-role-order-capacity.py \
  --t0 results/compiled-calibration-v4 \
  --t1 results/compiled-t1-calibration-v4 \
  --output /tmp/walt-v4-role-order-capacity-report
```

The expected work is 32 bounded role/partition selection units over 3,617
candidates each, with no leave-one-group-out pass. The output directory contains
the single `diagnostic.json`, the exact script and protocol copies, and SHA-256
hashes for the fitter, referee, script, protocol, and campaign manifests. Do
not promote a partitioned actor from this report;
any runtime control requires a separately named artifact, Scheme/GPU contracts,
and a fresh outcome protocol.
