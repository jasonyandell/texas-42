# Preserved setup failure

Cycle 1 completed 77 games / 38 full pairs; a healthy partial checkpoint remains.
Cycle 2 exited1 before worker start because a manually retyped C1 path did not
exist. The harness refused it during input identity validation. No failed game
was played, no original game was retried, and panel B did not start.

This original strict confirmation cannot pass with incomplete coverage. Its
receipts and partial checkpoint remain unchanged. New independent C/D panels
are frozen in ../compiled-v5-confirmation-r2/protocol.json with identical
player, budgets and inference, and a manifest-driven cycle runner.
