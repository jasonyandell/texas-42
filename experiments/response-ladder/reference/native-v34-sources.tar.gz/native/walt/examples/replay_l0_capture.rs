//! Replay naturally captured L0 Dice jobs without the surrounding whole game.
//!
//! `cargo run -p walt --example replay_l0_capture --features natural-job-capture -- \
//!   /path/to/capture.bin [repetitions] [--oracle]`
//!
//! The stored arm times the scalar prepared search. The regenerated arm times
//! exact Voidless resampling, fixed 288-byte packet construction, and search
//! while reusing each job's prebuilt Shared and Key. Packet comparison and
//! choice checks run outside both timers.
//! `--oracle` evaluates every root action exactly after the timed arms.

use std::time::Instant;
use walt::solver::{prepare_replay_batch, read_capture_file, CapturedJob, ReplayOutcome};

#[derive(Default)]
struct Totals {
    jobs: u64,
    stored_ns: u128,
    regenerated_ns: u128,
    recorded_prepare_ns: u128,
    recorded_search_ns: u128,
    recorded_nodes: u128,
    replay_nodes: u128,
    live_stored_node_mismatches: u64,
    live_regenerated_node_mismatches: u64,
}

fn nanoseconds(started: Instant) -> u128 {
    started.elapsed().as_nanos()
}

fn checked(
    job: &CapturedJob,
    outcome: ReplayOutcome,
    kind: &str,
    index: usize,
) -> Result<(), String> {
    if outcome.choice != job.expected_choice() {
        return Err(format!(
            "job {index}: {kind} chose tile {}, live job chose {}",
            outcome.choice,
            job.expected_choice()
        ));
    }
    Ok(())
}

fn main() -> Result<(), String> {
    let mut args = std::env::args().skip(1);
    let path = args
        .next()
        .ok_or_else(|| "usage: replay_l0_capture CAPTURE_FILE [REPETITIONS]".to_string())?;
    let mut repetitions = 1usize;
    let mut repetitions_given = false;
    let mut oracle = false;
    let mut dump_actions = false;
    for arg in args {
        if arg == "--oracle" && !oracle {
            oracle = true;
        } else if arg == "--dump-actions" && !dump_actions {
            dump_actions = true;
        } else if !repetitions_given {
            repetitions = arg.parse::<usize>().map_err(|_| {
                "usage: replay_l0_capture CAPTURE_FILE [REPETITIONS] [--oracle]".to_string()
            })?;
            repetitions_given = true;
        } else {
            return Err("usage: replay_l0_capture CAPTURE_FILE [REPETITIONS] [--oracle]".into());
        }
    }
    if repetitions == 0 {
        return Err("repetitions must be positive".into());
    }

    let jobs = read_capture_file(path).map_err(|error| error.to_string())?;
    if jobs.is_empty() {
        return Err("capture contains no selected L0 jobs".into());
    }
    let synthetic_jobs = jobs.iter().filter(|job| job.is_synthetic()).count();
    if synthetic_jobs != 0 {
        eprintln!("synthetic_coverage_jobs={synthetic_jobs}; timings are not a natural workload distribution");
    }
    // Shared is pooled by compatible game context and every Key is built
    // once, outside both timed arms, as in a live game.
    let stored = prepare_replay_batch(&jobs)?;
    let mut by_depth: [Totals; 8] = std::array::from_fn(|_| Totals::default());

    for repetition in 0..repetitions {
        for (index, (job, prepared)) in jobs.iter().zip(&stored).enumerate() {
            let bucket = &mut by_depth[usize::from(job.depth())];
            let run_stored = || -> Result<_, String> {
                let started = Instant::now();
                let result = prepared.search()?;
                Ok((result, nanoseconds(started)))
            };
            let run_regenerated = || -> Result<_, String> {
                let started = Instant::now();
                let (result, packet) = prepared.regenerate_packet_and_search()?;
                Ok((result, packet, nanoseconds(started)))
            };
            // Half the corpus sees each arm first; repeated passes reverse
            // the order to reduce cache-warm and branch-predictor bias.
            let (stored_result, stored_ns, regenerated_result, packet, regenerated_ns) =
                if (index + repetition) & 1 == 0 {
                    let (a, an) = run_stored()?;
                    let (b, packet, bn) = run_regenerated()?;
                    (a, an, b, packet, bn)
                } else {
                    let (b, packet, bn) = run_regenerated()?;
                    let (a, an) = run_stored()?;
                    (a, an, b, packet, bn)
                };
            bucket.stored_ns += stored_ns;
            bucket.regenerated_ns += regenerated_ns;
            checked(job, stored_result, "stored search", index)?;
            if !prepared.matches_captured_packet(&packet) {
                return Err(format!(
                    "job {index}: regenerated packet differs from original IDs/tapes/RNG"
                ));
            }
            checked(job, regenerated_result, "regenerated search", index)?;
            if stored_result.choice != regenerated_result.choice {
                return Err(format!(
                    "job {index}: stored and regenerated choices differ: \
                     {stored_result:?} versus {regenerated_result:?}"
                ));
            }
            if repetition == 0 && stored_result.nodes != job.recorded_nodes() {
                bucket.live_stored_node_mismatches += 1;
                eprintln!(
                    "node_mismatch,job={index},depth={},arm=stored,live={},replay={}",
                    job.depth(),
                    job.recorded_nodes(),
                    stored_result.nodes
                );
            }
            if repetition == 0 && regenerated_result.nodes != job.recorded_nodes() {
                bucket.live_regenerated_node_mismatches += 1;
                eprintln!(
                    "node_mismatch,job={index},depth={},arm=regenerated,live={},replay={}",
                    job.depth(),
                    job.recorded_nodes(),
                    regenerated_result.nodes
                );
            }
            bucket.jobs += 1;
            bucket.recorded_prepare_ns += u128::from(job.recorded_prepare_ns());
            bucket.recorded_search_ns += u128::from(job.recorded_search_ns());
            bucket.recorded_nodes += u128::from(job.recorded_nodes());
            bucket.replay_nodes += u128::from(stored_result.nodes);
        }
    }

    println!(
        "depth,jobs,stored_search_ns,scalar_prepare_packet_search_ns,\
         recorded_prepare_ns_sum_approx,recorded_search_ns_sum_approx,\
         recorded_nodes,replay_nodes,live_stored_node_mismatches,\
         live_regenerated_node_mismatches"
    );
    for (depth, totals) in by_depth.iter().enumerate().skip(1) {
        if totals.jobs == 0 {
            continue;
        }
        println!(
            "{depth},{},{},{},{},{},{},{},{},{}",
            totals.jobs,
            totals.stored_ns,
            totals.regenerated_ns,
            totals.recorded_prepare_ns,
            totals.recorded_search_ns,
            totals.recorded_nodes,
            totals.replay_nodes,
            totals.live_stored_node_mismatches,
            totals.live_regenerated_node_mismatches
        );
    }
    if oracle || dump_actions {
        let mut checked_actions = 0u64;
        for (index, (job, prepared)) in jobs.iter().zip(&stored).enumerate() {
            let counts = prepared.full_action_counts()?;
            if dump_actions {
                eprintln!("action_counts,job={index},values={counts:?}");
            }
            let mut best = counts[0];
            for &(tile, successes) in &counts[1..] {
                if (successes > best.1 && job.maximize()) || (successes < best.1 && !job.maximize())
                {
                    best = (tile, successes);
                }
            }
            if best.0 != job.expected_choice() {
                return Err(format!(
                    "job {index}: exact full-action oracle chose {}, live chose {}",
                    best.0,
                    job.expected_choice()
                ));
            }
            checked_actions += counts.len() as u64;
        }
        eprintln!(
            "exact_action_oracle,jobs={},actions={checked_actions}",
            jobs.len()
        );
    }
    Ok(())
}
