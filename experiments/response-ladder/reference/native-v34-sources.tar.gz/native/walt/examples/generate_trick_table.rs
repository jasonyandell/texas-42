//! Regenerate the completed-trick lookup from the canonical rule algebra.
//! `cargo run -p walt --example generate_trick_table -- --check` verifies the
//! checked-in artifact without changing it.

use std::path::PathBuf;
use walt::rules::{Decl, Domino};

const SIDE: usize = 28;
const PER_DECL: usize = SIDE * SIDE * SIDE * SIDE;
const TOTAL: usize = 9 * PER_DECL;

fn table(packed: bool) -> Vec<u8> {
    let mut bytes = vec![0u8; if packed { 9 << 20 } else { TOTAL }];
    for (di, decl) in Decl::ALL.into_iter().enumerate() {
        for a in 0..SIDE {
            let led = decl.led_context(Domino::ALL[a]);
            for b in 0..SIDE {
                for c in 0..SIDE {
                    for d in 0..SIDE {
                        let tiles = [a, b, c, d].map(|i| Domino::ALL[i]);
                        let mut best = decl.trick_key(tiles[0], led);
                        let mut winner = 0u8;
                        for (i, tile) in tiles.iter().enumerate().skip(1) {
                            let key = decl.trick_key(*tile, led);
                            if key > best {
                                best = key;
                                winner = i as u8;
                            }
                        }
                        let points = 1 + tiles.iter().map(|tile| tile.count()).sum::<u32>();
                        assert!(points < 64);
                        let index = if packed {
                            (di << 20) | a | (b << 5) | (c << 10) | (d << 15)
                        } else {
                            di * PER_DECL + (((a * SIDE + b) * SIDE + c) * SIDE + d)
                        };
                        bytes[index] = ((points as u8) << 2) | winner;
                    }
                }
            }
        }
    }
    bytes
}

// Two-byte little-endian records; sentinel-prefixed packed tiles make partial
// lengths disjoint while allowing a direct 16-bit lookup key.
fn partial_table() -> Vec<u8> {
    let mut bytes = vec![0u8; 9 * (1 << 16) * 2];
    for (di, decl) in Decl::ALL.into_iter().enumerate() {
        for len in 1..=3u32 {
            for dense in 0..SIDE.pow(len) {
                let mut rest = dense;
                let mut tiles = [0usize; 3];
                let mut packed = 0u32;
                for i in 0..len as usize {
                    tiles[i] = rest % SIDE;
                    rest /= SIDE;
                    packed |= (tiles[i] as u32) << (5 * i);
                }
                let led = decl.led_context(Domino::ALL[tiles[0]]);
                let mut winner = 0;
                let mut points = 1;
                for i in 0..len as usize {
                    points += Domino::ALL[tiles[i]].count();
                    if decl.trick_key(Domino::ALL[tiles[i]], led)
                        > decl.trick_key(Domino::ALL[tiles[winner]], led) {
                        winner = i;
                    }
                }
                assert!(points < 32);
                let record = (winner as u16) | ((points as u16) << 2)
                    | ((tiles[winner] as u16) << 7) | ((led.index() as u16) << 12);
                let key = ((1 << (5 * len)) | packed) as usize;
                let index = ((di << 16) | key) * 2;
                bytes[index..index + 2].copy_from_slice(&record.to_le_bytes());
            }
        }
    }
    bytes
}

fn main() {
    let args = std::env::args().skip(1).collect::<Vec<_>>();
    let packed = args.iter().any(|arg| arg == "--packed");
    let partial = args.iter().any(|arg| arg == "--partial");
    assert!(!(packed && partial), "choose either --packed or --partial");
    let output = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join(if partial { "src/solver/compact_dice/partial_payoff_table.bin" }
            else if packed { "src/solver/compact_dice/packed_trick_table.bin" }
            else { "src/solver/compact_dice/trick_table.bin" });
    let generated = if partial { partial_table() } else { table(packed) };
    if args.iter().any(|arg| arg == "--check") {
        let existing = std::fs::read(&output).expect("read checked-in trick table");
        assert_eq!(existing, generated, "trick table differs from canonical rules");
        println!("verified {} bytes at {}", generated.len(), output.display());
    } else {
        std::fs::write(&output, &generated).expect("write trick table");
        println!("wrote {} bytes to {}", generated.len(), output.display());
    }
}
