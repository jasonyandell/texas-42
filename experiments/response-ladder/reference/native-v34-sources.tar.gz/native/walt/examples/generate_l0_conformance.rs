//! Write synthetic L0 Dice conformance inputs in the live capture format.
//!
//! `cargo run -p walt --example generate_l0_conformance \
//!   --features natural-job-capture -- synthetic-l0-conformance.bin`
//!
//! These roots come from lawful shuffled deals, then use the real Voidless
//! sampler and pi seed formula. They cover declarations, depths, partial
//! tricks, and sample counts uniformly by design. They are **not** captured
//! gameplay jobs and must not be used as a performance distribution.

use walt::solver::generate_l0_conformance_file;

fn main() -> Result<(), String> {
    let mut args = std::env::args().skip(1);
    let path = args
        .next()
        .ok_or_else(|| "usage: generate_l0_conformance synthetic-OUTPUT.bin".to_string())?;
    if args.next().is_some() {
        return Err("usage: generate_l0_conformance synthetic-OUTPUT.bin".into());
    }
    let count = generate_l0_conformance_file(&path)?;
    println!(
        "wrote {count} SYNTHETIC conformance jobs to {path}; coverage only, not a workload distribution"
    );
    Ok(())
}
