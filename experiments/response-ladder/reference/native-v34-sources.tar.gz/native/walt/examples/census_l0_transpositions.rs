//! Census exact repeated compact states within naturally captured L0 jobs.
//!
//! `cargo run -p walt --release --example census_l0_transpositions \
//!   --features transposition-census -- CAPTURE.bin [CAPTURE2.bin ...]`
//! Optional `--min-depth=4` and `--max-jobs=10000` bound a survey. This is
//! instrumentation, not a memoization implementation or a timing benchmark.

use walt::solver::{prepare_replay_batch, read_capture_file, with_census, CensusStats};

#[derive(Default)]
struct Totals {
    jobs: u64,
    captured_nodes: u64,
    replay_nodes: u64,
    node_mismatches: u64,
    stats: CensusStats,
}

impl Totals {
    fn add(&mut self, captured_nodes: u64, replay_nodes: u64, census: CensusStats) {
        self.jobs += 1;
        self.captured_nodes += captured_nodes;
        self.replay_nodes += replay_nodes;
        self.node_mismatches += u64::from(captured_nodes != replay_nodes);
        self.stats.visits += census.visits;
        self.stats.unique_states += census.unique_states;
        self.stats.repeated_unique_states += census.repeated_unique_states;
        self.stats.duplicate_visits += census.duplicate_visits;
        self.stats.exact_after_exact += census.exact_after_exact;
        self.stats.window_after_exact += census.window_after_exact;
        self.stats.exact_after_window += census.exact_after_window;
        self.stats.window_after_window += census.window_after_window;
        self.stats.optimistic_saved_nodes += census.optimistic_saved_nodes;
        self.stats.disjoint_duplicate_subtrees += census.disjoint_duplicate_subtrees;
        self.stats.largest_duplicate_subtree = self
            .stats
            .largest_duplicate_subtree
            .max(census.largest_duplicate_subtree);
    }
}

fn main() -> Result<(), String> {
    let mut paths = Vec::new();
    let mut min_depth = 2u8;
    let mut max_jobs = usize::MAX;
    for arg in std::env::args().skip(1) {
        if let Some(value) = arg.strip_prefix("--min-depth=") {
            min_depth = value.parse().map_err(|_| "invalid min depth".to_string())?;
        } else if let Some(value) = arg.strip_prefix("--max-jobs=") {
            max_jobs = value.parse().map_err(|_| "invalid max jobs".to_string())?;
        } else if arg.starts_with("--") {
            return Err(format!("unknown option: {arg}"));
        } else {
            paths.push(arg);
        }
    }
    if paths.is_empty() || !(2..=7).contains(&min_depth) || max_jobs == 0 {
        return Err(
            "usage: census_l0_transpositions [--min-depth=2..7] [--max-jobs=N] CAPTURE.bin ..."
                .into(),
        );
    }
    let mut by_depth: [Totals; 8] = std::array::from_fn(|_| Totals::default());
    let mut processed = 0usize;
    for path in paths {
        if processed == max_jobs {
            break;
        }
        let mut jobs = read_capture_file(&path).map_err(|error| format!("{path}: {error}"))?;
        jobs.retain(|job| !job.is_synthetic() && job.depth() >= min_depth);
        let replay = prepare_replay_batch(&jobs)?;
        for (index, (job, prepared)) in jobs.iter().zip(replay.iter()).enumerate() {
            if processed == max_jobs {
                break;
            }
            let (outcome, census) = with_census(|| prepared.search());
            let outcome = outcome?;
            if outcome.choice != job.expected_choice() {
                return Err(format!(
                    "{path} job {index}: replay chose {}, capture chose {}",
                    outcome.choice,
                    job.expected_choice()
                ));
            }
            if census.visits != outcome.nodes {
                return Err(format!(
                    "{path} job {index}: hook coverage {} != replay nodes {}",
                    census.visits, outcome.nodes
                ));
            }
            by_depth[usize::from(job.depth())].add(job.recorded_nodes(), outcome.nodes, census);
            processed += 1;
        }
    }
    if processed == 0 {
        return Err("no natural captured jobs met the depth filter".into());
    }
    println!(
        "depth,jobs,captured_nodes,replay_nodes,node_mismatches,unique_states,\
         repeated_unique_states,duplicate_visits,exact_after_exact,window_after_exact,\
         exact_after_window,window_after_window,disjoint_duplicate_subtrees,\
         optimistic_saved_nodes,largest_duplicate_subtree,saved_upper_basis_points"
    );
    for (depth, total) in by_depth.iter().enumerate().skip(2) {
        if total.jobs == 0 {
            continue;
        }
        let s = &total.stats;
        let basis_points = if total.replay_nodes == 0 {
            0
        } else {
            u128::from(s.optimistic_saved_nodes) * 10_000 / u128::from(total.replay_nodes)
        };
        println!(
            "{depth},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{}",
            total.jobs,
            total.captured_nodes,
            total.replay_nodes,
            total.node_mismatches,
            s.unique_states,
            s.repeated_unique_states,
            s.duplicate_visits,
            s.exact_after_exact,
            s.window_after_exact,
            s.exact_after_window,
            s.window_after_window,
            s.disjoint_duplicate_subtrees,
            s.optimistic_saved_nodes,
            s.largest_duplicate_subtree,
            basis_points,
        );
    }
    Ok(())
}
