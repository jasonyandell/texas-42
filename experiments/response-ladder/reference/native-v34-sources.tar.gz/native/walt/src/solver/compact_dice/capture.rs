//! Opt-in native capture of actual prepared L0 Dice jobs.
//!
//! No sampler state is reconstructed while recording. The original sample-ID
//! order, all eight world slots, and all eight Dice tapes are written as a
//! fixed little-endian record. Replayer regeneration is an independent check.

#[cfg(not(target_os = "macos"))]
compile_error!("natural-job-capture is a native macOS profiling feature");

use super::{choose_fixed, mix, prepare_voidless, Search, SplitMix64, State, RULES};
use crate::rules::{legal_plays, Decl, Domino, DominoSet, Seat, Trick};
use crate::solver::{record_hash, Deadline, Key, Shared, FULL_MASK, INNER_SEED};
use std::collections::HashMap;
use std::fs::{self, File, OpenOptions};
use std::io::{self, Write};
use std::path::Path;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::{Arc, Mutex, OnceLock};
use std::time::{Duration, Instant};

const MAGIC: &[u8; 8] = b"W42L0CAP";
const VERSION: u32 = 1;
const HEADER_BYTES: usize = 16;
pub const RECORD_BYTES: usize = 288;
const META_BYTES: usize = 96;
const WORLD_BYTES: usize = 8 * 4 * 4;
const SAMPLE_MASK: u64 = 127; // one deterministic request hash in 128
const MAX_RECORDS: usize = 16_384;

struct Sink {
    file: Mutex<File>,
    count: AtomicUsize,
}

static SINK: OnceLock<Option<Sink>> = OnceLock::new();

fn sink() -> Option<&'static Sink> {
    SINK.get_or_init(|| {
        let path = std::env::var_os("WALT_L0_CAPTURE_PATH")?;
        let mut file = OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&path)
            .unwrap_or_else(|error| panic!("cannot create unique L0 capture {:?}: {error}", path));
        file.write_all(MAGIC).expect("write L0 capture magic");
        file.write_all(&VERSION.to_le_bytes())
            .expect("write L0 capture version");
        file.write_all(&(RECORD_BYTES as u32).to_le_bytes())
            .expect("write L0 capture record size");
        Some(Sink {
            file: Mutex::new(file),
            count: AtomicUsize::new(0),
        })
    })
    .as_ref()
}

/// A timer exists only for a selected request when an explicit output path is
/// set and the process cap has not been reached. Calling this does not draw RNG.
pub(super) struct CaptureToken {
    request_seed: u64,
    preparation_started: Instant,
    prepare_ns: u64,
    search_started: Option<Instant>,
}

impl CaptureToken {
    pub(super) fn begin(request_seed: u64) -> Option<Self> {
        if mix(request_seed) & SAMPLE_MASK != 0 {
            return None;
        }
        let destination = sink()?;
        if destination.count.load(Ordering::Relaxed) >= MAX_RECORDS {
            return None;
        }
        Some(Self {
            request_seed,
            preparation_started: Instant::now(),
            prepare_ns: 0,
            search_started: None,
        })
    }

    pub(super) fn begin_search(&mut self) {
        self.prepare_ns = duration_ns(self.preparation_started.elapsed());
        self.search_started = Some(Instant::now());
    }

    #[allow(clippy::too_many_arguments)]
    pub(super) fn finish(
        self,
        search: &Search<'_>,
        root: State,
        legal_mask: u32,
        sizes: [usize; 4],
        post_prepare_rng: u64,
        choice: Option<u8>,
    ) {
        let Some(choice) = choice else { return };
        let search_ns = duration_ns(
            self.search_started
                .expect("capture search timer was started")
                .elapsed(),
        );
        let mut worlds = [[0u32; 4]; 8];
        let mut seeds = [0u64; 8];
        let n = search.worlds.len();
        worlds[..n].copy_from_slice(search.worlds);
        seeds[..n].copy_from_slice(search.seeds);
        let remaining = (FULL_MASK & !root.played).count_ones() + u32::from(root.len);
        assert_eq!(remaining % 4, 0);
        let job = CapturedJob {
            request_seed: self.request_seed,
            post_prepare_rng,
            prepare_ns: self.prepare_ns,
            search_ns,
            original_nodes: search.nodes,
            played: root.played,
            plays: root.plays,
            viewer_hand: search.hand,
            legal_mask,
            declaration: declaration_id(search.sh.dcl),
            bid: search.sh.bid,
            viewer: search.viewer,
            maximize: u8::from(search.maximize),
            n: n as u8,
            len: root.len,
            leader: root.leader,
            t1: root.t1,
            t0: root.t0,
            expected_choice: choice,
            depth: (remaining / 4) as u8,
            hand_sizes: sizes.map(|size| u8::try_from(size).expect("hand size fits u8")),
            origin: 0,
            worlds,
            seeds,
        };
        let destination = sink().expect("capture destination remains set");
        if destination.count.load(Ordering::Relaxed) >= MAX_RECORDS {
            return;
        }
        let mut file = destination.file.lock().expect("L0 capture mutex poisoned");
        if destination.count.load(Ordering::Relaxed) >= MAX_RECORDS {
            return;
        }
        file.write_all(&job.encode())
            .expect("write complete L0 job");
        destination.count.fetch_add(1, Ordering::Relaxed);
    }
}

fn duration_ns(duration: Duration) -> u64 {
    u64::try_from(duration.as_nanos()).unwrap_or(u64::MAX)
}

fn declaration_id(decl: Decl) -> u8 {
    match decl {
        Decl::PipTrump(pip) => pip.value(),
        Decl::DoublesTrump => 7,
        Decl::NoTrump => 8,
    }
}

#[derive(Clone, Debug)]
pub struct CapturedJob {
    request_seed: u64,
    post_prepare_rng: u64,
    prepare_ns: u64,
    search_ns: u64,
    original_nodes: u64,
    played: u32,
    plays: u32,
    viewer_hand: u32,
    legal_mask: u32,
    declaration: u8,
    bid: u8,
    viewer: u8,
    maximize: u8,
    n: u8,
    len: u8,
    leader: u8,
    t1: u8,
    t0: u8,
    expected_choice: u8,
    depth: u8,
    hand_sizes: [u8; 4],
    /// Reserved v1 metadata byte: 0 natural live capture, 1 synthetic.
    origin: u8,
    worlds: [[u32; 4]; 8],
    seeds: [u64; 8],
}

impl CapturedJob {
    pub fn depth(&self) -> u8 {
        self.depth
    }
    pub fn sample_count(&self) -> u8 {
        self.n
    }
    pub fn legal_count(&self) -> u32 {
        self.legal_mask.count_ones()
    }
    pub fn partial_len(&self) -> u8 {
        self.len
    }
    pub fn recorded_prepare_ns(&self) -> u64 {
        self.prepare_ns
    }
    pub fn recorded_search_ns(&self) -> u64 {
        self.search_ns
    }
    pub fn recorded_nodes(&self) -> u64 {
        self.original_nodes
    }
    pub fn expected_choice(&self) -> u8 {
        self.expected_choice
    }
    pub fn maximize(&self) -> bool {
        self.maximize == 1
    }
    pub fn is_synthetic(&self) -> bool {
        self.origin == 1
    }

    fn encode(&self) -> [u8; RECORD_BYTES] {
        let mut out = [0u8; RECORD_BYTES];
        put_u64(&mut out, 0, self.request_seed);
        put_u64(&mut out, 8, self.post_prepare_rng);
        put_u64(&mut out, 16, self.prepare_ns);
        put_u64(&mut out, 24, self.search_ns);
        put_u64(&mut out, 32, self.original_nodes);
        put_u32(&mut out, 40, self.played);
        put_u32(&mut out, 44, self.plays);
        put_u32(&mut out, 48, self.viewer_hand);
        put_u32(&mut out, 52, self.legal_mask);
        out[56..71].copy_from_slice(&[
            self.declaration,
            self.bid,
            self.viewer,
            self.maximize,
            self.n,
            self.len,
            self.leader,
            self.t1,
            self.t0,
            self.expected_choice,
            self.depth,
            self.hand_sizes[0],
            self.hand_sizes[1],
            self.hand_sizes[2],
            self.hand_sizes[3],
        ]);
        out[71] = self.origin;
        for sid in 0..8 {
            for seat in 0..4 {
                put_u32(
                    &mut out,
                    META_BYTES + 16 * sid + 4 * seat,
                    self.worlds[sid][seat],
                );
            }
            put_u64(
                &mut out,
                META_BYTES + WORLD_BYTES + 8 * sid,
                self.seeds[sid],
            );
        }
        out
    }

    fn decode(bytes: &[u8]) -> io::Result<Self> {
        if bytes.len() != RECORD_BYTES {
            return Err(invalid("incomplete L0 capture record"));
        }
        let mut worlds = [[0u32; 4]; 8];
        let mut seeds = [0u64; 8];
        for sid in 0..8 {
            for seat in 0..4 {
                worlds[sid][seat] = get_u32(bytes, META_BYTES + 16 * sid + 4 * seat);
            }
            seeds[sid] = get_u64(bytes, META_BYTES + WORLD_BYTES + 8 * sid);
        }
        let job = Self {
            request_seed: get_u64(bytes, 0),
            post_prepare_rng: get_u64(bytes, 8),
            prepare_ns: get_u64(bytes, 16),
            search_ns: get_u64(bytes, 24),
            original_nodes: get_u64(bytes, 32),
            played: get_u32(bytes, 40),
            plays: get_u32(bytes, 44),
            viewer_hand: get_u32(bytes, 48),
            legal_mask: get_u32(bytes, 52),
            declaration: bytes[56],
            bid: bytes[57],
            viewer: bytes[58],
            maximize: bytes[59],
            n: bytes[60],
            len: bytes[61],
            leader: bytes[62],
            t1: bytes[63],
            t0: bytes[64],
            expected_choice: bytes[65],
            depth: bytes[66],
            hand_sizes: [bytes[67], bytes[68], bytes[69], bytes[70]],
            origin: bytes[71],
            worlds,
            seeds,
        };
        job.validate()?;
        Ok(job)
    }

    fn validate(&self) -> io::Result<()> {
        if self.declaration >= 9
            || !(30..=42).contains(&self.bid)
            || self.viewer >= 4
            || self.maximize > 1
            || self.origin > 1
            || !(1..=8).contains(&self.n)
            || self.len > 3
            || self.leader >= 4
            || !(1..=7).contains(&self.depth)
            || self.played & !FULL_MASK != 0
            || self.viewer_hand & !FULL_MASK != 0
            || self.legal_mask & !FULL_MASK != 0
            || self.legal_mask & !self.viewer_hand != 0
            || self.legal_mask == 0
            || self.expected_choice >= 28
            || self.legal_mask & (1 << self.expected_choice) == 0
            || self.plays >> (5 * self.len) != 0
            || self.hand_sizes.iter().any(|&size| size > 7)
            || self.hand_sizes[self.viewer as usize] != self.viewer_hand.count_ones() as u8
            || (usize::from(self.leader) + usize::from(self.len)) % 4 != self.viewer as usize
            || self.worlds[self.n as usize..]
                .iter()
                .any(|world| *world != [0; 4])
            || self.seeds[self.n as usize..].iter().any(|&seed| seed != 0)
        {
            return Err(invalid("invalid L0 capture fields"));
        }
        let mut partial_mask = 0u32;
        for i in 0..self.len {
            let tile = ((self.plays >> (5 * i)) & 31) as u8;
            if tile >= 28 || partial_mask & (1 << tile) != 0 {
                return Err(invalid("invalid L0 capture partial trick"));
            }
            partial_mask |= 1 << tile;
        }
        if self.played & partial_mask != partial_mask
            || self.viewer_hand & self.played != 0
            || self.legal_mask & self.played != 0
        {
            return Err(invalid("L0 capture masks disagree with public state"));
        }
        let remaining = (FULL_MASK & !self.played).count_ones() + u32::from(self.len);
        if remaining != 4 * u32::from(self.depth) {
            return Err(invalid("L0 capture depth disagrees with public state"));
        }
        let completed = (self.played.count_ones() - u32::from(self.len)) / 4;
        for seat in 0..4 {
            let already_played_this_trick =
                u32::from((seat as u8 + 4 - self.leader) & 3) < u32::from(self.len);
            let expected_size = 7 - completed - u32::from(already_played_this_trick);
            if u32::from(self.hand_sizes[seat]) != expected_size {
                return Err(invalid(
                    "L0 capture hand capacity disagrees with public state",
                ));
            }
        }
        let mut completed_tiles = self.played & !partial_mask;
        let mut count_points = 0u32;
        while completed_tiles != 0 {
            let tile = completed_tiles.trailing_zeros() as usize;
            completed_tiles &= completed_tiles - 1;
            count_points += Domino::ALL[tile].count();
        }
        if u32::from(self.t1) + u32::from(self.t0) != completed + count_points {
            return Err(invalid(
                "L0 capture banked total disagrees with completed tiles",
            ));
        }
        let led = if self.len == 0 {
            None
        } else {
            Some(
                Decl::ALL[self.declaration as usize]
                    .led_context(Domino::ALL[(self.plays & 31) as usize]),
            )
        };
        let legal = legal_plays(
            Decl::ALL[self.declaration as usize],
            DominoSet::from_bits(self.viewer_hand).expect("viewer mask already checked"),
            led,
        )
        .bits();
        if self.legal_mask != legal {
            return Err(invalid("L0 capture legal mask is not canonical"));
        }
        let unplayed = FULL_MASK & !self.played;
        for world in &self.worlds[..self.n as usize] {
            if world[self.viewer as usize] != self.viewer_hand {
                return Err(invalid("L0 capture viewer hand differs by sample"));
            }
            let mut union = 0u32;
            for (seat, &mask) in world.iter().enumerate() {
                if mask & !unplayed != 0
                    || union & mask != 0
                    || mask.count_ones() != u32::from(self.hand_sizes[seat])
                {
                    return Err(invalid("invalid L0 capture sample partition"));
                }
                union |= mask;
            }
            if union != unplayed {
                return Err(invalid("incomplete L0 capture sample partition"));
            }
        }
        Ok(())
    }

    fn normalized_context_c(&self) -> u8 {
        let completed = (self.played.count_ones() - u32::from(self.len)) / 4;
        self.depth + completed as u8
    }

    fn shared(&self) -> Shared {
        // Search and Voidless preparation consume only declaration, bid,
        // deadline/dead flag, and diagnostic counters. Normalizing the
        // boundary to its original hand capacity permits sharing all jobs
        // in one compatible context, just as the live game does.
        Shared::new(
            Decl::ALL[self.declaration as usize],
            self.bid,
            vec![self.n as usize],
            0,
            self.normalized_context_c() as usize,
            Deadline::after(Duration::from_secs(3_600)),
        )
    }

    fn key(&self) -> Key {
        let mut plays = Vec::with_capacity(self.len as usize);
        for i in 0..self.len {
            plays.push(((self.plays >> (5 * i)) & 31) as u8);
        }
        Key {
            voids: None,
            played: self.played,
            leader: self.leader,
            plays,
            banked_t1: self.t1,
            banked_t0: self.t0,
            alive: 0,
        }
    }

    fn prepared(
        &self,
        shared: Arc<Shared>,
        worlds: [[u32; 4]; 8],
        seeds: [u64; 8],
    ) -> ReplayPrepared {
        let root = State {
            played: self.played,
            plays: self.plays,
            len: self.len,
            leader: self.leader,
            t1: self.t1,
            t0: self.t0,
            alive: ((1u16 << self.n) - 1) as u8,
            #[cfg(feature = "compact-depth")]
            tricks_left: self.depth,
        };
        ReplayPrepared {
            shared,
            key: self.key(),
            root,
            worlds,
            seeds,
            request_seed: self.request_seed,
            hand_sizes: self.hand_sizes.map(usize::from),
            packet_template: self.encode(),
            n: self.n as usize,
            declaration: self.declaration as usize,
            viewer: self.viewer,
            hand: self.viewer_hand,
            maximize: self.maximize == 1,
            legal_mask: self.legal_mask,
        }
    }

    /// Parse/setup once outside a search-only timer; no resampling occurs.
    pub fn prepare_stored(&self) -> Result<ReplayPrepared, String> {
        self.validate().map_err(|error| error.to_string())?;
        Ok(self.prepared(Arc::new(self.shared()), self.worlds, self.seeds))
    }
}

/// Build all replay contexts once, sharing one `Shared` for every equivalent
/// (declaration, bid, sample count, normalized initial hand capacity) group.
/// The per-job public Key and its partial plays are also prebuilt here.
pub fn prepare_replay_batch(jobs: &[CapturedJob]) -> Result<Vec<ReplayPrepared>, String> {
    let mut groups: HashMap<(u8, u8, u8, u8), Arc<Shared>> = HashMap::new();
    let mut replay = Vec::with_capacity(jobs.len());
    for job in jobs {
        job.validate().map_err(|error| error.to_string())?;
        let group = (job.declaration, job.bid, job.n, job.normalized_context_c());
        let shared = groups
            .entry(group)
            .or_insert_with(|| Arc::new(job.shared()))
            .clone();
        replay.push(job.prepared(shared, job.worlds, job.seeds));
    }
    Ok(replay)
}

pub struct ReplayPrepared {
    shared: Arc<Shared>,
    key: Key,
    root: State,
    worlds: [[u32; 4]; 8],
    seeds: [u64; 8],
    request_seed: u64,
    hand_sizes: [usize; 4],
    packet_template: [u8; RECORD_BYTES],
    n: usize,
    declaration: usize,
    viewer: u8,
    hand: u32,
    maximize: bool,
    legal_mask: u32,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct ReplayOutcome {
    pub choice: u8,
    pub nodes: u64,
}

impl ReplayPrepared {
    /// Scalar recurrence used by live `prepared_choice`, including the same
    /// bounded Fixed chooser, candidate order, and sample-ID mapping.
    pub fn search(&self) -> Result<ReplayOutcome, String> {
        self.search_with(&self.worlds, &self.seeds)
    }

    /// Time this as the live-like scalar preparation/packet/search arm. The
    /// Shared and Key are built once, as they are reused by live L0 requests.
    /// Compare the returned packet outside the timer to keep validation cost
    /// distinct from actual preparation and fixed-size packet construction.
    pub fn regenerate_packet_and_search(
        &self,
    ) -> Result<(ReplayOutcome, [u8; RECORD_BYTES]), String> {
        let mut rng = SplitMix64(self.request_seed);
        let prepared = prepare_voidless(
            &self.shared,
            &self.key,
            self.viewer as usize,
            self.hand,
            self.hand_sizes,
            self.n,
            &mut rng,
        )
        .ok_or_else(|| "regeneration refused by deadline".to_string())?;
        let mut packet = self.packet_template;
        put_u64(&mut packet, 8, rng.0);
        for sid in 0..8 {
            for seat in 0..4 {
                put_u32(
                    &mut packet,
                    META_BYTES + 16 * sid + 4 * seat,
                    prepared.worlds[sid][seat],
                );
            }
            put_u64(
                &mut packet,
                META_BYTES + WORLD_BYTES + 8 * sid,
                prepared.seeds[sid],
            );
        }
        let outcome = self.search_with(&prepared.worlds, &prepared.seeds)?;
        Ok((outcome, packet))
    }

    pub fn matches_captured_packet(&self, packet: &[u8; RECORD_BYTES]) -> bool {
        packet == &self.packet_template
    }

    /// Exact per-root-action success counts for independent GPU validation.
    /// This deliberately bypasses bounded root choice and runs outside replay
    /// timing. The output preserves ascending legal tile order and sample IDs.
    pub fn full_action_counts(&self) -> Result<Vec<(u8, u8)>, String> {
        let mut search = Search {
            rules: &RULES[self.declaration],
            sh: &self.shared,
            worlds: &self.worlds[..self.n],
            seeds: &self.seeds[..self.n],
            viewer: self.viewer,
            hand: self.hand,
            maximize: self.maximize,
            nodes: 0,
            viewer_children: 0,
            viewer_legal: 0,
        };
        let mut counts = Vec::with_capacity(self.legal_mask.count_ones() as usize);
        let mut legal = self.legal_mask;
        while legal != 0 {
            let tile = legal.trailing_zeros() as u8;
            legal &= legal - 1;
            let child = search.advance(self.root, u32::from(tile), self.root.alive);
            #[cfg(feature = "const-objective")]
            let value = if self.maximize {
                search.solve_const::<true>(child)
            } else {
                search.solve_const::<false>(child)
            };
            #[cfg(not(feature = "const-objective"))]
            let value = search.solve(child);
            let successes =
                value.ok_or_else(|| "exact L0 action-count replay refused".to_string())?;
            counts.push((tile, successes));
        }
        if !search.finished() {
            return Err("exact L0 action-count replay cancelled".into());
        }
        Ok(counts)
    }

    fn search_with(
        &self,
        worlds: &[[u32; 4]; 8],
        seeds: &[u64; 8],
    ) -> Result<ReplayOutcome, String> {
        let mut search = Search {
            rules: &RULES[self.declaration],
            sh: &self.shared,
            worlds: &worlds[..self.n],
            seeds: &seeds[..self.n],
            viewer: self.viewer,
            hand: self.hand,
            maximize: self.maximize,
            nodes: 0,
            viewer_children: 0,
            viewer_legal: 0,
        };
        let mut candidates = [0u8; 28];
        let mut len = 0;
        let mut legal = self.legal_mask;
        while legal != 0 {
            candidates[len] = legal.trailing_zeros() as u8;
            len += 1;
            legal &= legal - 1;
        }
        let choice = choose_fixed(&mut search, self.root, &candidates[..len])
            .ok_or_else(|| "captured job replay refused".to_string())?;
        Ok(ReplayOutcome {
            choice,
            nodes: search.nodes,
        })
    }
}

pub fn read_capture_file(path: impl AsRef<Path>) -> io::Result<Vec<CapturedJob>> {
    let bytes = fs::read(path)?;
    if bytes.len() < HEADER_BYTES
        || &bytes[..8] != MAGIC
        || get_u32(&bytes, 8) != VERSION
        || get_u32(&bytes, 12) != RECORD_BYTES as u32
        || (bytes.len() - HEADER_BYTES) % RECORD_BYTES != 0
    {
        return Err(invalid("invalid L0 capture file header or length"));
    }
    let count = (bytes.len() - HEADER_BYTES) / RECORD_BYTES;
    if count > MAX_RECORDS {
        return Err(invalid("L0 capture exceeds process record cap"));
    }
    bytes[HEADER_BYTES..]
        .chunks_exact(RECORD_BYTES)
        .map(CapturedJob::decode)
        .collect()
}

struct SyntheticPrefix {
    key: Key,
    hands: [u32; 4],
    viewer: usize,
    legal_mask: u32,
}

fn nth_tile(mut mask: u32, n: u32) -> u8 {
    for _ in 0..n {
        mask &= mask - 1;
    }
    mask.trailing_zeros() as u8
}

/// Draw one genuine legal public prefix from a complete shuffled deal. Its
/// *future* hidden worlds are intentionally resampled Voidless below; their
/// assignments need not explain earlier plays or inferred voids.
fn synthetic_prefix(
    decl: Decl,
    depth: u8,
    partial_len: u8,
    attempt: u64,
) -> Option<SyntheticPrefix> {
    let seed = mix(0xD9B4_2E58_7A31_C6F0
        ^ (u64::from(declaration_id(decl)) << 48)
        ^ (u64::from(depth) << 40)
        ^ (u64::from(partial_len) << 32)
        ^ attempt);
    let mut rng = SplitMix64(seed);
    let mut tiles = [0u8; 28];
    for (i, tile) in tiles.iter_mut().enumerate() {
        *tile = i as u8;
    }
    for i in (1..tiles.len()).rev() {
        let j = rng.below((i + 1) as u64) as usize;
        tiles.swap(i, j);
    }
    let mut hands = [0u32; 4];
    for seat in 0..4 {
        for &tile in &tiles[seat * 7..seat * 7 + 7] {
            hands[seat] |= 1u32 << tile;
        }
    }
    let mut leader = rng.below(4) as u8;
    let mut played = 0u32;
    let mut t1 = 0u8;
    let mut t0 = 0u8;
    for _ in 0..(7 - depth) {
        let mut trick_tiles = [0u8; 4];
        for i in 0..4 {
            let seat = (usize::from(leader) + i) & 3;
            let led = if i == 0 {
                None
            } else {
                Some(decl.led_context(Domino::ALL[trick_tiles[0] as usize]))
            };
            let legal = legal_plays(
                decl,
                DominoSet::from_bits(hands[seat]).expect("valid synthetic hand"),
                led,
            )
            .bits();
            let tile = nth_tile(legal, rng.below(u64::from(legal.count_ones())) as u32);
            trick_tiles[i] = tile;
            let bit = 1u32 << tile;
            hands[seat] &= !bit;
            played |= bit;
        }
        let trick = Trick::new(
            Seat::ALL[usize::from(leader)],
            trick_tiles.map(|tile| Domino::ALL[tile as usize]),
        )
        .expect("shuffled deal has distinct tiles");
        let winner = trick.winner(decl).index() as u8;
        let points = trick.points() as u8;
        if winner & 1 == 1 {
            t1 += points;
        } else {
            t0 += points;
        }
        leader = winner;
        if t1 >= 30 || t0 > 12 {
            return None;
        }
    }
    let mut plays = Vec::with_capacity(partial_len as usize);
    for i in 0..partial_len {
        let seat = (usize::from(leader) + usize::from(i)) & 3;
        let led = plays
            .first()
            .map(|&tile| decl.led_context(Domino::ALL[tile as usize]));
        let legal = legal_plays(
            decl,
            DominoSet::from_bits(hands[seat]).expect("valid synthetic hand"),
            led,
        )
        .bits();
        let tile = nth_tile(legal, rng.below(u64::from(legal.count_ones())) as u32);
        hands[seat] &= !(1u32 << tile);
        played |= 1u32 << tile;
        plays.push(tile);
    }
    let viewer = (usize::from(leader) + usize::from(partial_len)) & 3;
    let led = plays
        .first()
        .map(|&tile| decl.led_context(Domino::ALL[tile as usize]));
    let legal_mask = legal_plays(
        decl,
        DominoSet::from_bits(hands[viewer]).expect("valid synthetic hand"),
        led,
    )
    .bits();
    Some(SyntheticPrefix {
        key: Key {
            voids: None,
            played,
            leader,
            plays,
            banked_t1: t1,
            banked_t0: t0,
            alive: 0,
        },
        hands,
        viewer,
        legal_mask,
    })
}

fn synthetic_job(prefix: &SyntheticPrefix, decl: Decl, n: usize) -> Result<CapturedJob, String> {
    let hand = prefix.hands[prefix.viewer];
    let sizes = prefix.hands.map(|mask| mask.count_ones() as usize);
    let request_seed =
        INNER_SEED ^ mix(prefix.viewer as u64) ^ mix(u64::from(hand)) ^ record_hash(&prefix.key);
    let mut rng = SplitMix64(request_seed);
    let shared = Shared::new(
        decl,
        30,
        vec![n],
        0,
        7,
        Deadline::after(Duration::from_secs(3_600)),
    );
    let prepared = prepare_voidless(
        &shared,
        &prefix.key,
        prefix.viewer,
        hand,
        sizes,
        n,
        &mut rng,
    )
    .ok_or_else(|| "synthetic Voidless preparation cancelled".to_string())?;
    let mut packed_plays = 0u32;
    for (i, &tile) in prefix.key.plays.iter().enumerate() {
        packed_plays |= u32::from(tile) << (5 * i);
    }
    let remaining = (FULL_MASK & !prefix.key.played).count_ones() + prefix.key.plays.len() as u32;
    let mut job = CapturedJob {
        request_seed,
        post_prepare_rng: rng.0,
        prepare_ns: 0,
        search_ns: 0,
        original_nodes: 0,
        played: prefix.key.played,
        plays: packed_plays,
        viewer_hand: hand,
        legal_mask: prefix.legal_mask,
        declaration: declaration_id(decl),
        bid: 30,
        viewer: prefix.viewer as u8,
        maximize: u8::from(prefix.viewer & 1 == 1),
        n: n as u8,
        len: prefix.key.plays.len() as u8,
        leader: prefix.key.leader,
        t1: prefix.key.banked_t1,
        t0: prefix.key.banked_t0,
        expected_choice: prefix.legal_mask.trailing_zeros() as u8,
        depth: (remaining / 4) as u8,
        hand_sizes: sizes.map(|size| size as u8),
        origin: 1,
        worlds: prepared.worlds,
        seeds: prepared.seeds,
    };
    job.validate().map_err(|error| error.to_string())?;
    let choice = job.prepare_stored()?.search()?;
    job.expected_choice = choice.choice;
    job.original_nodes = choice.nodes;
    Ok(job)
}

/// Write a deliberately synthetic conformance corpus in the live capture v1
/// format. It is coverage input for correctness, never a workload frequency
/// distribution. Refuses overwrite and requires `synthetic` in the filename.
pub fn generate_l0_conformance_file(path: impl AsRef<Path>) -> Result<usize, String> {
    let path = path.as_ref();
    if !path
        .file_name()
        .is_some_and(|name| name.to_string_lossy().contains("synthetic"))
    {
        return Err("conformance filename must contain 'synthetic'".into());
    }
    let mut jobs = Vec::with_capacity(9 * 6 * 4 * 8);
    for decl in Decl::ALL {
        for depth in 2..=7 {
            for partial_len in 0..=3 {
                let prefix = (0..100_000u64)
                    .find_map(|attempt| synthetic_prefix(decl, depth, partial_len, attempt))
                    .ok_or_else(|| format!(
                        "no undecided lawful prefix for {decl}, depth {depth}, partial {partial_len}"
                    ))?;
                for n in 1..=8 {
                    jobs.push(synthetic_job(&prefix, decl, n)?);
                }
            }
        }
    }
    let mut file = OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(path)
        .map_err(|error| format!("cannot create synthetic corpus {}: {error}", path.display()))?;
    file.write_all(MAGIC).map_err(|error| error.to_string())?;
    file.write_all(&VERSION.to_le_bytes())
        .map_err(|error| error.to_string())?;
    file.write_all(&(RECORD_BYTES as u32).to_le_bytes())
        .map_err(|error| error.to_string())?;
    for job in &jobs {
        file.write_all(&job.encode())
            .map_err(|error| error.to_string())?;
    }
    file.sync_all().map_err(|error| error.to_string())?;
    Ok(jobs.len())
}

fn invalid(message: &'static str) -> io::Error {
    io::Error::new(io::ErrorKind::InvalidData, message)
}

fn put_u32(out: &mut [u8], at: usize, value: u32) {
    out[at..at + 4].copy_from_slice(&value.to_le_bytes());
}
fn put_u64(out: &mut [u8], at: usize, value: u64) {
    out[at..at + 8].copy_from_slice(&value.to_le_bytes());
}
fn get_u32(bytes: &[u8], at: usize) -> u32 {
    u32::from_le_bytes(bytes[at..at + 4].try_into().expect("u32 field"))
}
fn get_u64(bytes: &[u8], at: usize) -> u64 {
    u64::from_le_bytes(bytes[at..at + 8].try_into().expect("u64 field"))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn fixed_record_roundtrip_retains_duplicate_ids_and_partial_state() {
        let mut job = CapturedJob {
            request_seed: 123,
            post_prepare_rng: 456,
            prepare_ns: 7,
            search_ns: 8,
            original_nodes: 9,
            played: (1 << 0) | (1 << 5),
            plays: 5 << 5 | 0,
            viewer_hand: (21..28).fold(0u32, |mask, tile| mask | (1 << tile)),
            legal_mask: 1 << 21,
            declaration: 8,
            bid: 30,
            viewer: 2,
            maximize: 0,
            n: 2,
            len: 2,
            leader: 0,
            t1: 0,
            t0: 0,
            expected_choice: 21,
            depth: 7,
            hand_sizes: [6, 6, 7, 7],
            origin: 0,
            worlds: [[0; 4]; 8],
            seeds: [0; 8],
        };
        let mut available = (0..28).filter(|&tile| tile != 0 && tile != 5 && tile < 21);
        let seat0 = available
            .by_ref()
            .take(6)
            .fold(0u32, |mask, tile| mask | (1 << tile));
        let seat1 = available
            .by_ref()
            .take(6)
            .fold(0u32, |mask, tile| mask | (1 << tile));
        let seat3 = available.fold(0u32, |mask, tile| mask | (1 << tile));
        job.worlds[0] = [seat0, seat1, job.viewer_hand, seat3];
        job.worlds[1] = job.worlds[0];
        job.seeds[0] = 11;
        job.seeds[1] = 22;
        let bytes = job.encode();
        assert_eq!(bytes.len(), RECORD_BYTES);
        let read = CapturedJob::decode(&bytes).unwrap();
        assert_eq!(read.encode(), bytes);
        assert_eq!(read.worlds[0], read.worlds[1]);
        assert_ne!(read.seeds[0], read.seeds[1]);
        let batch = prepare_replay_batch(&[read.clone(), read]).unwrap();
        assert!(Arc::ptr_eq(&batch[0].shared, &batch[1].shared));
        assert_eq!(batch[0].key.plays, vec![0, 5]);

        let mut bad = job.clone();
        bad.legal_mask = 1 << 27;
        assert!(bad.validate().is_err(), "noncanonical legal subset");
        bad = job.clone();
        bad.plays |= 1 << 15;
        assert!(bad.validate().is_err(), "packed-play high bits");
        bad = job.clone();
        bad.hand_sizes[0] += 1;
        assert!(bad.validate().is_err(), "seat capacity");
        bad = job.clone();
        bad.t1 = 1;
        assert!(bad.validate().is_err(), "banked point conservation");
        bad = job;
        bad.origin = 1;
        assert!(CapturedJob::decode(&bad.encode()).unwrap().is_synthetic());
    }
}
