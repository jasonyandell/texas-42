//! Optional parallel root challengers for early modeled L1 Fixed choices.
//!
//! The first ascending action is exact. Every later action searches against
//! that same incumbent using a strict one-sided window. A surviving challenger
//! is exact, so the ordered reduction preserves Fixed's earliest-tile ties.

use super::{Bounds, Search, State};
use crate::solver::FULL_MASK;
use rayon::prelude::*;
#[cfg(test)]
use std::sync::atomic::{AtomicU64, Ordering};

#[cfg(test)]
static TEST_FANOUT_JOBS: AtomicU64 = AtomicU64::new(0);

/// Outer `None`: use the serial chooser. Inner `None`: cancelled/refused.
pub(super) fn choose(search: &mut Search<'_>, root: State, tiles: &[u8]) -> Option<Option<u8>> {
    let remaining = ((FULL_MASK & !root.played).count_ones() + u32::from(root.len)) / 4;
    // This experiment targets modeled L1, whose field is L0. The installed
    // rayon facade does not expose its core-only pending-task query; depth
    // and candidate count are the cheap, stable scheduling guard instead.
    if search.field_k != 0 || remaining < 5 || tiles.len() < 3 || rayon::current_num_threads() < 2 {
        return None;
    }
    // Avoid spawning more challengers while this worker has queued work.
    // This is a racy local-deque observation, not a claim that the pool is idle.
    #[cfg(feature = "queue-aware-inner")]
    if !matches!(rayon_core::current_thread_has_pending_tasks(), Some(false)) {
        return None;
    }
    assert!(tiles.windows(2).all(|pair| pair[0] < pair[1]));

    Some((|| {
        if !search.finished() {
            return None;
        }
        let mass = root.mass();
        let first = search.advance(root, u32::from(tiles[0]), root.alive);
        let first_bounds = search.window(first, -1, i16::from(mass) + 1)?;
        debug_assert_eq!(first_bounds.lo, first_bounds.hi);
        let initial_best = first_bounds.lo;
        let maximize = search.solver.maximize;
        if (maximize && initial_best == mass) || (!maximize && initial_best == 0) {
            return search.finished().then_some(tiles[0]);
        }

        let solver = search.solver;
        let rules = search.rules;
        let field_k = search.field_k;
        let (alpha, beta) = if maximize {
            (i16::from(initial_best), i16::from(mass) + 1)
        } else {
            (-1, i16::from(initial_best))
        };
        // Indexed par_iter preserves ascending candidate order in collect.
        // Every job owns its counters and stack; only the existing thread-safe
        // Solver/Shared policy cache is shared across candidate searches.
        let results: Vec<Option<Bounds>> = tiles[1..]
            .par_iter()
            .map(|&tile| {
                #[cfg(test)]
                TEST_FANOUT_JOBS.fetch_add(1, Ordering::Relaxed);
                let mut local = Search {
                    solver,
                    rules,
                    field_k,
                    nodes: 0,
                    viewer_children: 0,
                    viewer_legal: 0,
                };
                let child = local.advance(root, u32::from(tile), root.alive);
                let result = local.window(child, alpha, beta);
                local.report();
                result
            })
            .collect();
        if !search.finished() {
            return None;
        }

        let mut best = initial_best;
        let mut best_tile = tiles[0];
        for (&tile, result) in tiles[1..].iter().zip(results) {
            let bounds = result?;
            let rejected = if maximize {
                i16::from(bounds.hi) <= alpha
            } else {
                i16::from(bounds.lo) >= beta
            };
            if rejected {
                continue;
            }
            // The opposite cutoff lies outside [0,mass], so every accepted
            // challenger is exact and strictly better than the first tile.
            debug_assert_eq!(bounds.lo, bounds.hi);
            debug_assert!(if maximize {
                bounds.lo > initial_best
            } else {
                bounds.lo < initial_best
            });
            if (maximize && bounds.lo > best) || (!maximize && bounds.lo < best) {
                best = bounds.lo;
                best_tile = tile;
            }
        }
        search.finished().then_some(best_tile)
    })())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::rules::rules::{legal_plays, Trick};
    use crate::rules::{Decl, Domino, Seat, Team};
    use crate::solver::{
        self, best_of, Deadline, Field, InnerBelief, Key, Shared, Solver, SplitMix64,
    };
    use std::sync::Arc;
    use std::time::Duration;

    fn lawful_five_trick_prefix(decl: Decl, salt: u64) -> (Key, Seat, u32, u32) {
        let mut rng = SplitMix64(0x7df0_7331_aa42_0000 ^ salt);
        let mut deck: [u8; 28] = std::array::from_fn(|i| i as u8);
        for i in (1..28).rev() {
            deck.swap(i, rng.below((i + 1) as u64) as usize);
        }
        let mut hands = [0u32; 4];
        for (seat, tiles) in deck.chunks_exact(7).enumerate() {
            hands[seat] = tiles.iter().fold(0, |mask, &tile| mask | (1 << tile));
        }
        let mut key = Key {
            voids: None,
            played: 0,
            leader: 0,
            plays: Vec::new(),
            banked_t1: 0,
            banked_t0: 0,
            alive: 0,
        };
        for _ in 0..2 {
            let leader = key.leader as usize;
            let mut tiles = [0u8; 4];
            for i in 0..4 {
                let seat = (leader + i) & 3;
                let led = (i > 0).then(|| decl.led_context(Domino::ALL[tiles[0] as usize]));
                let legal = legal_plays(decl, solver::set_of(hands[seat]), led).bits();
                let tile = legal.trailing_zeros() as u8;
                tiles[i] = tile;
                hands[seat] &= !(1 << tile);
                key.played |= 1 << tile;
            }
            let trick = Trick::new(
                Seat::from_index(leader).unwrap(),
                tiles.map(|tile| Domino::ALL[tile as usize]),
            )
            .unwrap();
            let winner = trick.winner(decl);
            if winner.team() == Team::T1 {
                key.banked_t1 += trick.points() as u8;
            } else {
                key.banked_t0 += trick.points() as u8;
            }
            key.leader = winner.index() as u8;
        }
        let viewer = Seat::from_index(key.leader as usize).unwrap();
        let hand = hands[viewer.index()];
        assert_eq!(hand.count_ones(), 5);
        let boundary = key.played;
        (key, viewer, hand, boundary)
    }

    #[test]
    fn early_inner_parallel_matches_full_values_for_both_objectives() {
        let pool = rayon::ThreadPoolBuilder::new()
            .num_threads(3)
            .build()
            .unwrap();
        for maximize in [false, true] {
            let mut found = false;
            for attempt in 0..256u64 {
                let di = attempt as usize % Decl::COUNT;
                let decl = Decl::ALL[di];
                let (key, viewer, hand, boundary) =
                    lawful_five_trick_prefix(decl, attempt / Decl::COUNT as u64);
                if (viewer.team() == Team::T1) != maximize
                    || key.banked_t1 >= 30
                    || key.banked_t0 > 12
                {
                    continue;
                }
                let choices = solver::mask_bits(hand);
                assert_eq!(choices.len(), 5);
                let sample_sh = Arc::new(Shared::new(
                    decl,
                    30,
                    vec![1],
                    boundary,
                    5,
                    Deadline::after(Duration::from_secs(20)),
                ));
                let mut rng = SplitMix64(0x9b11_5478_2222_0000 ^ attempt);
                let worlds = InnerBelief::Voidless
                    .sample(
                        decl,
                        viewer,
                        hand,
                        &key,
                        [5; 4],
                        2,
                        &mut rng,
                        sample_sh.deadline,
                    )
                    .unwrap();
                let trial = Solver::new(
                    Arc::clone(&sample_sh),
                    viewer,
                    hand,
                    maximize,
                    worlds.clone(),
                    Vec::new(),
                    Field::Level(0),
                );
                let root = State {
                    played: key.played,
                    plays: 0,
                    len: 0,
                    leader: key.leader,
                    t1: key.banked_t1,
                    t0: key.banked_t0,
                    alive: 0b11,
                };
                let mut trial_search = Search {
                    solver: &trial,
                    rules: &super::super::RULES[di],
                    field_k: 0,
                    nodes: 0,
                    viewer_children: 0,
                    viewer_legal: 0,
                };
                let first = trial_search.advance(root, u32::from(choices[0]), root.alive);
                let first_bounds = trial_search.window(first, -1, 3).unwrap();
                assert_eq!(first_bounds.lo, first_bounds.hi);
                if (maximize && first_bounds.lo == 2) || (!maximize && first_bounds.lo == 0) {
                    continue;
                }

                let reference_sh = Arc::new(Shared::new(
                    decl,
                    30,
                    vec![1],
                    boundary,
                    5,
                    Deadline::after(Duration::from_secs(20)),
                ));
                let reference = Solver::new(
                    reference_sh,
                    viewer,
                    hand,
                    maximize,
                    worlds.clone(),
                    Vec::new(),
                    Field::Level(0),
                )
                .action_values(&key, &choices)
                .unwrap();
                let expected = best_of(&reference, maximize);

                let parallel_sh = Arc::new(Shared::new(
                    decl,
                    30,
                    vec![1],
                    boundary,
                    5,
                    Deadline::after(Duration::from_secs(20)),
                ));
                let parallel_solver = Solver::new(
                    parallel_sh,
                    viewer,
                    hand,
                    maximize,
                    worlds,
                    Vec::new(),
                    Field::Level(0),
                );
                let mut parallel_search = Search {
                    solver: &parallel_solver,
                    rules: &super::super::RULES[di],
                    field_k: 0,
                    nodes: 0,
                    viewer_children: 0,
                    viewer_legal: 0,
                };
                let before = TEST_FANOUT_JOBS.load(Ordering::Relaxed);
                let actual = pool.install(|| choose(&mut parallel_search, root, &choices));
                let after = TEST_FANOUT_JOBS.load(Ordering::Relaxed);
                assert_eq!(actual, Some(Some(expected)));
                assert!(after >= before + (choices.len() - 1) as u64);
                found = true;
                break;
            }
            assert!(
                found,
                "no eligible non-extreme early fixture for maximize={maximize}"
            );
        }
    }
}
