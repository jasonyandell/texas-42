//! Exact choice-only comparison by optimistic integer endpoints.
//!
//! Bounds belong to one sampled modeled-policy bundle. A bound is never emitted as an
//! action value: it is used only to certify the smallest-tile argbest.

use super::{Bounds, Search, State};

trait RootOracle {
    /// Sound exact count or interval outside (target-1, target+1).
    fn probe(&mut self, tile: u8, target: u8) -> Option<Bounds>;
    fn finished(&mut self) -> bool;
}

struct LiveOracle<'a, 'b> {
    search: &'a mut Search<'b>,
    root: State,
}

impl RootOracle for LiveOracle<'_, '_> {
    fn probe(&mut self, tile: u8, target: u8) -> Option<Bounds> {
        let child = self.search.advance(self.root, u32::from(tile), self.root.alive);
        self.search.window(child, i16::from(target) - 1, i16::from(target) + 1)
    }

    fn finished(&mut self) -> bool { self.search.finished() }
}

fn dominance(tiles: &[u8], intervals: &[Bounds], maximize: bool) -> Option<u8> {
    for (i, &tile) in tiles.iter().enumerate() {
        let a = intervals[i];
        if tiles.iter().enumerate().all(|(j, &rival)| {
            if i == j { return true; }
            let b = intervals[j];
            if maximize {
                a.lo > b.hi || (a.lo == b.hi && tile < rival)
            } else {
                a.hi < b.lo || (a.hi == b.lo && tile < rival)
            }
        }) {
            return Some(tile);
        }
    }
    None
}

fn choose_with(oracle: &mut impl RootOracle, tiles: &[u8], mass: u8, maximize: bool) -> Option<u8> {
    assert!(!tiles.is_empty() && tiles.len() <= 7);
    assert!(tiles.windows(2).all(|w| w[0] < w[1]), "ascending unique root candidates");
    assert!((1..=8).contains(&mass));
    let mut intervals = [Bounds { lo: 0, hi: mass }; 7];
    let live = &mut intervals[..tiles.len()];
    loop {
        if !oracle.finished() { return None; }
        // This certificate may finish without identifying any exact count.
        if let Some(tile) = dominance(tiles, live, maximize) {
            return oracle.finished().then_some(tile);
        }
        // Optimistic endpoint and the first tile on every endpoint tie.
        let mut selected = 0;
        for i in 1..live.len() {
            if if maximize { live[i].hi > live[selected].hi }
               else { live[i].lo < live[selected].lo } {
                selected = i;
            }
        }
        let old = live[selected];
        if old.lo == old.hi {
            return oracle.finished().then_some(tiles[selected]);
        }
        let target = if maximize { old.hi } else { old.lo };
        let observed = oracle.probe(tiles[selected], target)?;
        let next = Bounds { lo: old.lo.max(observed.lo), hi: old.hi.min(observed.hi) };
        assert!(next.lo <= next.hi, "root certificate intersection is nonempty");
        if next.lo != next.hi {
            assert!(if maximize { next.hi < old.hi } else { next.lo > old.lo },
                    "failed endpoint probe must tighten the optimistic endpoint");
        }
        live[selected] = next;
    }
}

/// Choose the exact Fixed argbest over this modeled-policy bundle. The caller owns
/// reporting the search's counters, including refusal. Final deadline and
/// cancellation are checked even after an interval certificate is found.
pub(super) fn choose(search: &mut Search<'_>, root: State, tiles: &[u8]) -> Option<u8> {
    let mass = root.mass();
    let maximize = search.solver.maximize;
    let mut oracle = LiveOracle { search, root };
    choose_with(&mut oracle, tiles, mass, maximize)
}

#[cfg(test)]
mod tests {
    use super::*;

    struct Counts {
        values: Vec<u8>,
        mass: u8,
        probes: usize,
        alive: bool,
    }

    impl RootOracle for Counts {
        fn probe(&mut self, tile: u8, target: u8) -> Option<Bounds> {
            self.probes += 1;
            let value = self.values[usize::from(tile)];
            Some(if value == target {
                Bounds::exact(value)
            } else if value < target {
                // Valid fail-soft upper bound, deliberately weaker than the
                // exact value to force repeated endpoint refinement.
                Bounds { lo: 0, hi: target - 1 }
            } else {
                Bounds { lo: target + 1, hi: self.mass }
            })
        }

        fn finished(&mut self) -> bool { self.alive }
    }

    #[test]
    fn every_small_integer_vector_retains_first_tile_ties() {
        let tiles = [1u8, 3, 9, 27];
        for mass in 1u8..=4 {
            let base = usize::from(mass) + 1;
            for n in 1..=tiles.len() {
                for mut code in 0..base.pow(n as u32) {
                    let mut values = vec![0u8; 28];
                    let mut ordered = Vec::new();
                    for &tile in &tiles[..n] {
                        let value = (code % base) as u8;
                        code /= base;
                        values[usize::from(tile)] = value;
                        ordered.push(value);
                    }
                    for maximize in [false, true] {
                        let optimum = if maximize {
                            *ordered.iter().max().unwrap()
                        } else {
                            *ordered.iter().min().unwrap()
                        };
                        let expected = tiles[ordered.iter().position(|&v| v == optimum).unwrap()];
                        let mut oracle = Counts { values: values.clone(), mass,
                            probes: 0, alive: true };
                        assert_eq!(choose_with(&mut oracle, &tiles[..n], mass, maximize),
                                   Some(expected), "mass={mass} ordered={ordered:?} max={maximize}");
                        assert!(oracle.probes <= n * usize::from(mass) + 1);
                    }
                }
            }
        }
    }

    #[test]
    fn a_finished_certificate_still_refuses_cancellation() {
        let mut oracle = Counts { values: vec![0; 28], mass: 1,
                                  probes: 0, alive: false };
        assert_eq!(choose_with(&mut oracle, &[1, 3], 1, false), None);
    }
}
