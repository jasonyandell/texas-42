//! Replay-only census of repeated compact Dice states within one prepared job.
//!
//! The 61-bit key is exact only because the recorder is scoped to one fixed
//! hand/world/tape/declaration/bid/objective bundle. It omits t0 because the
//! completed tiles determine total banked points, hence t0 from t1.
//! No lookup changes the search result or prunes a node.

use super::State;
use std::cell::RefCell;
use std::collections::HashMap;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) enum Kind {
    Exact,
    Window,
}

#[derive(Clone, Copy, Debug, Default)]
pub struct CensusStats {
    pub visits: u64,
    pub unique_states: u64,
    pub repeated_unique_states: u64,
    pub duplicate_visits: u64,
    pub exact_after_exact: u64,
    pub window_after_exact: u64,
    pub exact_after_window: u64,
    pub window_after_window: u64,
    /// Optimistic, disjoint duplicate subtrees in the observed traversal.
    /// A prior window probe may not contain a reusable exact answer or a
    /// strong-enough bound for another window, so this is an upper bound.
    pub optimistic_saved_nodes: u64,
    pub disjoint_duplicate_subtrees: u64,
    pub largest_duplicate_subtree: u64,
}

struct Entry {
    first_kind: Kind,
    visits: u32,
}

struct Frame {
    depth: u32,
    first_ordinal: u64,
    disjoint_duplicate: bool,
}

#[derive(Default)]
struct Recorder {
    seen: HashMap<u64, Entry>,
    stack: Vec<Frame>,
    stats: CensusStats,
}

impl Recorder {
    fn finish_frame(&mut self) {
        let frame = self.stack.pop().expect("census frame");
        if frame.disjoint_duplicate {
            let nodes = self.stats.visits - frame.first_ordinal + 1;
            self.stats.optimistic_saved_nodes += nodes;
            self.stats.disjoint_duplicate_subtrees += 1;
            self.stats.largest_duplicate_subtree = self.stats.largest_duplicate_subtree.max(nodes);
        }
    }

    fn record(&mut self, state: State, kind: Kind) {
        let depth = state.played.count_ones();
        // Every physical transition adds one played tile. Once the next
        // visit is at the same or shallower depth, the prior branch is done.
        while self.stack.last().is_some_and(|frame| frame.depth >= depth) {
            self.finish_frame();
        }
        let key = pack(state);
        let duplicate = if let Some(entry) = self.seen.get_mut(&key) {
            entry.visits += 1;
            self.stats.duplicate_visits += 1;
            if entry.visits == 2 {
                self.stats.repeated_unique_states += 1;
            }
            match (entry.first_kind, kind) {
                (Kind::Exact, Kind::Exact) => self.stats.exact_after_exact += 1,
                (Kind::Exact, Kind::Window) => self.stats.window_after_exact += 1,
                (Kind::Window, Kind::Exact) => self.stats.exact_after_window += 1,
                (Kind::Window, Kind::Window) => self.stats.window_after_window += 1,
            }
            true
        } else {
            self.seen.insert(
                key,
                Entry {
                    first_kind: kind,
                    visits: 1,
                },
            );
            self.stats.unique_states += 1;
            false
        };
        let disjoint_duplicate =
            duplicate && !self.stack.iter().any(|frame| frame.disjoint_duplicate);
        self.stats.visits += 1;
        self.stack.push(Frame {
            depth,
            first_ordinal: self.stats.visits,
            disjoint_duplicate,
        });
    }

    fn finish(mut self) -> CensusStats {
        while !self.stack.is_empty() {
            self.finish_frame();
        }
        debug_assert_eq!(
            self.stats.unique_states + self.stats.duplicate_visits,
            self.stats.visits
        );
        self.stats
    }
}

/// Exact 61-bit job-local identity: played28, unfinished tiles15, len2,
/// leader2, t1 score6, alive sample mask8. No hash collision is possible.
fn pack(state: State) -> u64 {
    debug_assert!(state.played < (1 << 28));
    debug_assert!(state.plays < (1 << 15));
    debug_assert!(state.len <= 3 && state.leader <= 3 && state.t1 <= 42);
    u64::from(state.played)
        | (u64::from(state.plays) << 28)
        | (u64::from(state.len) << 43)
        | (u64::from(state.leader) << 45)
        | (u64::from(state.t1) << 47)
        | (u64::from(state.alive) << 53)
}

thread_local! {
    static ACTIVE: RefCell<Option<Recorder>> = const { RefCell::new(None) };
}

/// Run one already-prepared job with a private recorder on this thread.
/// Panics if nested; a panic in `work` clears the TLS before unwinding.
pub fn with_census<T>(work: impl FnOnce() -> T) -> (T, CensusStats) {
    ACTIVE.with(|cell| {
        let mut slot = cell.borrow_mut();
        assert!(slot.is_none(), "nested transposition census");
        *slot = Some(Recorder::default());
    });
    struct Clear;
    impl Drop for Clear {
        fn drop(&mut self) {
            ACTIVE.with(|cell| {
                cell.borrow_mut().take();
            });
        }
    }
    let clear = Clear;
    let result = work();
    let recorder = ACTIVE.with(|cell| cell.borrow_mut().take().expect("active census"));
    drop(clear);
    (result, recorder.finish())
}

#[inline]
pub(super) fn record(state: State, kind: Kind) {
    ACTIVE.with(|cell| {
        if let Some(recorder) = cell.borrow_mut().as_mut() {
            recorder.record(state, kind);
        }
    });
}

#[cfg(test)]
mod tests {
    use super::*;

    fn state(played: u32, alive: u8) -> State {
        State {
            played,
            plays: 0,
            len: 0,
            leader: 0,
            t1: 0,
            t0: 0,
            alive,
            #[cfg(feature = "compact-depth")]
            tricks_left: 7 - played.count_ones() as u8 / 4,
        }
    }

    #[test]
    fn counts_repeated_states_and_disjoint_subtrees() {
        let root = state(1, 3);
        let child = state(3, 3);
        let (_, stats) = with_census(|| {
            record(root, Kind::Window);
            record(child, Kind::Exact);
            record(root, Kind::Window);
            record(child, Kind::Exact);
        });
        assert_eq!(stats.visits, 4);
        assert_eq!(stats.unique_states, 2);
        assert_eq!(stats.duplicate_visits, 2);
        assert_eq!(stats.disjoint_duplicate_subtrees, 1);
        assert_eq!(stats.optimistic_saved_nodes, 2);
    }
}
