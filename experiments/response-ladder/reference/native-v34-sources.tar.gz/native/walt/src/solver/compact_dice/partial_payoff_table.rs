//! Immutable current-trick winner/point summary, keyed by a sentinel-prefixed
//! packed partial. No public state fields or random streams are changed.
//!
//! `cargo run -p walt --example generate_trick_table -- --partial --check`
//! verifies every byte against the canonical rule algebra, including repeated
//! tile tuples that cannot occur in a legal game.

const PER_DECL: usize = 1 << 16;
static TABLE: &[u8; 9 * PER_DECL * 2] = include_bytes!("partial_payoff_table.bin");

/// Bits: winner offset 0..1, guaranteed points 2..6, standing tile 7..11,
/// fixed lead context 12..14. The maximum points value is 31 (three repeated
/// ten-count tiles plus the trick point); real distinct partials need less.
#[inline]
pub(super) fn lookup(declaration: usize, len: u8, packed_plays: u32) -> u16 {
    debug_assert!(declaration < 9);
    debug_assert!((1..=3).contains(&len));
    debug_assert!(packed_plays < (1 << (5 * len)));
    let key = ((1u32 << (5 * len)) | packed_plays) as u16;
    let index = ((declaration << 16) | usize::from(key)) * 2;
    u16::from_le_bytes([TABLE[index], TABLE[index + 1]])
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::rules::{Decl, Domino};

    #[test]
    fn partial_payoff_table_matches_all_canonical_partials_including_repeats() {
        let mut checked = 0;
        for (di, decl) in Decl::ALL.into_iter().enumerate() {
            let mut used = vec![false; PER_DECL];
            for len in 1..=3u8 {
                for dense in 0..28usize.pow(u32::from(len)) {
                    let mut rest = dense;
                    let mut tiles = [0usize; 3];
                    let mut packed = 0u32;
                    for i in 0..usize::from(len) {
                        tiles[i] = rest % 28;
                        rest /= 28;
                        packed |= (tiles[i] as u32) << (5 * i);
                    }
                    let context = decl.led_context(Domino::ALL[tiles[0]]);
                    let mut winner = 0;
                    let mut points = 1;
                    for i in 0..usize::from(len) {
                        points += Domino::ALL[tiles[i]].count();
                        if decl.trick_key(Domino::ALL[tiles[i]], context)
                            > decl.trick_key(Domino::ALL[tiles[winner]], context) {
                            winner = i;
                        }
                    }
                    let expected = (winner as u16) | ((points as u16) << 2)
                        | ((tiles[winner] as u16) << 7) | ((context.index() as u16) << 12);
                    assert_eq!(lookup(di, len, packed), expected,
                        "declaration={di} len={len} packed={packed}");
                    let key = ((1 << (5 * len)) | packed) as usize;
                    assert!(!used[key], "sentinel key collision");
                    used[key] = true;
                    checked += 1;
                }
            }
            for (key, used) in used.into_iter().enumerate() {
                if !used {
                    let at = (di * PER_DECL + key) * 2;
                    assert_eq!(&TABLE[at..at + 2], &[0, 0], "unused slot must be zero");
                }
            }
        }
        assert_eq!(checked, 9 * (28 + 28 * 28 + 28 * 28 * 28));
    }
}
