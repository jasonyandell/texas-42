//! Per-sample Dice continuation once the viewer has only one tile left.
//!
//! The viewer's remaining action is forced, so independently rolling each
//! original sample ID cannot fuse incompatible viewer strategies. Field
//! choices still use their own original Dice tape and public record hash.

use super::{Bounds, Search, SplitMix64, State};
#[cfg(feature = "transposition-census")]
use super::transposition_census::{self, Kind};

impl Search<'_> {
    /// The caller has already visited `state`, checked its terminal/last-trick
    /// guards, and established exactly one unplayed viewer tile. Every actual
    /// physical advance below is counted and checked through `visit`.
    pub(super) fn forced_tail_window(
        &mut self,
        state: State,
        alpha: i16,
        beta: i16,
    ) -> Option<Bounds> {
        debug_assert!(alpha < beta);
        debug_assert_eq!((self.hand & !state.played).count_ones(), 1);
        let mut remaining = state.alive.count_ones() as u8;
        let mut sum = 0u8;
        let mut alive = state.alive;
        while alive != 0 {
            let interval = Bounds {
                lo: sum,
                hi: sum + remaining,
            };
            if interval.separates(alpha, beta) {
                return Some(interval);
            }
            let sid = alive.trailing_zeros() as usize;
            alive &= alive - 1;
            remaining -= 1;
            sum += self.forced_tail_sample(state, sid)?;
        }
        Some(Bounds::exact(sum))
    }

    /// One original sample ID; no observed-action bucket is needed because
    /// every viewer action after this point is forced.
    fn forced_tail_sample(&mut self, state: State, sid: usize) -> Option<u8> {
        let id = 1u8 << sid;
        let mut current = State { alive: id, ..state };
        loop {
            if current.t1 >= self.sh.bid {
                return Some(1);
            }
            if current.t0 > 42 - self.sh.bid {
                return Some(0);
            }
            if current.is_last_trick() {
                return Some(self.last_trick(current));
            }
            let seat = (current.leader + current.len) & 3;
            let tile = if seat == self.viewer {
                let legal = self.legal(self.hand & !current.played, current);
                assert!(legal.is_power_of_two(), "forced viewer has one legal tile");
                self.viewer_legal += 1;
                self.viewer_children += 1;
                legal.trailing_zeros()
            } else {
                let mut legal =
                    self.legal(self.worlds[sid][seat as usize] & !current.played, current);
                let choices = legal.count_ones();
                assert!(choices > 0, "sampled field hand has a legal tile");
                if choices > 1 {
                    let mut rng = SplitMix64(self.seeds[sid] ^ Self::record_hash(current));
                    let skip = rng.below(u64::from(choices));
                    for _ in 0..skip {
                        legal &= legal - 1;
                    }
                }
                legal.trailing_zeros()
            };
            current = self.advance(current, tile, id);
            self.visit()?;
            #[cfg(feature = "transposition-census")]
            transposition_census::record(current, Kind::Window);
        }
    }
}

#[cfg(all(test, feature = "parallel"))]
mod tests {
    use super::*;
    use crate::rules::rules::{legal_plays, Trick};
    use crate::rules::{Decl, Domino, Seat, Team};
    use crate::solver::{self, Deadline, Field, Key, Shared, Solver};
    use num_rational::BigRational;
    use std::sync::Arc;
    use std::time::Duration;

    fn fixture(decl: Decl, partial: usize, salt: u64) -> (Key, [u32; 4], Seat, u8, u32) {
        for attempt in 0..1_000u64 {
            let mut rng = SplitMix64(0x8b50_0000_7331_0021 ^ salt ^ attempt);
            let mut deck: [u8; 28] = std::array::from_fn(|i| i as u8);
            for i in (1..28).rev() {
                deck.swap(i, rng.below((i + 1) as u64) as usize);
            }
            let mut hands = [0u32; 4];
            for (seat, tiles) in deck.chunks_exact(7).enumerate() {
                hands[seat] = tiles.iter().fold(0, |mask, &tile| mask | (1 << tile));
            }
            let mut key = Key {
                voids: None,
                played: 0,
                leader: 0,
                plays: Vec::new(),
                banked_t1: 0,
                banked_t0: 0,
                alive: 0,
            };
            for _ in 0..5 {
                let leader = key.leader as usize;
                let mut tiles = [0u8; 4];
                for i in 0..4 {
                    let seat = (leader + i) & 3;
                    let led = (i > 0).then(|| decl.led_context(Domino::ALL[tiles[0] as usize]));
                    let legal = legal_plays(decl, solver::set_of(hands[seat]), led).bits();
                    let tile = legal.trailing_zeros() as u8;
                    tiles[i] = tile;
                    hands[seat] &= !(1 << tile);
                    key.played |= 1 << tile;
                }
                let trick = Trick::new(
                    Seat::from_index(leader).unwrap(),
                    tiles.map(|tile| Domino::ALL[tile as usize]),
                )
                .unwrap();
                let winner = trick.winner(decl);
                if winner.team() == Team::T1 {
                    key.banked_t1 += trick.points() as u8;
                } else {
                    key.banked_t0 += trick.points() as u8;
                }
                key.leader = winner.index() as u8;
            }
            let Some(bid) = (30..=42).find(|&b| key.banked_t1 < b && key.banked_t0 <= 42 - b)
            else {
                continue;
            };
            let boundary = key.played;
            let viewer = Seat::from_index(key.leader as usize).unwrap();
            for i in 0..partial {
                let seat = (usize::from(key.leader) + i) & 3;
                let led = key
                    .plays
                    .first()
                    .map(|&tile| decl.led_context(Domino::ALL[tile as usize]));
                let legal = legal_plays(decl, solver::set_of(hands[seat]), led).bits();
                let tile = legal.trailing_zeros() as u8;
                hands[seat] &= !(1 << tile);
                key.played |= 1 << tile;
                key.plays.push(tile);
            }
            assert_eq!(hands[viewer.index()].count_ones(), 1);
            return (key, hands, viewer, bid, boundary);
        }
        panic!("no undecided two-trick fixture");
    }

    fn search<'a>(
        sh: &'a Shared,
        worlds: &'a [[u32; 4]],
        seeds: &'a [u64],
        di: usize,
        viewer: Seat,
        hand: u32,
    ) -> Search<'a> {
        Search {
            rules: &super::super::RULES[di],
            sh,
            worlds,
            seeds,
            viewer: viewer.index() as u8,
            hand,
            maximize: viewer.team() == Team::T1,
            nodes: 0,
            viewer_children: 0,
            viewer_legal: 0,
        }
    }

    #[test]
    fn overlapping_worlds_match_general_solver_at_partial_roots_and_windows() {
        for (di, decl) in Decl::ALL.into_iter().enumerate() {
            for partial in 1..=3 {
                let (key, remaining, viewer, bid, boundary) =
                    fixture(decl, partial, (di * 4 + partial) as u64);
                let hand = remaining[viewer.index()];
                let acting = (usize::from(key.leader) + key.plays.len()) & 3;
                assert_ne!(acting, viewer.index());
                let mut worlds = [remaining, remaining];
                let others: Vec<usize> = (0..4)
                    .filter(|&seat| seat != viewer.index() && seat != acting)
                    .collect();
                let a = worlds[1][others[0]].trailing_zeros();
                let b = worlds[1][others[1]].trailing_zeros();
                worlds[1][others[0]] ^= (1 << a) | (1 << b);
                worlds[1][others[1]] ^= (1 << a) | (1 << b);
                assert_ne!(worlds[0], worlds[1]);
                let sh = Arc::new(Shared::new(
                    decl,
                    bid,
                    vec![2],
                    boundary,
                    2,
                    Deadline::after(Duration::from_secs(10)),
                ));
                let mut packed = 0u32;
                for (i, &tile) in key.plays.iter().enumerate() {
                    packed |= u32::from(tile) << (5 * i);
                }
                let root = State {
                    played: key.played,
                    plays: packed,
                    len: key.plays.len() as u8,
                    leader: key.leader,
                    t1: key.banked_t1,
                    t0: key.banked_t0,
                    alive: 0b11,
                    #[cfg(feature = "compact-depth")]
                    tricks_left: super::super::tricks_left_at_root(&key),
                };
                let mut seeds = [0xabb5_0234_6789_abcd, 0];
                let overlapping = (1..1_000u64).any(|candidate| {
                    seeds[1] = candidate;
                    let probe = search(&sh, &worlds, &seeds, di, viewer, hand);
                    let (buckets, _) = probe.field_buckets(root, acting as u8);
                    buckets.iter().any(|bucket| bucket.count_ones() == 2)
                });
                assert!(overlapping, "fixture must retain an observed overlap");

                let reference = Solver::new(
                    Arc::clone(&sh),
                    viewer,
                    hand,
                    viewer.team() == Team::T1,
                    worlds.to_vec(),
                    seeds.to_vec(),
                    Field::Dice,
                )
                .solve(&key)
                .unwrap();
                let mut exact = search(&sh, &worlds, &seeds, di, viewer, hand);
                exact.visit().unwrap(); // the parent dispatch visits this state
                let count = exact.forced_tail_window(root, -1, 3).unwrap();
                assert_eq!(count.lo, count.hi);
                assert!(exact.nodes > 1, "physical advances must be counted");
                assert_eq!(
                    reference,
                    BigRational::new(i64::from(count.lo).into(), 2.into()),
                    "declaration={decl} partial={partial}",
                );
                for threshold in 0..=3 {
                    let mut probe = search(&sh, &worlds, &seeds, di, viewer, hand);
                    probe.visit().unwrap();
                    let alpha = threshold - 1;
                    let bounds = probe.forced_tail_window(root, alpha, threshold).unwrap();
                    assert!(bounds.separates(alpha, threshold));
                    assert!(bounds.lo <= count.lo && count.lo <= bounds.hi);
                }
            }
        }
    }
}
