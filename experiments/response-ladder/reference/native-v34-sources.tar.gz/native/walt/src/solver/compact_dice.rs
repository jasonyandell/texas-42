//! Allocation-free CPU recurrence for small fixed Dice bundles.
//!
//! This is an implementation of the existing sampled Dice value, not a new
//! policy or sampler. Sample IDs remain distinct even when deals repeat.

use super::{mix, Key, Shared, Solver, SplitMix64, FULL_MASK};
#[cfg(feature = "profile-phases")]
use crate::clock::Instant;
use crate::rules::{Context, Decl, Domino};
#[cfg(feature = "profile-phases")]
use std::sync::atomic::AtomicU64;
use std::sync::atomic::Ordering;

/// Process-wide sampled costs for stack-prepared L0 Dice choices.
/// Snapshots taken during concurrent work may observe partially updated totals.
#[cfg(feature = "profile-phases")]
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct CompactPhaseProfile {
    pub samples: u64,
    pub prepare_ns: u64,
    pub search_ns: u64,
    pub nodes: u64,
}

#[cfg(feature = "profile-phases")]
static PROFILE_SAMPLES: AtomicU64 = AtomicU64::new(0);
#[cfg(feature = "profile-phases")]
static PROFILE_PREPARE_NS: AtomicU64 = AtomicU64::new(0);
#[cfg(feature = "profile-phases")]
static PROFILE_SEARCH_NS: AtomicU64 = AtomicU64::new(0);
#[cfg(feature = "profile-phases")]
static PROFILE_NODES: AtomicU64 = AtomicU64::new(0);

#[cfg(feature = "profile-phases")]
pub fn compact_phase_profile() -> CompactPhaseProfile {
    CompactPhaseProfile {
        samples: PROFILE_SAMPLES.load(Ordering::Relaxed),
        prepare_ns: PROFILE_PREPARE_NS.load(Ordering::Relaxed),
        search_ns: PROFILE_SEARCH_NS.load(Ordering::Relaxed),
        nodes: PROFILE_NODES.load(Ordering::Relaxed),
    }
}

#[cfg(feature = "certified-trick-payoff")]
mod certified_payoff;
#[cfg(feature = "table-certified-payoff")]
mod partial_payoff_table;
#[cfg(feature = "singleton-dice")]
mod singleton;
#[cfg(feature = "const-objective")]
mod const_objective;
#[cfg(feature = "trick-table")]
mod trick_table;
#[cfg(feature = "extremum-choice")]
mod extremum;
#[cfg(feature = "forced-viewer-tail")]
mod forced_tail;
#[cfg(feature = "two-trick-sum")]
mod two_trick;
#[cfg(feature = "natural-job-capture")]
pub(super) mod capture;
#[cfg(feature = "transposition-census")]
pub(super) mod transposition_census;

/// Completed-trick winner offset from the leader and point count.
#[cfg(feature = "trick-table")]
#[inline]
pub(super) fn trick_outcome(decl: Decl, packed_plays: u32) -> (u8, u8) {
    let di = match decl {
        Decl::PipTrump(pip) => pip.value() as usize,
        Decl::DoublesTrump => 7,
        Decl::NoTrump => 8,
    };
    trick_table::resolve(di, packed_plays)
}

// A packed tile uses five bits, so valid 0..28 tile indices can be accessed
// through a 32-entry array without a runtime length branch. Invalid public
// tiles are still rejected at the existing API boundary; the debug checks at
// the indexed uses below keep that invariant visible during development.
const TILE_SLOTS: usize = if cfg!(feature = "padded-compact-tables") { 32 } else { 28 };

#[derive(Clone, Copy)]
struct Rules {
    #[cfg(feature = "trick-table")]
    declaration: u8,
    led: [u8; TILE_SLOTS],
    incidence: [u32; 8],
    strength: [[u8; 28]; 8],
    count: [u8; 28],
}

const EMPTY_RULES: Rules = Rules {
    #[cfg(feature = "trick-table")]
    declaration: 0,
    led: [0; TILE_SLOTS],
    incidence: [0; 8],
    strength: [[0; 28]; 8],
    count: [0; 28],
};

// Build from the authoritative rule algebra at compile time. This adds no
// first-decision initialization cost and stores no sampled or policy state.
const RULES: [Rules; Decl::COUNT] = {
    let mut all = [EMPTY_RULES; Decl::COUNT];
    let mut di = 0;
    while di < Decl::COUNT {
        let decl = Decl::ALL[di];
        #[cfg(feature = "trick-table")]
        {
            all[di].declaration = di as u8;
        }
        let mut t = 0;
        while t < Domino::COUNT {
            let tile = Domino::ALL[t];
            let context = decl.led_context(tile).index();
            assert!(context < Context::COUNT && Context::COUNT == 8);
            all[di].led[t] = context as u8;
            all[di].count[t] = tile.count() as u8;
            t += 1;
        }
        let mut q = 0;
        while q < Context::COUNT {
            let context = Context::ALL[q];
            all[di].incidence[q] = decl.effective_incidence(context).bits();
            let mut tile = 0;
            while tile < Domino::COUNT {
                let k = decl.trick_key(Domino::ALL[tile], context);
                all[di].strength[q][tile] = (k.tier as u8) * 16 + k.rank.value();
                tile += 1;
            }
            q += 1;
        }
        di += 1;
    }
    all
};

#[derive(Clone, Copy)]
struct State {
    played: u32,
    plays: u32,
    len: u8,
    leader: u8,
    t1: u8,
    t0: u8,
    alive: u8,
    #[cfg(feature = "compact-depth")]
    tricks_left: u8,
}

impl State {
    #[inline]
    fn is_last_trick(self) -> bool {
        #[cfg(feature = "compact-depth")]
        {
            self.tricks_left == 1
        }
        #[cfg(not(feature = "compact-depth"))]
        {
            (FULL_MASK & !self.played).count_ones() + u32::from(self.len) == 4
        }
    }
}

#[cfg(feature = "compact-depth")]
fn tricks_left_at_root(key: &Key) -> u8 {
    // The current unfinished trick contributes its already played tiles.
    // Every complete or future trick contributes exactly four physical tiles.
    let remaining = (FULL_MASK & !key.played).count_ones() + key.plays.len() as u32;
    assert_eq!(remaining % 4, 0, "public prefix has whole trick capacity");
    assert!(remaining <= 28, "at most seven tricks remain");
    (remaining / 4) as u8
}

#[cfg(feature = "bounded-choice")]
#[derive(Clone, Copy, Debug)]
struct Bounds {
    lo: u8,
    hi: u8,
}

#[cfg(feature = "bounded-choice")]
impl Bounds {
    fn exact(value: u8) -> Self {
        Self {
            lo: value,
            hi: value,
        }
    }

    fn separates(self, alpha: i16, beta: i16) -> bool {
        self.lo == self.hi || i16::from(self.hi) <= alpha || i16::from(self.lo) >= beta
    }
}

struct Search<'a> {
    rules: &'static Rules,
    sh: &'a Shared,
    worlds: &'a [[u32; 4]],
    seeds: &'a [u64],
    viewer: u8,
    hand: u32,
    maximize: bool,
    nodes: u64,
    viewer_children: u64,
    viewer_legal: u64,
}

#[cfg(any(feature = "compact-order", feature = "root-pivot"))]
#[derive(Clone, Copy)]
struct PriorityContext {
    led: Option<usize>,
    best: u8,
    count: u16,
    own_team: bool,
}

struct ViewerMoves {
    #[cfg(feature = "compact-order")]
    tiles: [u8; 7],
    #[cfg(feature = "compact-order")]
    priorities: [u16; 7],
    #[cfg(feature = "compact-order")]
    len: u8,
    #[cfg(feature = "compact-order")]
    pos: u8,
    #[cfg(not(feature = "compact-order"))]
    mask: u32,
}

impl Iterator for ViewerMoves {
    type Item = u32;

    #[inline]
    fn next(&mut self) -> Option<u32> {
        #[cfg(feature = "compact-order")]
        {
            if self.pos == self.len {
                return None;
            }
            let tile = self.tiles[self.pos as usize];
            self.pos += 1;
            Some(u32::from(tile))
        }
        #[cfg(not(feature = "compact-order"))]
        {
            if self.mask == 0 {
                return None;
            }
            let tile = self.mask.trailing_zeros();
            self.mask &= self.mask - 1;
            Some(tile)
        }
    }
}

impl Search<'_> {
    #[inline]
    fn led_context(&self, tile: usize) -> usize {
        #[cfg(feature = "padded-compact-tables")]
        {
            debug_assert!(tile < Domino::COUNT, "packed tile is canonical");
            // RULES is constructed above from Context::index() and checked
            // at compile time. Masking its static 0..7 value makes the
            // incidence-table access statically in bounds in optimized code.
            let context = self.rules.led[tile];
            debug_assert!(usize::from(context) < Context::COUNT);
            usize::from(context & 7)
        }
        #[cfg(not(feature = "padded-compact-tables"))]
        {
            self.rules.led[tile] as usize
        }
    }

    #[cfg(any(feature = "compact-order", feature = "root-pivot"))]
    fn priority_context(&self, state: State) -> PriorityContext {
        if state.len == 0 {
            return PriorityContext {
                led: None,
                best: 0,
                count: 0,
                own_team: false,
            };
        }
        let q = self.led_context((state.plays & 31) as usize);
        let mut best = 0u8;
        let mut winner_at = 0u8;
        let mut count = 0u16;
        for i in 0..state.len {
            let t = ((state.plays >> (5 * i)) & 31) as usize;
            let rank = self.rules.strength[q][t];
            if i == 0 || rank > best {
                best = rank;
                winner_at = i;
            }
            count += u16::from(self.rules.count[t]);
        }
        PriorityContext {
            led: Some(q),
            best,
            count,
            own_team: ((state.leader + winner_at) & 1) == (self.viewer & 1),
        }
    }

    #[cfg(any(feature = "compact-order", feature = "root-pivot"))]
    #[inline]
    fn viewer_priority(&self, context: PriorityContext, tile: u8) -> u16 {
        let t = usize::from(tile);
        if let Some(q) = context.led {
            if self.rules.strength[q][t] > context.best {
                1000 + context.count + u16::from(self.rules.count[t])
            } else if context.own_team {
                20 + u16::from(self.rules.count[t])
            } else {
                10 - u16::from(self.rules.count[t])
            }
        } else {
            let led = self.led_context(t);
            let key = self.rules.strength[led][t];
            100 * u16::from(key >> 4) + u16::from(key & 15)
        }
    }

    #[inline]
    fn viewer_moves(&self, state: State, legal: u32) -> ViewerMoves {
        #[cfg(not(feature = "compact-order"))]
        {
            let _ = state;
            ViewerMoves { mask: legal }
        }
        #[cfg(feature = "compact-order")]
        {
            let mut moves = ViewerMoves {
                tiles: [0; 7],
                priorities: [0; 7],
                len: 0,
                pos: 0,
            };
            let count = legal.count_ones() as usize;
            debug_assert!(count <= 7, "a physical hand holds at most seven tiles");
            if count <= 1 {
                if count == 1 {
                    moves.tiles[0] = legal.trailing_zeros() as u8;
                    moves.len = 1;
                }
                return moves;
            }
            let context = self.priority_context(state);
            let mut remaining = legal;
            while remaining != 0 {
                let tile = remaining.trailing_zeros() as usize;
                remaining &= remaining - 1;
                let priority = self.viewer_priority(context, tile as u8);
                let mut at = moves.len as usize;
                while at > 0
                    && (moves.priorities[at - 1] < priority
                        || (moves.priorities[at - 1] == priority
                            && moves.tiles[at - 1] > tile as u8))
                {
                    moves.priorities[at] = moves.priorities[at - 1];
                    moves.tiles[at] = moves.tiles[at - 1];
                    at -= 1;
                }
                moves.priorities[at] = priority;
                moves.tiles[at] = tile as u8;
                moves.len += 1;
            }
            moves
        }
    }
    #[inline]
    fn alive_len(state: State) -> u8 {
        state.alive.count_ones() as u8
    }

    #[inline]
    fn legal(&self, hand: u32, state: State) -> u32 {
        if state.len == 0 {
            return hand;
        }
        let lead = (state.plays & 31) as usize;
        let q = self.led_context(lead);
        let follows = hand & self.rules.incidence[q];
        if follows == 0 {
            hand
        } else {
            follows
        }
    }

    #[inline]
    fn advance(&self, state: State, tile: u32, alive: u8) -> State {
        let mut next = State {
            played: state.played | (1 << tile),
            plays: state.plays | (tile << (5 * state.len)),
            len: state.len + 1,
            alive,
            ..state
        };
        if state.len == 3 {
            #[cfg(feature = "compact-depth")]
            {
                debug_assert!(state.tricks_left > 0);
                next.tricks_left = state.tricks_left - 1;
            }
            #[cfg(feature = "trick-table")]
            let (winner_at, points) =
                trick_table::resolve(self.rules.declaration as usize, next.plays);
            #[cfg(not(feature = "trick-table"))]
            let (winner_at, points) = {
                let q = self.led_context((state.plays & 31) as usize);
                let mut highest = 0;
                let mut winner_at = 0;
                let mut points = 1u8;
                let mut i = 0;
                while i < 4 {
                    let t = ((next.plays >> (5 * i)) & 31) as usize;
                    let rank = self.rules.strength[q][t];
                    if i == 0 || rank > highest {
                        highest = rank;
                        winner_at = i;
                    }
                    points += self.rules.count[t];
                    i += 1;
                }
                (winner_at, points)
            };
            let winner = (state.leader + winner_at) & 3;
            next.leader = winner;
            next.plays = 0;
            next.len = 0;
            if winner & 1 == 1 {
                next.t1 += points;
            } else {
                next.t0 += points;
            }
        }
        next
    }

    #[inline]
    fn record_hash(state: State) -> u64 {
        let mut h = mix(u64::from(state.played));
        h = mix(h ^ (u64::from(state.leader) << 32));
        let mut i = 0;
        while i < state.len {
            h = mix(h ^ (0x100 | u64::from((state.plays >> (5 * i)) & 31)));
            i += 1;
        }
        h
    }

    #[inline]
    fn visit(&mut self) -> Option<()> {
        self.nodes += 1;
        if self.sh.dead.load(Ordering::Relaxed) {
            return None;
        }
        if ((!cfg!(feature = "coalesced-deadlines") && self.nodes == 1)
            || self.nodes & 0xff == 0) && self.sh.deadline.passed() {
            self.sh.dead.store(true, Ordering::Relaxed);
            return None;
        }
        Some(())
    }

    // At the last trick every not-yet-acting seat has one tile in each world.
    // Resolve those forced plays directly, including a root inside the trick.
    fn last_trick(&self, state: State) -> u8 {
        let mut alive = state.alive;
        let mut wins = 0;
        while alive != 0 {
            let sid = alive.trailing_zeros() as usize;
            alive &= alive - 1;
            #[cfg(feature = "trick-table")]
            {
                let mut plays = state.plays;
                let mut played = state.played;
                let mut i = state.len;
                while i < 4 {
                    let seat = ((state.leader + i) & 3) as usize;
                    let hand = if seat as u8 == self.viewer {
                        self.hand & !played
                    } else {
                        self.worlds[sid][seat] & !played
                    };
                    debug_assert_eq!(hand.count_ones(), 1);
                    let tile = hand.trailing_zeros();
                    plays |= tile << (5 * i);
                    played |= 1 << tile;
                    i += 1;
                }
                let (winner_at, points) =
                    trick_table::resolve(self.rules.declaration as usize, plays);
                let winner = (state.leader + winner_at) & 3;
                let t1 = state.t1 + if winner & 1 == 1 { points } else { 0 };
                wins += u8::from(t1 >= self.sh.bid);
            }
            #[cfg(not(feature = "trick-table"))]
            {
                let mut next = state;
                while next.len != 0 || next.played != FULL_MASK {
                    let seat = ((next.leader + next.len) & 3) as usize;
                    let hand = if seat as u8 == self.viewer {
                        self.hand & !next.played
                    } else {
                        self.worlds[sid][seat] & !next.played
                    };
                    debug_assert_eq!(hand.count_ones(), 1);
                    next = self.advance(next, hand.trailing_zeros(), 1 << sid);
                }
                wins += u8::from(next.t1 >= self.sh.bid);
            }
        }
        wins
    }

    // Classify the entire surviving multiset before evaluating any observed
    // action child. A provisional bucket would change the viewer information
    // set, so this complete partition is shared by exact and bounded search.
    fn field_buckets(&self, state: State, seat: u8) -> ([u8; TILE_SLOTS], u32) {
        let mut buckets = [0u8; TILE_SLOTS];
        let mut occupied = 0u32;
        let mut alive = state.alive;
        #[cfg(not(feature = "lazy-record-hash"))]
        let hash = Self::record_hash(state);
        #[cfg(feature = "lazy-record-hash")]
        let mut hash = None;
        while alive != 0 {
            let sid = alive.trailing_zeros() as usize;
            alive &= alive - 1;
            let mut legal = self.legal(self.worlds[sid][seat as usize] & !state.played, state);
            let choices = legal.count_ones();
            debug_assert!(choices > 0);
            if choices > 1 {
                #[cfg(feature = "lazy-record-hash")]
                let hash = *hash.get_or_insert_with(|| Self::record_hash(state));
                let mut rng = SplitMix64(self.seeds[sid] ^ hash);
                let skip = rng.below(u64::from(choices));
                let mut i = 0;
                while i < skip {
                    legal &= legal - 1;
                    i += 1;
                }
            }
            let tile = legal.trailing_zeros();
            #[cfg(feature = "padded-compact-tables")]
            debug_assert!((tile as usize) < Domino::COUNT, "legal tile is canonical");
            buckets[tile as usize] |= 1 << sid;
            occupied |= 1 << tile;
        }
        (buckets, occupied)
    }

    #[cfg(not(feature = "const-objective"))]
    fn solve(&mut self, state: State) -> Option<u8> {
        self.visit()?;
        #[cfg(feature = "transposition-census")]
        transposition_census::record(state, transposition_census::Kind::Exact);
        #[cfg(feature = "certified-trick-payoff")]
        {
            let certificate = self.certified_before_dispatch(state);
            if certificate.settled != 0 {
                let residual = certificate.residual(state);
                if residual.alive == 0 { return Some(certificate.wins); }
                return self.solve_after_visit(residual).map(|value| certificate.wins + value);
            }
        }
        self.solve_after_visit(state)
    }

    // Same physical state, already visited. Certificate projection enters here
    // directly, so it neither visits twice nor recertifies the same support.
    #[cfg(not(feature = "const-objective"))]
    #[inline]
    fn solve_after_visit(&mut self, state: State) -> Option<u8> {
        #[cfg(feature = "singleton-dice")]
        if state.alive.is_power_of_two() {
            return self.singleton_solve(state);
        }
        if state.t1 >= self.sh.bid {
            return Some(Self::alive_len(state));
        }
        if state.t0 > 42 - self.sh.bid {
            return Some(0);
        }
        if state.is_last_trick() {
            return Some(self.last_trick(state));
        }
        #[cfg(feature = "two-trick-sum")]
        if self.has_two_trick_tail(state) {
            return self.two_trick_window(state, -1, i16::from(Self::alive_len(state)) + 1)
                .map(|bounds| bounds.lo);
        }
        #[cfg(feature = "forced-viewer-tail")]
        if (self.hand & !state.played).is_power_of_two() {
            let bounds = self.forced_tail_window(state, -1, i16::from(Self::alive_len(state)) + 1)?;
            debug_assert_eq!(bounds.lo, bounds.hi);
            return Some(bounds.lo);
        }
        let seat = (state.leader + state.len) & 3;
        if seat == self.viewer {
            let legal = self.legal(self.hand & !state.played, state);
            let mass = Self::alive_len(state);
            let mut best = if self.maximize { 0 } else { mass };
            self.viewer_legal += u64::from(legal.count_ones());
            for tile in self.viewer_moves(state, legal) {
                self.viewer_children += 1;
                let child = self.advance(state, tile, state.alive);
                let value = self.solve(child)?;
                if self.maximize {
                    best = best.max(value);
                } else {
                    best = best.min(value);
                }
                if (self.maximize && best == mass) || (!self.maximize && best == 0) {
                    break;
                }
            }
            Some(best)
        } else {
            let (buckets, mut occupied) = self.field_buckets(state, seat);
            let mut total = 0;
            while occupied != 0 {
                let tile = occupied.trailing_zeros();
                occupied &= occupied - 1;
                total += self.solve(self.advance(state, tile, buckets[tile as usize]))?;
            }
            Some(total)
        }
    }

    /// Return an exact count or a sound interval wholly outside the open
    /// integer window (alpha, beta). Neither interval endpoint is treated as
    /// an exact value unless the endpoints coincide.
    #[cfg(all(feature = "bounded-choice", not(feature = "const-objective")))]
    fn window(&mut self, state: State, alpha: i16, beta: i16) -> Option<Bounds> {
        debug_assert!(alpha < beta);
        self.visit()?;
        #[cfg(feature = "transposition-census")]
        transposition_census::record(state, transposition_census::Kind::Window);
        #[cfg(feature = "certified-trick-payoff")]
        {
            let initial = Bounds { lo: 0, hi: Self::alive_len(state) };
            if initial.separates(alpha, beta) { return Some(initial); }
            let certificate = self.certified_before_dispatch(state);
            if certificate.settled != 0 {
                let residual = certificate.residual(state);
                if residual.alive == 0 { return Some(Bounds::exact(certificate.wins)); }
                let (alpha, beta) = certificate.shift(alpha, beta);
                // The continuation recomputes initial bounds for residual mass.
                return self.window_after_visit(residual, alpha, beta)
                    .map(|bounds| certificate.restore(bounds));
            }
        }
        self.window_after_visit(state, alpha, beta)
    }

    #[cfg(all(feature = "bounded-choice", not(feature = "const-objective")))]
    #[inline]
    fn window_after_visit(&mut self, state: State, alpha: i16, beta: i16) -> Option<Bounds> {
        let mass = Self::alive_len(state);
        let initial = Bounds { lo: 0, hi: mass };
        if initial.separates(alpha, beta) {
            return Some(initial);
        }
        #[cfg(feature = "singleton-dice")]
        if state.alive.is_power_of_two() {
            return self.singleton_solve(state).map(Bounds::exact);
        }
        if state.t1 >= self.sh.bid {
            return Some(Bounds::exact(mass));
        }
        if state.t0 > 42 - self.sh.bid {
            return Some(Bounds::exact(0));
        }
        if state.is_last_trick() {
            return Some(Bounds::exact(self.last_trick(state)));
        }
        #[cfg(feature = "two-trick-sum")]
        if self.has_two_trick_tail(state) {
            return self.two_trick_window(state, alpha, beta);
        }
        #[cfg(feature = "forced-viewer-tail")]
        if (self.hand & !state.played).is_power_of_two() {
            return self.forced_tail_window(state, alpha, beta);
        }
        let seat = (state.leader + state.len) & 3;
        if seat == self.viewer {
            let legal = self.legal(self.hand & !state.played, state);
            self.viewer_legal += u64::from(legal.count_ones());
            if self.maximize {
                let mut lower = 0u8;
                let mut upper = 0u8;
                for tile in self.viewer_moves(state, legal) {
                    if i16::from(lower) >= beta {
                        return Some(Bounds {
                            lo: lower,
                            hi: mass,
                        });
                    }
                    self.viewer_children += 1;
                    let child = self.advance(state, tile, state.alive);
                    let bounds = self.window(child, alpha.max(i16::from(lower)), beta)?;
                    lower = lower.max(bounds.lo);
                    upper = upper.max(bounds.hi);
                }
                let bounds = Bounds {
                    lo: lower,
                    hi: upper,
                };
                debug_assert!(bounds.separates(alpha, beta));
                Some(bounds)
            } else {
                let mut lower = mass;
                let mut upper = mass;
                for tile in self.viewer_moves(state, legal) {
                    if i16::from(upper) <= alpha {
                        return Some(Bounds { lo: 0, hi: upper });
                    }
                    self.viewer_children += 1;
                    let child = self.advance(state, tile, state.alive);
                    let bounds = self.window(child, alpha, beta.min(i16::from(upper)))?;
                    lower = lower.min(bounds.lo);
                    upper = upper.min(bounds.hi);
                }
                let bounds = Bounds {
                    lo: lower,
                    hi: upper,
                };
                debug_assert!(bounds.separates(alpha, beta));
                Some(bounds)
            }
        } else {
            let (buckets, mut occupied) = self.field_buckets(state, seat);
            let mut sum = 0u8;
            let mut remaining = mass;
            while occupied != 0 {
                if i16::from(sum) >= beta {
                    return Some(Bounds {
                        lo: sum,
                        hi: sum + remaining,
                    });
                }
                if i16::from(sum + remaining) <= alpha {
                    return Some(Bounds {
                        lo: sum,
                        hi: sum + remaining,
                    });
                }
                let tile = occupied.trailing_zeros();
                occupied &= occupied - 1;
                let bucket = buckets[tile as usize];
                let child_mass = bucket.count_ones() as u8;
                remaining -= child_mass;
                let child = self.advance(state, tile, bucket);
                let bounds = self.window(
                    child,
                    alpha - i16::from(sum) - i16::from(remaining),
                    beta - i16::from(sum),
                )?;
                if bounds.lo == bounds.hi {
                    sum += bounds.lo;
                } else {
                    let parent = Bounds {
                        lo: sum + bounds.lo,
                        hi: sum + bounds.hi + remaining,
                    };
                    debug_assert!(parent.separates(alpha, beta));
                    return Some(parent);
                }
            }
            Some(Bounds::exact(sum))
        }
    }

    fn finished(&self) -> bool {
        if self.sh.dead.load(Ordering::Relaxed) || self.sh.deadline.passed() {
            self.sh.dead.store(true, Ordering::Relaxed);
            false
        } else {
            true
        }
    }

    // Root entry, periodic visits and final publication retain clock checks.
    // Between root candidates a cancellation load is enough; a bounded
    // candidate may finish after expiry but its answer is then refused.
    fn continue_search(&self) -> bool {
        #[cfg(feature = "coalesced-deadlines")]
        { !self.sh.dead.load(Ordering::Relaxed) }
        #[cfg(not(feature = "coalesced-deadlines"))]
        { self.finished() }
    }

    fn report(&self, solver: &Solver, key: &Key) {
        solver.sh.compact_dice_calls.fetch_add(1, Ordering::Relaxed);
        solver
            .sh
            .compact_dice_nodes
            .fetch_add(self.nodes, Ordering::Relaxed);
        let remaining_tricks = (FULL_MASK & !key.played).count_ones() + key.plays.len() as u32;
        solver
            .sh
            .compact_dice_max_tricks
            .fetch_max(u64::from(remaining_tricks / 4), Ordering::Relaxed);
        solver.sh.nodes.fetch_add(self.nodes, Ordering::Relaxed);
        solver
            .local_viewer_children
            .fetch_add(self.viewer_children, Ordering::Relaxed);
        solver
            .local_viewer_legal
            .fetch_add(self.viewer_legal, Ordering::Relaxed);
    }
}

fn start<'a>(solver: &'a Solver, key: &Key) -> Option<(Search<'a>, State)> {
    if solver.field != super::Field::Dice
        || solver.parallel
        || !(1..=8).contains(&solver.worlds.len())
        || solver.seeds.len() != solver.worlds.len()
        || key.plays.len() > 3
        || (usize::from(key.leader) + key.plays.len()) % 4 != solver.viewer.index()
    {
        return None;
    }
    solver.check_belief_key(key);
    let mut packed_plays = 0u32;
    for (i, &tile) in key.plays.iter().enumerate() {
        packed_plays |= u32::from(tile) << (5 * i);
    }
    let full = ((1u16 << solver.worlds.len()) - 1) as u8;
    let root = State {
        played: key.played,
        plays: packed_plays,
        len: key.plays.len() as u8,
        leader: key.leader,
        t1: key.banked_t1,
        t0: key.banked_t0,
        alive: full,
        #[cfg(feature = "compact-depth")]
        tricks_left: tricks_left_at_root(key),
    };
    let di = Decl::ALL
        .iter()
        .position(|&d| d == solver.sh.dcl)
        .expect("declaration");
    let search = Search {
        rules: &RULES[di],
        sh: &solver.sh,
        worlds: &solver.worlds,
        seeds: &solver.seeds,
        viewer: solver.viewer.index() as u8,
        hand: solver.viewer_hand0,
        maximize: solver.maximize,
        nodes: 0,
        viewer_children: 0,
        viewer_legal: 0,
    };
    Some((search, root))
}

/// `None`: ineligible, use the original solver. `Some(None)`: deadline or
/// cancellation; `Some(Some(counts))`: complete values in caller order.
#[cfg(feature = "const-objective")]
fn collect_values_const<const MAX: bool>(
    search: &mut Search<'_>, root: State, tiles: &[u8],
) -> Option<Vec<u8>> {
    let mut counts = Vec::with_capacity(tiles.len());
    for &tile in tiles {
        if !search.finished() { return None; }
        let child = search.advance(root, u32::from(tile), root.alive);
        counts.push(search.solve_const::<MAX>(child)?);
    }
    search.finished().then_some(counts)
}

pub(super) fn action_values(solver: &Solver, key: &Key, tiles: &[u8]) -> Option<Option<Vec<u8>>> {
    let (mut search, root) = start(solver, key)?;
    // A caller may compare only a subset of legal actions, in any order.
    #[cfg(feature = "const-objective")]
    let result = if search.maximize {
        collect_values_const::<true>(&mut search, root, tiles)
    } else {
        collect_values_const::<false>(&mut search, root, tiles)
    };
    #[cfg(not(feature = "const-objective"))]
    let result = {
    let mut counts = Vec::with_capacity(tiles.len());
    for &tile in tiles {
        if !search.finished() {
            break;
        }
        let child = search.advance(root, u32::from(tile), root.alive);
        match search.solve(child) {
            Some(value) => counts.push(value),
            None => break,
        }
    }
    let complete = counts.len() == tiles.len() && search.finished();
    complete.then_some(counts)
    };
    search.report(solver, key);
    Some(result)
}

/// Choose the same tile as a full Fixed comparison. Root pivoting may visit a
/// higher tile first; an earlier tile can then replace on an exact value tie.
#[cfg(feature = "bounded-choice")]
pub(super) fn fixed_choice(solver: &Solver, key: &Key, tiles: &[u8]) -> Option<u8> {
    let (mut search, root) = start(solver, key).expect("modeled L0 Dice root is eligible");
    let result = choose_fixed(&mut search, root, tiles);
    search.report(solver, key);
    result
}

#[cfg(feature = "bounded-choice")]
#[cfg(feature = "root-pivot")]
fn root_pivot(search: &Search<'_>, root: State, tiles: &[u8]) -> u8 {
    let context = search.priority_context(root);
    let mut pivot = tiles[0];
    let mut best = search.viewer_priority(context, pivot);
    for &tile in &tiles[1..] {
        let priority = search.viewer_priority(context, tile);
        if priority > best {
            best = priority;
            pivot = tile;
        }
    }
    pivot
}

#[cfg(all(feature = "extremum-choice", not(feature = "const-objective")))]
fn choose_fixed(search: &mut Search<'_>, root: State, tiles: &[u8]) -> Option<u8> {
    extremum::choose(search, root, tiles)
}

#[cfg(all(feature = "bounded-choice", not(feature = "extremum-choice"), not(feature = "const-objective")))]
fn choose_fixed(search: &mut Search<'_>, root: State, tiles: &[u8]) -> Option<u8> {
    assert!(!tiles.is_empty(), "Fixed comparison has a legal candidate");
    assert!(
        tiles.windows(2).all(|w| w[0] < w[1]),
        "Fixed tie rule uses ascending candidates"
    );
    (|| {
        if !search.finished() {
            return None;
        }
        #[cfg(feature = "root-pivot")]
        let pivot = root_pivot(search, root, tiles);
        #[cfg(feature = "root-pivot")]
        let mut best_tile = pivot;
        #[cfg(not(feature = "root-pivot"))]
        let mut best_tile = tiles[0];
        let first = search.advance(root, u32::from(best_tile), root.alive);
        let mass = Search::alive_len(root);
        let first_bounds = search.window(first, -1, i16::from(mass) + 1)?;
        debug_assert_eq!(first_bounds.lo, first_bounds.hi);
        let mut best = first_bounds.lo;
        #[cfg(feature = "root-pivot")]
        let remaining = tiles;
        #[cfg(not(feature = "root-pivot"))]
        let remaining = &tiles[1..];
        for &tile in remaining {
            #[cfg(feature = "root-pivot")]
            if tile == pivot {
                continue;
            }
            if !search.continue_search() {
                return None;
            }
            #[cfg(feature = "root-pivot")]
            let earlier = tile < best_tile;
            #[cfg(not(feature = "root-pivot"))]
            let earlier = false;
            if ((search.maximize && best == mass) || (!search.maximize && best == 0)) && !earlier {
                break;
            }
            let child = search.advance(root, u32::from(tile), root.alive);
            let weak = if earlier { 1 } else { 0 };
            let (alpha, beta) = if search.maximize {
                (i16::from(best) - weak, i16::from(mass) + 1)
            } else {
                (-1, i16::from(best) + weak)
            };
            search
                .sh
                .bounded_choice_probes
                .fetch_add(1, Ordering::Relaxed);
            let bounds = search.window(child, alpha, beta)?;
            let rejected = if search.maximize {
                i16::from(bounds.hi) <= alpha
            } else {
                i16::from(bounds.lo) >= beta
            };
            if rejected {
                search
                    .sh
                    .bounded_choice_rejections
                    .fetch_add(1, Ordering::Relaxed);
                continue;
            }
            // The opposite cutoff is outside [0,mass], so a nonrejected
            // candidate is exact. Earlier tiles may replace on equality.
            debug_assert_eq!(bounds.lo, bounds.hi);
            debug_assert!(if search.maximize {
                bounds.lo > best || (earlier && bounds.lo == best)
            } else {
                bounds.lo < best || (earlier && bounds.lo == best)
            });
            best = bounds.lo;
            best_tile = tile;
        }
        search.finished().then_some(best_tile)
    })()
}

#[cfg(all(feature = "bounded-choice", feature = "const-objective"))]
fn choose_fixed(search: &mut Search<'_>, root: State, tiles: &[u8]) -> Option<u8> {
    if search.maximize {
        choose_fixed_const::<true>(search, root, tiles)
    } else {
        choose_fixed_const::<false>(search, root, tiles)
    }
}

#[cfg(all(feature = "bounded-choice", feature = "const-objective", feature = "extremum-choice"))]
fn choose_fixed_const<const MAX: bool>(
    search: &mut Search<'_>, root: State, tiles: &[u8],
) -> Option<u8> {
    extremum::choose_const::<MAX>(search, root, tiles)
}

#[cfg(all(feature = "bounded-choice", feature = "const-objective", not(feature = "extremum-choice")))]
fn choose_fixed_const<const MAX: bool>(
    search: &mut Search<'_>, root: State, tiles: &[u8],
) -> Option<u8> {
    assert!(!tiles.is_empty() && tiles.windows(2).all(|w| w[0] < w[1]));
    (|| {
        if !search.finished() { return None; }
        #[cfg(feature = "root-pivot")]
        let pivot = root_pivot(search, root, tiles);
        #[cfg(feature = "root-pivot")]
        let mut best_tile = pivot;
        #[cfg(not(feature = "root-pivot"))]
        let mut best_tile = tiles[0];
        let first = search.advance(root, u32::from(best_tile), root.alive);
        let mass = Search::alive_len(root);
        let first_bounds = search.window_const::<MAX>(first, -1, i16::from(mass) + 1)?;
        debug_assert_eq!(first_bounds.lo, first_bounds.hi);
        let mut best = first_bounds.lo;
        #[cfg(feature = "root-pivot")]
        let remaining = tiles;
        #[cfg(not(feature = "root-pivot"))]
        let remaining = &tiles[1..];
        for &tile in remaining {
            #[cfg(feature = "root-pivot")]
            if tile == pivot { continue; }
            if !search.continue_search() { return None; }
            #[cfg(feature = "root-pivot")]
            let earlier = tile < best_tile;
            #[cfg(not(feature = "root-pivot"))]
            let earlier = false;
            if ((MAX && best == mass) || (!MAX && best == 0)) && !earlier { break; }
            let child = search.advance(root, u32::from(tile), root.alive);
            let weak = if earlier { 1 } else { 0 };
            let (alpha, beta) = if MAX {
                (i16::from(best) - weak, i16::from(mass) + 1)
            } else {
                (-1, i16::from(best) + weak)
            };
            search.sh.bounded_choice_probes.fetch_add(1, Ordering::Relaxed);
            let bounds = search.window_const::<MAX>(child, alpha, beta)?;
            let rejected = if MAX {
                i16::from(bounds.hi) <= alpha
            } else {
                i16::from(bounds.lo) >= beta
            };
            if rejected {
                search.sh.bounded_choice_rejections.fetch_add(1, Ordering::Relaxed);
                continue;
            }
            debug_assert_eq!(bounds.lo, bounds.hi);
            debug_assert!(if MAX {
                bounds.lo > best || (earlier && bounds.lo == best)
            } else {
                bounds.lo < best || (earlier && bounds.lo == best)
            });
            best = bounds.lo;
            best_tile = tile;
        }
        search.finished().then_some(best_tile)
    })()
}

#[cfg(feature = "stack-dice")]
struct PreparedVoidless {
    worlds: [[u32; 4]; 8],
    seeds: [u64; 8],
}

/// Stack form of `InnerBelief::Voidless::sample` followed by its Dice seeds.
/// The tile pool is shuffled in place across samples, exactly as in the
/// source sampler; resetting it between samples would change every later RNG
/// world even with the same seed.
#[cfg(feature = "stack-dice")]
fn prepare_voidless(
    sh: &Shared,
    key: &Key,
    viewer: usize,
    hand: u32,
    sizes: [usize; 4],
    n: usize,
    rng: &mut SplitMix64,
) -> Option<PreparedVoidless> {
    debug_assert!((1..=8).contains(&n));
    let unseen = FULL_MASK & !key.played & !hand;
    let mut others = [0usize; 3];
    let mut other_len = 0;
    for seat in 0..4 {
        if seat != viewer {
            others[other_len] = seat;
            other_len += 1;
        }
    }
    assert_eq!(
        unseen.count_ones() as usize,
        others.iter().map(|&seat| sizes[seat]).sum::<usize>(),
    );
    if sh.dead.load(Ordering::Relaxed) || sh.deadline.passed() {
        sh.dead.store(true, Ordering::Relaxed);
        return None;
    }
    let mut tiles = [0u8; 28];
    let mut pool = unseen;
    let mut tile_len = 0;
    while pool != 0 {
        tiles[tile_len] = pool.trailing_zeros() as u8;
        tile_len += 1;
        pool &= pool - 1;
    }
    let mut worlds = [[0u32; 4]; 8];
    for sample_index in 0..n {
        #[cfg(not(feature = "coalesced-deadlines"))]
        if (sample_index == 0 || sample_index & 0xff == 0)
            && (sh.dead.load(Ordering::Relaxed) || sh.deadline.passed())
        {
            sh.dead.store(true, Ordering::Relaxed);
            return None;
        }
        #[cfg(feature = "coalesced-deadlines")]
        if sh.dead.load(Ordering::Relaxed) { return None; }
        for i in (1..tile_len).rev() {
            let j = rng.below((i + 1) as u64) as usize;
            tiles.swap(i, j);
        }
        worlds[sample_index][viewer] = hand;
        let mut off = 0;
        for &seat in &others {
            let end = off + sizes[seat];
            let mut mask = 0u32;
            for &tile in &tiles[off..end] {
                mask |= 1u32 << tile;
            }
            worlds[sample_index][seat] = mask;
            off = end;
        }
    }
    // The reference pi counts only fully sampled worlds, before drawing Dice
    // tapes. All n tapes then continue the very same SplitMix64 stream.
    sh.inner_worlds_by_level[0].fetch_add(n as u64, Ordering::Relaxed);
    let mut seeds = [0u64; 8];
    for seed in &mut seeds[..n] {
        *seed = rng.next_u64();
    }
    Some(PreparedVoidless { worlds, seeds })
}

/// Allocation-free L0 Voidless preparation and Fixed choice. `pi` still owns
/// the policy cache and publishes the choice only after its final deadline
/// check. Counted-void beliefs keep the existing sampler/solver path.
#[cfg(feature = "stack-dice")]
#[allow(clippy::too_many_arguments)]
pub(super) fn prepared_choice(
    sh: &Shared,
    key: &Key,
    viewer: usize,
    hand: u32,
    maximize: bool,
    sizes: [usize; 4],
    n: usize,
    rng: &mut SplitMix64,
    legal_mask: u32,
) -> Option<u8> {
    assert!((1..=8).contains(&n));
    assert_eq!((usize::from(key.leader) + key.plays.len()) % 4, viewer);
    // The seed is read before sampling, without advancing the stream. Timing
    // and atomics compile out completely when this feature is disabled.
    #[cfg(feature = "profile-phases")]
    let profile_started = (rng.0 & 0xff == 0).then(Instant::now);
    #[cfg(feature = "natural-job-capture")]
    let mut capture = capture::CaptureToken::begin(rng.0);
    let prepared = prepare_voidless(sh, key, viewer, hand, sizes, n, rng)?;
    let mut root_plays = 0u32;
    for (i, &tile) in key.plays.iter().enumerate() {
        root_plays |= u32::from(tile) << (5 * i);
    }
    let root = State {
        played: key.played,
        plays: root_plays,
        len: key.plays.len() as u8,
        leader: key.leader,
        t1: key.banked_t1,
        t0: key.banked_t0,
        alive: ((1u16 << n) - 1) as u8,
        #[cfg(feature = "compact-depth")]
        tricks_left: tricks_left_at_root(key),
    };
    let di = Decl::ALL
        .iter()
        .position(|&d| d == sh.dcl)
        .expect("declaration");
    let mut search = Search {
        rules: &RULES[di],
        sh,
        worlds: &prepared.worlds[..n],
        seeds: &prepared.seeds[..n],
        viewer: viewer as u8,
        hand,
        maximize,
        nodes: 0,
        viewer_children: 0,
        viewer_legal: 0,
    };
    let mut candidates = [0u8; 28];
    let mut candidate_len = 0;
    let mut legal = legal_mask;
    while legal != 0 {
        candidates[candidate_len] = legal.trailing_zeros() as u8;
        candidate_len += 1;
        legal &= legal - 1;
    }
    #[cfg(feature = "profile-phases")]
    let prepare_ns = profile_started.map(|started| started.elapsed().as_nanos() as u64);
    #[cfg(feature = "profile-phases")]
    let search_started = profile_started.map(|_| Instant::now());
    #[cfg(feature = "natural-job-capture")]
    if let Some(token) = capture.as_mut() { token.begin_search(); }
    let choice = choose_fixed(&mut search, root, &candidates[..candidate_len]);
    #[cfg(feature = "natural-job-capture")]
    if let Some(token) = capture {
        token.finish(&search, root, legal_mask, sizes, rng.0, choice);
    }
    #[cfg(feature = "profile-phases")]
    if let (Some(prepare_ns), Some(started)) = (prepare_ns, search_started) {
        PROFILE_PREPARE_NS.fetch_add(prepare_ns, Ordering::Relaxed);
        PROFILE_SEARCH_NS.fetch_add(started.elapsed().as_nanos() as u64, Ordering::Relaxed);
        PROFILE_NODES.fetch_add(search.nodes, Ordering::Relaxed);
        PROFILE_SAMPLES.fetch_add(1, Ordering::Relaxed);
    }
    sh.compact_dice_calls.fetch_add(1, Ordering::Relaxed);
    sh.compact_dice_nodes
        .fetch_add(search.nodes, Ordering::Relaxed);
    let remaining_tricks = (FULL_MASK & !key.played).count_ones() + key.plays.len() as u32;
    sh.compact_dice_max_tricks
        .fetch_max(u64::from(remaining_tricks / 4), Ordering::Relaxed);
    sh.nodes.fetch_add(search.nodes, Ordering::Relaxed);
    sh.viewer_children
        .fetch_add(search.viewer_children, Ordering::Relaxed);
    sh.viewer_legal
        .fetch_add(search.viewer_legal, Ordering::Relaxed);
    choice
}

#[cfg(all(test, feature = "stack-dice"))]
mod stack_tests {
    use super::*;
    use crate::rules::Seat;
    use crate::solver::{Deadline, InnerBelief};
    use std::time::Duration;

    #[test]
    fn stack_sampler_matches_worlds_dice_tapes_and_following_rng_state() {
        let opening = Key {
            voids: None,
            played: 0,
            leader: 0,
            plays: vec![],
            banked_t1: 0,
            banked_t0: 0,
            alive: 0,
        };
        let partial = Key {
            voids: None,
            played: (1 << 0) | (1 << 7),
            leader: 0,
            plays: vec![0, 7],
            banked_t1: 0,
            banked_t0: 0,
            alive: 0,
        };
        let frames = [
            (&opening, 0usize, (1 << 7) - 1, [7; 4]),
            (&partial, 2usize, ((1 << 7) - 1) << 14, [6, 6, 7, 7]),
        ];
        for decl in Decl::ALL {
            for &(key, viewer, hand, sizes) in &frames {
                for n in [1, 2, 8] {
                    let sh = Shared::new(
                        decl,
                        30,
                        vec![n],
                        0,
                        7,
                        Deadline::after(Duration::from_secs(10)),
                    );
                    let seed = 0x2d84_75c1 ^ u64::from(key.played) ^ n as u64;
                    let mut expected_rng = SplitMix64(seed);
                    let expected_worlds = InnerBelief::Voidless
                        .sample(
                            decl,
                            Seat::from_index(viewer).unwrap(),
                            hand,
                            key,
                            sizes,
                            n,
                            &mut expected_rng,
                            sh.deadline,
                        )
                        .unwrap();
                    let expected_seeds: Vec<u64> =
                        (0..n).map(|_| expected_rng.next_u64()).collect();
                    let expected_next = expected_rng.next_u64();
                    let mut actual_rng = SplitMix64(seed);
                    let actual =
                        prepare_voidless(&sh, key, viewer, hand, sizes, n, &mut actual_rng)
                            .unwrap();
                    assert_eq!(&actual.worlds[..n], expected_worlds.as_slice());
                    assert_eq!(&actual.seeds[..n], expected_seeds.as_slice());
                    assert_eq!(actual_rng.next_u64(), expected_next);
                    assert_eq!(sh.inner_worlds_by_level(), vec![n as u64]);
                }
            }
        }
    }

    #[cfg(feature = "profile-phases")]
    #[test]
    fn phase_sampling_preserves_choice_and_rng_stream() {
        use crate::solver::Field;
        use std::sync::Arc;

        let key = Key {
            voids: None,
            played: 0,
            leader: 0,
            plays: vec![],
            banked_t1: 0,
            banked_t0: 0,
            alive: 0,
        };
        let hand = (1u32 << 7) - 1;
        let tiles: Vec<u8> = (0..7).collect();
        let before = compact_phase_profile();
        for seed in [0x4ab3_0010_0000_0000, 0x4ab3_0010_0000_0001] {
            let sh = Arc::new(Shared::new(
                Decl::ALL[0],
                30,
                vec![1],
                0,
                7,
                Deadline::after(Duration::from_secs(10)),
            ));
            let mut profiled_rng = SplitMix64(seed);
            let actual = prepared_choice(
                &sh,
                &key,
                0,
                hand,
                false,
                [7; 4],
                1,
                &mut profiled_rng,
                hand,
            );

            let mut reference_rng = SplitMix64(seed);
            let prepared =
                prepare_voidless(&sh, &key, 0, hand, [7; 4], 1, &mut reference_rng).unwrap();
            assert_eq!(profiled_rng.0, reference_rng.0);
            let solver = Solver::new(
                Arc::clone(&sh),
                Seat::S0,
                hand,
                false,
                prepared.worlds[..1].to_vec(),
                prepared.seeds[..1].to_vec(),
                Field::Dice,
            );
            assert_eq!(actual, fixed_choice(&solver, &key, &tiles));
        }
        let after = compact_phase_profile();
        assert!(after.samples > before.samples);
        assert!(after.nodes > before.nodes);
    }
}

#[cfg(all(test, feature = "compact-depth"))]
mod depth_tests {
    use super::*;
    use crate::solver::Deadline;
    use std::time::Duration;

    #[test]
    fn trick_coordinate_matches_public_mask_after_every_legal_play() {
        assert_eq!(std::mem::size_of::<State>(), 16);
        let hands = std::array::from_fn(|seat| ((1u32 << 7) - 1) << (7 * seat));
        let worlds = [hands];
        let seeds = [0u64];
        for (di, decl) in Decl::ALL.into_iter().enumerate() {
            for leader in 0..4u8 {
                let sh = Shared::new(
                    decl,
                    30,
                    vec![1],
                    0,
                    7,
                    Deadline::after(Duration::from_secs(10)),
                );
                let search = Search {
                    rules: &RULES[di],
                    sh: &sh,
                    worlds: &worlds,
                    seeds: &seeds,
                    viewer: 0,
                    hand: hands[0],
                    maximize: false,
                    nodes: 0,
                    viewer_children: 0,
                    viewer_legal: 0,
                };
                let mut state = State {
                    played: 0,
                    plays: 0,
                    len: 0,
                    leader,
                    t1: 0,
                    t0: 0,
                    alive: 1,
                    tricks_left: 7,
                };
                for _ in 0..28 {
                    let mut key_plays = Vec::new();
                    for i in 0..state.len {
                        key_plays.push(((state.plays >> (5 * i)) & 31) as u8);
                    }
                    let key = Key {
                        voids: None,
                        played: state.played,
                        leader: state.leader,
                        plays: key_plays,
                        banked_t1: state.t1,
                        banked_t0: state.t0,
                        alive: 0,
                    };
                    assert_eq!(state.tricks_left, tricks_left_at_root(&key));
                    assert_eq!(state.is_last_trick(), state.tricks_left == 1);
                    let seat = usize::from((state.leader + state.len) & 3);
                    let hand = hands[seat] & !state.played;
                    let legal = search.legal(hand, state);
                    assert_ne!(legal, 0);
                    state = search.advance(state, legal.trailing_zeros(), 1);
                    let remaining = (FULL_MASK & !state.played).count_ones() + u32::from(state.len);
                    assert_eq!(u32::from(state.tricks_left) * 4, remaining);
                }
                assert_eq!(state.played, FULL_MASK);
                assert_eq!(state.len, 0);
                assert_eq!(state.tricks_left, 0);
                assert_eq!(u16::from(state.t1) + u16::from(state.t0), 42);
            }
        }
    }
}

#[cfg(all(test, feature = "compact-order"))]
mod order_tests {
    use super::*;
    use crate::rules::Seat;
    use crate::solver::{Deadline, Field};
    use std::{sync::Arc, time::Duration};

    #[test]
    fn interior_order_matches_authoritative_capture_first_on_legal_prefixes() {
        let hands: [u32; 4] = std::array::from_fn(|seat| ((1u32 << 7) - 1) << (7 * seat));
        let worlds = [hands];
        let seeds = [0u64];
        let mut compared = 0;
        let mut multiaction_partial = 0;
        for (di, decl) in Decl::ALL.into_iter().enumerate() {
            for initial_leader in 0..4u8 {
                let shared = Arc::new(Shared::new(
                    decl,
                    30,
                    vec![1],
                    0,
                    7,
                    Deadline::after(Duration::from_secs(10)),
                ));
                let mut state = State {
                    played: 0,
                    plays: 0,
                    len: 0,
                    leader: initial_leader,
                    t1: 0,
                    t0: 0,
                    alive: 1,
                    #[cfg(feature = "compact-depth")]
                    tricks_left: 7,
                };
                for _ in 0..28 {
                    let actor = usize::from((state.leader + state.len) & 3);
                    let hand = hands[actor] & !state.played;
                    let search = Search {
                        rules: &RULES[di],
                        sh: &shared,
                        worlds: &worlds,
                        seeds: &seeds,
                        viewer: actor as u8,
                        hand,
                        maximize: actor & 1 == 1,
                        nodes: 0,
                        viewer_children: 0,
                        viewer_legal: 0,
                    };
                    let legal = search.legal(hand, state);
                    let mut plays = Vec::new();
                    for i in 0..state.len {
                        plays.push(((state.plays >> (5 * i)) & 31) as u8);
                    }
                    let key = Key {
                        voids: None,
                        played: state.played,
                        leader: state.leader,
                        plays,
                        banked_t1: state.t1,
                        banked_t0: state.t0,
                        alive: 0,
                    };
                    let led = key
                        .plays
                        .first()
                        .map(|&t| decl.led_context(Domino::ALL[t as usize]));
                    let reference = Solver::new(
                        Arc::clone(&shared),
                        Seat::from_index(actor).unwrap(),
                        hand,
                        actor & 1 == 1,
                        vec![hands],
                        vec![0],
                        Field::Dice,
                    );
                    let expected: Vec<u32> = reference
                        .viewer_visit_order(&key, led, super::super::set_of(legal))
                        .iter()
                        .map(|t| t.index() as u32)
                        .collect();
                    let actual: Vec<u32> = search.viewer_moves(state, legal).collect();
                    assert_eq!(
                        actual, expected,
                        "decl={decl:?}, leader={initial_leader}, actor={actor}, len={}",
                        state.len
                    );
                    compared += 1;
                    multiaction_partial += usize::from(state.len > 0 && legal.count_ones() > 1);
                    state = search.advance(state, legal.trailing_zeros(), 1);
                }
            }
        }
        assert_eq!(compared, 9 * 4 * 28);
        assert!(multiaction_partial > 0);
    }
}
