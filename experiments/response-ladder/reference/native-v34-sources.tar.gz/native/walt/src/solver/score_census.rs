//! Post-join census of completed L0 policies after projecting out scores.
//!
//! Included as a child of `cache`, so the projection can use its private key
//! fields without widening the production cache API. No search path calls this.

use super::{CacheMap, PolicyKey};
use super::super::Shared;
use std::collections::BTreeMap;

/// Counts describe the cache snapshot, not policy requests or saved CPU time.
/// Histograms contain `(value, number_of_projected_keys)` pairs, sorted by value.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct ScoreCensusStats {
    /// U: distinct completed full L0 policy keys.
    pub full_keys: u64,
    /// P: distinct keys after removing both banked score fields.
    pub projected_keys: u64,
    /// U-P: additional score contexts, an opportunity count rather than hits.
    pub additional_score_contexts: u64,
    pub repeated_projected_keys: u64,
    pub repeated_same_action_groups: u64,
    pub repeated_mixed_action_groups: u64,
    /// Lawful identical public records have the same total banked points.
    /// A nonzero count invalidates the one-dimensional residual-target model
    /// for those groups and should be investigated before attempting reuse.
    pub inconsistent_banked_total_groups: u64,
    pub multiplicity_histogram: Vec<(usize, u64)>,
    pub distinct_t1_scores_histogram: Vec<(usize, u64)>,
    pub t1_score_span_histogram: Vec<(usize, u64)>,
    pub distinct_actions_histogram: Vec<(usize, u64)>,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ScoreCensusDepth {
    /// Number of tricks still to be banked, including an unfinished trick.
    pub remaining_tricks: usize,
    pub stats: ScoreCensusStats,
}

#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct ScoreCensus {
    pub all: ScoreCensusStats,
    pub by_remaining_tricks: Vec<ScoreCensusDepth>,
    pub excluded_non_l0_keys: u64,
}

struct Group {
    full_keys: usize,
    // Accommodate the u8 representation without assuming validated scores.
    scores: [u64; 4],
    actions: [u64; 4],
    min_score: u8,
    max_score: u8,
    min_total: u16,
    max_total: u16,
}

impl Group {
    fn new(key: &PolicyKey, action: u8) -> Self {
        let total = u16::from(key.banked_t1) + u16::from(key.banked_t0);
        let mut group = Self {
            full_keys: 0, scores: [0; 4], actions: [0; 4],
            min_score: key.banked_t1, max_score: key.banked_t1,
            min_total: total, max_total: total,
        };
        group.add(key, action);
        group
    }

    fn add(&mut self, key: &PolicyKey, action: u8) {
        self.full_keys += 1;
        let score = usize::from(key.banked_t1);
        self.scores[score / 64] |= 1u64 << (score % 64);
        let action = usize::from(action);
        self.actions[action / 64] |= 1u64 << (action % 64);
        self.min_score = self.min_score.min(key.banked_t1);
        self.max_score = self.max_score.max(key.banked_t1);
        let total = u16::from(key.banked_t1) + u16::from(key.banked_t0);
        self.min_total = self.min_total.min(total);
        self.max_total = self.max_total.max(total);
    }
}

#[derive(Default)]
struct Accumulator {
    stats: ScoreCensusStats,
    multiplicities: BTreeMap<usize, u64>,
    scores: BTreeMap<usize, u64>,
    spans: BTreeMap<usize, u64>,
    actions: BTreeMap<usize, u64>,
}

impl Accumulator {
    fn add(&mut self, group: &Group) {
        let score_count = group.scores.iter().map(|bits| bits.count_ones() as usize).sum();
        let action_count: usize = group.actions.iter().map(|bits| bits.count_ones() as usize).sum();
        self.stats.full_keys += group.full_keys as u64;
        self.stats.projected_keys += 1;
        self.stats.additional_score_contexts += (group.full_keys - 1) as u64;
        if group.full_keys > 1 {
            self.stats.repeated_projected_keys += 1;
            if action_count == 1 { self.stats.repeated_same_action_groups += 1; }
            else { self.stats.repeated_mixed_action_groups += 1; }
        }
        if group.min_total != group.max_total {
            self.stats.inconsistent_banked_total_groups += 1;
        }
        *self.multiplicities.entry(group.full_keys).or_default() += 1;
        *self.scores.entry(score_count).or_default() += 1;
        *self.spans.entry(usize::from(group.max_score - group.min_score)).or_default() += 1;
        *self.actions.entry(action_count).or_default() += 1;
    }

    fn finish(mut self) -> ScoreCensusStats {
        self.stats.multiplicity_histogram = self.multiplicities.into_iter().collect();
        self.stats.distinct_t1_scores_histogram = self.scores.into_iter().collect();
        self.stats.t1_score_span_histogram = self.spans.into_iter().collect();
        self.stats.distinct_actions_histogram = self.actions.into_iter().collect();
        self.stats
    }
}

fn projected(key: &PolicyKey) -> PolicyKey {
    PolicyKey { banked_t1: 0, banked_t0: 0, ..*key }
}

fn remaining_tricks(key: &PolicyKey) -> usize {
    // packed_plays uses a leading 1 sentinel followed by five bits per tile.
    let mut encoded = key.plays;
    let mut partial_len = 0usize;
    while encoded > 1 {
        encoded >>= 5;
        partial_len += 1;
    }
    debug_assert_eq!(encoded, 1);
    debug_assert!(partial_len <= 3);
    (28 - key.played.count_ones() as usize + partial_len) / 4
}

fn summarize(groups: CacheMap<PolicyKey, Group>, excluded_non_l0_keys: u64) -> ScoreCensus {
    let mut all = Accumulator::default();
    let mut depths: BTreeMap<usize, Accumulator> = BTreeMap::new();
    for (key, group) in groups {
        all.add(&group);
        depths.entry(remaining_tricks(&key)).or_default().add(&group);
    }
    ScoreCensus {
        all: all.finish(),
        by_remaining_tricks: depths.into_iter().map(|(remaining_tricks, accumulator)| {
            ScoreCensusDepth { remaining_tricks, stats: accumulator.finish() }
        }).collect(),
        excluded_non_l0_keys,
    }
}

impl Shared {
    /// Inspect completed L0 policy entries after all searches using this Shared
    /// have joined. The caller must keep the cache quiescent for this snapshot.
    ///
    /// This allocates O(P) temporary storage and locks each shard once. It does
    /// not change cache contents, solver counters, policies, or sample streams.
    /// Shared's declaration, sample budgets, belief, and boundary context are
    /// common to all entries; all other non-score key fields remain explicit.
    /// With cache carry enabled this is cumulative, so do not sum snapshots as
    /// if they were independent decisions. Census time is instrumentation time.
    #[must_use]
    pub fn score_census(&self) -> ScoreCensus {
        let mut groups: CacheMap<PolicyKey, Group> = CacheMap::default();
        let mut excluded = 0u64;
        for shard in &self.pi_cache {
            let completed = shard.lock().expect("pi shard poisoned");
            for ((level, key), &action) in completed.iter() {
                if *level != 0 { excluded += 1; continue; }
                groups.entry(projected(key))
                    .and_modify(|group| group.add(key, action))
                    .or_insert_with(|| Group::new(key, action));
            }
        }
        summarize(groups, excluded)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn key(t1: u8, t0: u8) -> PolicyKey {
        PolicyKey { voids: None, hand: 1, played: 0xff, plays: 1,
            seat: 0, leader: 0, banked_t1: t1, banked_t0: t0 }
    }

    #[test]
    fn projection_preserves_non_score_identity() {
        let a = key(3, 9);
        assert!(projected(&a) == projected(&key(8, 4)));
        let mut b = key(8, 4);
        b.hand = 2;
        assert!(projected(&a) != projected(&b));
        b = key(8, 4);
        b.plays = (1 << 5) | 0;
        assert!(projected(&a) != projected(&b));
        b = key(8, 4);
        b.voids = Some([0; 4]);
        assert!(projected(&a) != projected(&b));
    }

    #[test]
    fn histogram_counts_contexts_spans_and_action_disagreement() {
        let a = key(3, 9);
        let mut group = Group::new(&a, 2);
        group.add(&key(8, 4), 2);
        group.add(&key(10, 2), 7);
        let mut groups = CacheMap::default();
        groups.insert(projected(&a), group);
        let census = summarize(groups, 4);
        let stats = &census.all;
        assert_eq!((stats.full_keys, stats.projected_keys, stats.additional_score_contexts), (3, 1, 2));
        assert_eq!(stats.multiplicity_histogram, vec![(3, 1)]);
        assert_eq!(stats.distinct_t1_scores_histogram, vec![(3, 1)]);
        assert_eq!(stats.t1_score_span_histogram, vec![(7, 1)]);
        assert_eq!(stats.distinct_actions_histogram, vec![(2, 1)]);
        assert_eq!(stats.repeated_mixed_action_groups, 1);
        assert_eq!(stats.repeated_same_action_groups, 0);
        assert_eq!(stats.inconsistent_banked_total_groups, 0);
        assert_eq!(census.by_remaining_tricks[0].remaining_tricks, 5);
        assert_eq!(census.by_remaining_tricks[0].stats, *stats);
        assert_eq!(census.excluded_non_l0_keys, 4);
    }

    #[test]
    fn partial_lengths_and_inconsistent_score_totals_are_visible() {
        let mut a = key(3, 9);
        for partial in 0..=3 {
            a.played = (1 << (8 + partial)) - 1;
            a.plays = 1 << (5 * partial); // tile-zero encoding suffices for length
            assert_eq!(remaining_tricks(&a), 5);
        }
        let mut group = Group::new(&a, 2);
        a.banked_t0 += 1;
        group.add(&a, 2);
        let mut acc = Accumulator::default();
        acc.add(&group);
        let stats = acc.finish();
        assert_eq!(stats.inconsistent_banked_total_groups, 1);
        assert_eq!(stats.distinct_t1_scores_histogram, vec![(1, 1)]);
        assert_eq!(stats.repeated_same_action_groups, 1);
    }
}
