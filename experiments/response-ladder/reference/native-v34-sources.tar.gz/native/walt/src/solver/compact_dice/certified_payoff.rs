//! Remove sample IDs whose current trick already certifies a constant payoff.
//!
//! This is a support projection of constant objective terms, not a per-world
//! choice: all unremoved IDs retain their common viewer decisions and tapes.

use super::{Bounds, Decl, Rules, Search, State, RULES};

// Strictly beating tiles, indexed by declaration, led context, standing tile.
// Canonical Rules owns both follow incidence and total trick-strength order.
const BEATING: [[[u32; 28]; 8]; Decl::COUNT] = {
    let mut table = [[[0u32; 28]; 8]; Decl::COUNT];
    let mut d = 0;
    while d < Decl::COUNT {
        let mut q = 0;
        while q < 8 {
            let mut standing = 0;
            while standing < 28 {
                let mut tile = 0;
                while tile < 28 {
                    if RULES[d].strength[q][tile] > RULES[d].strength[q][standing] {
                        table[d][q][standing] |= 1 << tile;
                    }
                    tile += 1;
                }
                standing += 1;
            }
            q += 1;
        }
        d += 1;
    }
    table
};

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub(super) struct Certificate {
    pub(super) settled: u8,
    pub(super) wins: u8,
}

impl Certificate {
    #[inline]
    pub(super) fn residual(self, state: State) -> State {
        State { alive: state.alive & !self.settled, ..state }
    }

    #[inline]
    pub(super) fn shift(self, alpha: i16, beta: i16) -> (i16, i16) {
        (alpha - i16::from(self.wins), beta - i16::from(self.wins))
    }

    #[inline]
    pub(super) fn restore(self, b: Bounds) -> Bounds {
        Bounds { lo: self.wins + b.lo, hi: self.wins + b.hi }
    }
}

/// `legal(sid, seat)` supplies the canonical legal set for a not-yet-acting
/// seat at this public record. No physical transition or random draw occurs.
#[inline]
fn certify(
    rules: &Rules, declaration: usize, state: State, bid: u8,
    mut legal: impl FnMut(usize, u8) -> u32,
) -> Certificate {
    if state.len == 0 || state.alive == 0 || state.t1 >= bid || state.t0 > 42 - bid {
        return Certificate::default();
    }
    #[cfg(feature = "table-certified-payoff")]
    let (q, standing, winner, points) = {
        let entry = super::partial_payoff_table::lookup(declaration, state.len, state.plays);
        let _ = rules; // The immutable entry was generated from these rules.
        (((entry >> 12) & 7) as usize, ((entry >> 7) & 31) as usize,
            (state.leader + (entry & 3) as u8) & 3, ((entry >> 2) & 31) as u8)
    };
    #[cfg(not(feature = "table-certified-payoff"))]
    let (q, standing, winner, points) = {
        let q = rules.led[(state.plays & 31) as usize] as usize;
        let mut standing = (state.plays & 31) as usize;
        let mut winner = state.leader;
        let mut points = 1u8;
        for i in 0..state.len {
            let tile = ((state.plays >> (5 * i)) & 31) as usize;
            points += rules.count[tile];
            if rules.strength[q][tile] > rules.strength[q][standing] {
                standing = tile;
                winner = (state.leader + i) & 3;
            }
        }
        (q, standing, winner, points)
    };
    let team = winner & 1;
    // Widen before arithmetic: these are lower bounds on unbanked points.
    let enough = if team == 1 {
        u16::from(state.t1) + u16::from(points) >= u16::from(bid)
    } else {
        u16::from(state.t0) + u16::from(points) > 42 - u16::from(bid)
    };
    if !enough { return Certificate::default(); }
    let threats = BEATING[declaration][q][standing];
    let mut todo = state.alive;
    let mut settled = 0u8;
    while todo != 0 {
        let sid = todo.trailing_zeros() as usize;
        todo &= todo - 1;
        let mut safe = true;
        for i in state.len..4 {
            let seat = (state.leader + i) & 3;
            // A later winner on the same team preserves this certificate.
            if seat & 1 != team && legal(sid, seat) & threats != 0 {
                safe = false;
                break;
            }
        }
        if safe { settled |= 1 << sid; }
    }
    Certificate { settled, wins: if team == 1 { settled.count_ones() as u8 } else { 0 } }
}

impl Search<'_> {
    /// Fast handlers certify their own already-visited states. Defer here to
    /// avoid repeating the scan at every singleton / penultimate-tail entry.
    #[inline]
    pub(super) fn certified_before_dispatch(&self, state: State) -> Certificate {
        #[cfg(feature = "singleton-dice")]
        if state.alive.is_power_of_two() { return Certificate::default(); }
        #[cfg(feature = "two-trick-sum")]
        if self.has_two_trick_tail(state) { return Certificate::default(); }
        self.certified_trick_payoff(state)
    }

    #[inline]
    pub(super) fn certified_trick_payoff(&self, state: State) -> Certificate {
        // The direct final-trick evaluator is already cheaper and exact.
        if state.is_last_trick() { return Certificate::default(); }
        let declaration = match self.sh.dcl {
            Decl::PipTrump(pip) => pip.value() as usize,
            Decl::DoublesTrump => 7,
            Decl::NoTrump => 8,
        };
        certify(self.rules, declaration, state, self.sh.bid, |sid, seat| {
            let hand = if seat == self.viewer { self.hand } else { self.worlds[sid][seat as usize] };
            self.legal(hand & !state.played, state)
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::rules::Domino;

    fn tile(hi: u8, lo: u8) -> u32 {
        Domino::ALL.iter().position(|t| t.hi().value() == hi && t.lo().value() == lo).unwrap() as u32
    }
    fn state(leader: u8, plays: &[u32], t1: u8, t0: u8, alive: u8) -> State {
        State {
            played: plays.iter().fold(0, |a, &t| a | (1 << t)),
            plays: plays.iter().enumerate().fold(0, |a, (i, &t)| a | (t << (5 * i))),
            len: plays.len() as u8, leader, t1, t0, alive,
            #[cfg(feature = "compact-depth")]
            tricks_left: 3,
        }
    }
    fn legal(rules: &Rules, state: State, hand: u32) -> u32 {
        let q = rules.led[(state.plays & 31) as usize] as usize;
        let follow = hand & rules.incidence[q];
        if follow == 0 { hand } else { follow }
    }

    #[test]
    fn certified_payoff_tables_are_exact_strict_canonical_strength() {
        for d in 0..Decl::COUNT {
            for q in 0..8 {
                for standing in 0..28 {
                    for t in 0..28 {
                        assert_eq!(BEATING[d][q][standing] & (1 << t) != 0,
                            RULES[d].strength[q][t] > RULES[d].strength[q][standing]);
                    }
                }
            }
        }
    }

    #[test]
    fn certified_payoff_future_own_winner_and_legal_trump_threat() {
        let rules = &RULES[6]; // Sixes trump, fives led.
        let s = state(1, &[tile(5, 4)], 29, 0, 0x81); // Existing count 0 + trick 1 wins bid30.
        let weaker_follow = 1 << tile(5, 1);
        let trump = 1 << tile(6, 0);
        let own_winner = 1 << tile(5, 5);
        let c = certify(rules, 6, s, 30, |sid, seat| {
            assert_ne!(seat, 1); // Standing seat never acts again.
            if seat == 3 { return own_winner; }
            let hand = if sid == 7 && seat == 2 { trump } else { weaker_follow | trump };
            legal(rules, s, hand)
        });
        // ID0 must follow; its held trump is irrelevant. ID7 can legally trump.
        assert_eq!(c, Certificate { settled: 1, wins: 1 });
        assert_eq!(c.residual(s).alive, 0x80);
        // Own-team threats are not queried at all, even if they win instead.
        let safe = certify(rules, 6, s, 30, |_, seat| {
            assert_eq!(seat & 1, 0);
            weaker_follow
        });
        assert_eq!(safe.settled, 0x81);
    }

    #[test]
    fn certified_payoff_remaining_viewer_must_be_checked_already_acted_is_not() {
        let rules = &RULES[8];
        let s = state(1, &[tile(5, 4)], 29, 0, 1);
        let mut queried = Vec::new();
        let c = certify(rules, 8, s, 30, |_, seat| {
            queried.push(seat);
            if seat == 0 { 1 << tile(5, 5) } else { 1 << tile(5, 1) }
        });
        assert_eq!(c.settled, 0); // Remaining viewer at seat0 has a legal refutation.
        assert_eq!(queried, vec![2, 0]);
        let s = state(0, &[tile(5, 1), tile(5, 4)], 29, 0, 1);
        let c = certify(rules, 8, s, 30, |_, seat| {
            assert_eq!(seat, 2); // Viewer0 has acted and cannot threaten again.
            1 << tile(5, 2)
        });
        assert_eq!(c, Certificate { settled: 1, wins: 1 });
    }

    #[test]
    fn certified_payoff_score_gates_are_asymmetric_and_skip_scans() {
        let rules = &RULES[8];
        let win = state(1, &[tile(5, 4)], 28, 0, 0x81);
        assert_eq!(certify(rules, 8, win, 30, |_, _| panic!("gate must skip")), Certificate::default());
        let fail_equal = state(0, &[tile(5, 4)], 0, 11, 0x81);
        assert_eq!(certify(rules, 8, fail_equal, 30, |_, _| panic!("equality is undecided")), Certificate::default());
        let fail = State { t0: 12, ..fail_equal };
        assert_eq!(certify(rules, 8, fail, 30, |_, _| 1 << tile(5, 1)), Certificate { settled: 0x81, wins: 0 });
    }

    #[test]
    fn certified_payoff_affine_windows_and_common_max_min() {
        for credit in 0..=8u8 {
            for residual_mass in 0..=8-credit {
                let c = Certificate { settled: 0, wins: credit };
                for alpha in -1..=8i16 {
                    for beta in alpha+1..=9 {
                        let (a, b) = c.shift(alpha, beta);
                        for lo in 0..=residual_mass {
                            for hi in lo..=residual_mass {
                                let inner = Bounds { lo, hi };
                                let outer = c.restore(inner);
                                assert_eq!(inner.separates(a, b), outer.separates(alpha, beta));
                                assert!(outer.hi <= 8);
                            }
                        }
                    }
                }
            }
        }
        // Removed win/loss IDs have constant rows across all common actions.
        let residual_values = [0u8, 2, 2, 1];
        let credited = residual_values.map(|v| v + 3);
        for maximize in [false, true] {
            let choose = |v: &[u8]| {
                let mut best = 0;
                for i in 1..v.len() {
                    if (maximize && v[i] > v[best]) || (!maximize && v[i] < v[best]) { best = i; }
                }
                best
            };
            assert_eq!(choose(&residual_values), choose(&credited));
        }
    }

    // Deliberately unoptimized information-set oracle: no certificates,
    // singleton/last-trick/two-trick shortcuts, windows, or extremal cuts.
    fn oracle(search: &Search<'_>, s: State) -> u8 {
        if s.t1 >= search.sh.bid { return s.alive.count_ones() as u8; }
        if s.t0 > 42 - search.sh.bid { return 0; }
        if s.played == super::super::FULL_MASK { return 0; }
        let seat = (s.leader + s.len) & 3;
        if seat == search.viewer {
            let mut legal = search.legal(search.hand & !s.played, s);
            let mut values = Vec::new();
            while legal != 0 {
                let tile = legal.trailing_zeros();
                legal &= legal - 1;
                values.push(oracle(search, search.advance(s, tile, s.alive)));
            }
            if search.maximize { *values.iter().max().unwrap() } else { *values.iter().min().unwrap() }
        } else {
            let (buckets, mut occupied) = search.field_buckets(s, seat);
            let mut total = 0;
            while occupied != 0 {
                let tile = occupied.trailing_zeros();
                occupied &= occupied - 1;
                total += oracle(search, search.advance(s, tile, buckets[tile as usize]));
            }
            total
        }
    }

    #[test]
    fn certified_payoff_matches_uncertified_common_policy_oracle_and_cancellation() {
        use crate::solver::{Deadline, Shared, SplitMix64};
        use std::sync::atomic::Ordering;
        use std::time::Duration;
        for (di, decl) in Decl::ALL.into_iter().enumerate() {
            for deal in 0..8 {
                let mut rng = SplitMix64(0x1234_7788 + deal);
                let mut deck: Vec<u32> = (0..28).collect();
                for i in (1..28).rev() {
                    let j = rng.below((i + 1) as u64) as usize;
                    deck.swap(i, j);
                }
                let mut hands = [0u32; 4];
                for i in 0..12 { hands[i / 3] |= 1 << deck[i]; }
                let remaining = hands.iter().fold(0, |a, &h| a | h);
                let unbanked: u8 = deck[..12].iter().map(|&t| RULES[di].count[t as usize]).sum::<u8>() + 3;
                let banked = 42 - unbanked;
                // Mechanical score-conserving contexts, not a claim of past
                // reachability for these artificial assignment-only fixtures.
                let t0 = if deal & 1 == 0 { banked.min(12) } else { banked.saturating_sub(29) };
                let sh = Shared::new(decl, 30, vec![8], 0, 3,
                    Deadline::after(Duration::from_secs(30)));
                let worlds = [hands; 8]; // Duplicate deals, distinct IDs and tapes.
                let seeds = std::array::from_fn::<_, 8, _>(|_| rng.next_u64());
                let mut root = state((deal & 3) as u8, &[], banked-t0, t0, 0x81);
                root.played = super::super::FULL_MASK & !remaining;
                for partial in 0..4 {
                    for maximize in [false, true] {
                        let viewer = (root.leader + root.len) & 3;
                        let mut search = Search {
                            rules: &RULES[di], sh: &sh, worlds: &worlds, seeds: &seeds,
                            viewer, hand: hands[viewer as usize], maximize,
                            nodes: 0, viewer_children: 0, viewer_legal: 0,
                        };
                        for alive in [0x80, 0x81] {
                            let s = State { alive, ..root };
                            let expected = oracle(&search, s);
                            #[cfg(not(feature = "const-objective"))]
                            let exact = search.solve(s).unwrap();
                            #[cfg(feature = "const-objective")]
                            let exact = if maximize { search.solve_const::<true>(s) } else { search.solve_const::<false>(s) }.unwrap();
                            assert_eq!(exact, expected, "declaration={di} deal={deal} partial={partial} alive={alive} maximize={maximize}");
                            for alpha in -1..=2 {
                                for beta in alpha+1..=3 {
                                    #[cfg(not(feature = "const-objective"))]
                                    let b = search.window(s, alpha, beta).unwrap();
                                    #[cfg(feature = "const-objective")]
                                    let b = if maximize { search.window_const::<true>(s, alpha, beta) } else { search.window_const::<false>(s, alpha, beta) }.unwrap();
                                    assert!(b.lo <= expected && expected <= b.hi);
                                    assert!(b.separates(alpha, beta));
                                }
                            }
                        }
                    }
                    if partial != 3 {
                        let seat = ((root.leader + root.len) & 3) as usize;
                        let hand = hands[seat] & !root.played;
                        let moves = if root.len == 0 { hand } else { legal(&RULES[di], root, hand) };
                        let tile = moves.trailing_zeros();
                        root.played |= 1 << tile;
                        root.plays |= tile << (5 * root.len);
                        root.len += 1;
                    }
                }
                sh.dead.store(true, Ordering::Relaxed);
                let mut search = Search {
                    rules: &RULES[di], sh: &sh, worlds: &worlds, seeds: &seeds,
                    viewer: (root.leader + root.len) & 3,
                    hand: hands[((root.leader + root.len) & 3) as usize],
                    maximize: true, nodes: 0, viewer_children: 0, viewer_legal: 0,
                };
                #[cfg(not(feature = "const-objective"))]
                assert!(search.window(root, -1, 3).is_none());
                #[cfg(feature = "const-objective")]
                assert!(search.window_const::<true>(root, -1, 3).is_none());
            }
        }
    }

    #[test]
    fn certified_payoff_constant_support_returns_credit_without_a_child_visit() {
        use crate::solver::{Deadline, Shared};
        use std::time::Duration;
        let lead = tile(6, 6);
        let mut deck = vec![lead];
        deck.extend((0..28u32).filter(|&t| t != lead && RULES[8].count[t as usize] == 0).take(11));
        assert_eq!(deck.len(), 12);
        let mut hands = [0u32; 4];
        for i in 0..12 { hands[i / 3] |= 1 << deck[i]; }
        let remaining = hands.iter().fold(0, |a, &h| a | h);
        for team in [0u8, 1] {
            let mut hands = hands;
            hands.swap(0, usize::from(team)); // Leader owns unbeatable 6-6.
            let worlds = [hands; 8];
            let seeds = [91, 7, 32, 5, 44, 4, 71, 99];
            let (t1, t0) = if team == 1 { (29, 10) } else { (27, 12) };
            let mut s = state(team, &[lead], t1, t0, 0x81);
            s.played = (super::super::FULL_MASK & !remaining) | (1 << lead);
            let sh = Shared::new(Decl::NoTrump, 30, vec![8], 0, 3,
                Deadline::after(Duration::from_secs(10)));
            for maximize in [false, true] {
                let viewer = (team + 1) & 3; // Opponent still has multiple choices.
                let mut search = Search {
                    rules: &RULES[8], sh: &sh, worlds: &worlds, seeds: &seeds,
                    viewer, hand: hands[viewer as usize], maximize,
                    nodes: 0, viewer_children: 0, viewer_legal: 0,
                };
                let certificate = search.certified_trick_payoff(s);
                assert_eq!(certificate.settled, 0x81);
                assert_eq!(certificate.wins, team * 2);
                assert_eq!(oracle(&search, s), team * 2);
                #[cfg(not(feature = "const-objective"))]
                let exact = search.solve(s).unwrap();
                #[cfg(feature = "const-objective")]
                let exact = if maximize { search.solve_const::<true>(s) } else { search.solve_const::<false>(s) }.unwrap();
                assert_eq!(exact, team * 2);
                assert_eq!(search.nodes, 1);
                #[cfg(not(feature = "const-objective"))]
                let b = search.window(s, -1, 3).unwrap();
                #[cfg(feature = "const-objective")]
                let b = if maximize { search.window_const::<true>(s, -1, 3) } else { search.window_const::<false>(s, -1, 3) }.unwrap();
                assert_eq!((b.lo, b.hi), (team * 2, team * 2));
                assert_eq!(search.nodes, 2);
            }
        }
    }
}
